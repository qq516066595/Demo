﻿namespace HZH_Controls.Controls
{
    partial class UCCalendarNotes_Week
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panWeek = new System.Windows.Forms.TableLayoutPanel();
            this.lblRight = new System.Windows.Forms.Label();
            this.lblWeek_7 = new System.Windows.Forms.Label();
            this.lblWeek_6 = new System.Windows.Forms.Label();
            this.lblWeek_5 = new System.Windows.Forms.Label();
            this.lblWeek_4 = new System.Windows.Forms.Label();
            this.lblWeek_3 = new System.Windows.Forms.Label();
            this.lblWeek_2 = new System.Windows.Forms.Label();
            this.lblWeek_1 = new System.Windows.Forms.Label();
            this.lblLeft = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panMain = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblClose = new System.Windows.Forms.Label();
            this.lblAdd = new System.Windows.Forms.Label();
            this.panWeek.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panWeek
            // 
            this.panWeek.BackColor = System.Drawing.Color.White;
            this.panWeek.ColumnCount = 9;
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.panWeek.Controls.Add(this.lblRight, 8, 0);
            this.panWeek.Controls.Add(this.lblWeek_7, 7, 0);
            this.panWeek.Controls.Add(this.lblWeek_6, 6, 0);
            this.panWeek.Controls.Add(this.lblWeek_5, 5, 0);
            this.panWeek.Controls.Add(this.lblWeek_4, 4, 0);
            this.panWeek.Controls.Add(this.lblWeek_3, 3, 0);
            this.panWeek.Controls.Add(this.lblWeek_2, 2, 0);
            this.panWeek.Controls.Add(this.lblWeek_1, 1, 0);
            this.panWeek.Controls.Add(this.lblLeft, 0, 0);
            this.panWeek.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panWeek.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.panWeek.Location = new System.Drawing.Point(0, 0);
            this.panWeek.Name = "panWeek";
            this.panWeek.RowCount = 1;
            this.panWeek.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.panWeek.Size = new System.Drawing.Size(394, 51);
            this.panWeek.TabIndex = 3;
            // 
            // lblRight
            // 
            this.lblRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRight.Font = new System.Drawing.Font("宋体", 15F);
            this.lblRight.Location = new System.Drawing.Point(373, 0);
            this.lblRight.Name = "lblRight";
            this.lblRight.Size = new System.Drawing.Size(18, 51);
            this.lblRight.TabIndex = 8;
            this.lblRight.Text = "▶";
            this.lblRight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblRight.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lblRight_MouseClick);
            // 
            // lblWeek_7
            // 
            this.lblWeek_7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWeek_7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeek_7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblWeek_7.Location = new System.Drawing.Point(323, 0);
            this.lblWeek_7.Name = "lblWeek_7";
            this.lblWeek_7.Size = new System.Drawing.Size(44, 51);
            this.lblWeek_7.TabIndex = 6;
            this.lblWeek_7.Text = "六";
            this.lblWeek_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblWeek_7.Click += new System.EventHandler(this.lblWeek_Click);
            // 
            // lblWeek_6
            // 
            this.lblWeek_6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWeek_6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeek_6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblWeek_6.Location = new System.Drawing.Point(273, 0);
            this.lblWeek_6.Name = "lblWeek_6";
            this.lblWeek_6.Size = new System.Drawing.Size(44, 51);
            this.lblWeek_6.TabIndex = 5;
            this.lblWeek_6.Text = "五";
            this.lblWeek_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblWeek_6.Click += new System.EventHandler(this.lblWeek_Click);
            // 
            // lblWeek_5
            // 
            this.lblWeek_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWeek_5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeek_5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblWeek_5.Location = new System.Drawing.Point(223, 0);
            this.lblWeek_5.Name = "lblWeek_5";
            this.lblWeek_5.Size = new System.Drawing.Size(44, 51);
            this.lblWeek_5.TabIndex = 4;
            this.lblWeek_5.Text = "四";
            this.lblWeek_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblWeek_5.Click += new System.EventHandler(this.lblWeek_Click);
            // 
            // lblWeek_4
            // 
            this.lblWeek_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWeek_4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeek_4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblWeek_4.Location = new System.Drawing.Point(173, 0);
            this.lblWeek_4.Name = "lblWeek_4";
            this.lblWeek_4.Size = new System.Drawing.Size(44, 51);
            this.lblWeek_4.TabIndex = 3;
            this.lblWeek_4.Text = "三";
            this.lblWeek_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblWeek_4.Click += new System.EventHandler(this.lblWeek_Click);
            // 
            // lblWeek_3
            // 
            this.lblWeek_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWeek_3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeek_3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblWeek_3.Location = new System.Drawing.Point(123, 0);
            this.lblWeek_3.Name = "lblWeek_3";
            this.lblWeek_3.Size = new System.Drawing.Size(44, 51);
            this.lblWeek_3.TabIndex = 2;
            this.lblWeek_3.Text = "二";
            this.lblWeek_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblWeek_3.Click += new System.EventHandler(this.lblWeek_Click);
            // 
            // lblWeek_2
            // 
            this.lblWeek_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWeek_2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeek_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblWeek_2.Location = new System.Drawing.Point(73, 0);
            this.lblWeek_2.Name = "lblWeek_2";
            this.lblWeek_2.Size = new System.Drawing.Size(44, 51);
            this.lblWeek_2.TabIndex = 1;
            this.lblWeek_2.Text = "一";
            this.lblWeek_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblWeek_2.Click += new System.EventHandler(this.lblWeek_Click);
            // 
            // lblWeek_1
            // 
            this.lblWeek_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWeek_1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeek_1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblWeek_1.Location = new System.Drawing.Point(23, 0);
            this.lblWeek_1.Name = "lblWeek_1";
            this.lblWeek_1.Size = new System.Drawing.Size(44, 51);
            this.lblWeek_1.TabIndex = 0;
            this.lblWeek_1.Text = "日";
            this.lblWeek_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblWeek_1.Click += new System.EventHandler(this.lblWeek_Click);
            // 
            // lblLeft
            // 
            this.lblLeft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblLeft.Font = new System.Drawing.Font("宋体", 15F);
            this.lblLeft.Location = new System.Drawing.Point(3, 0);
            this.lblLeft.Name = "lblLeft";
            this.lblLeft.Size = new System.Drawing.Size(14, 51);
            this.lblLeft.TabIndex = 7;
            this.lblLeft.Text = "◀";
            this.lblLeft.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblLeft.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lblLeft_MouseClick);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.panMain);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 51);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(482, 354);
            this.panel1.TabIndex = 4;
            // 
            // panMain
            // 
            this.panMain.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panMain.Location = new System.Drawing.Point(0, 0);
            this.panMain.Name = "panMain";
            this.panMain.Size = new System.Drawing.Size(482, 1220);
            this.panMain.TabIndex = 5;
            this.panMain.Paint += new System.Windows.Forms.PaintEventHandler(this.panMain_Paint);
            this.panMain.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panMain_MouseClick);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panWeek);
            this.panel2.Controls.Add(this.lblAdd);
            this.panel2.Controls.Add(this.lblClose);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(482, 51);
            this.panel2.TabIndex = 0;
            // 
            // lblClose
            // 
            this.lblClose.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblClose.Font = new System.Drawing.Font("微软雅黑", 13F);
            this.lblClose.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblClose.Location = new System.Drawing.Point(438, 0);
            this.lblClose.Name = "lblClose";
            this.lblClose.Size = new System.Drawing.Size(44, 51);
            this.lblClose.TabIndex = 7;
            this.lblClose.Text = "✖";
            this.lblClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblClose.Click += new System.EventHandler(this.lblClose_Click);
            // 
            // lblAdd
            // 
            this.lblAdd.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblAdd.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.lblAdd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblAdd.Location = new System.Drawing.Point(394, 0);
            this.lblAdd.Name = "lblAdd";
            this.lblAdd.Size = new System.Drawing.Size(44, 51);
            this.lblAdd.TabIndex = 8;
            this.lblAdd.Text = "添加\r\n日程";
            this.lblAdd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblAdd.Click += new System.EventHandler(this.lblAdd_Click);
            // 
            // UCCalendarNotes_Week
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "UCCalendarNotes_Week";
            this.Size = new System.Drawing.Size(482, 405);
            this.VisibleChanged += new System.EventHandler(this.UCCalendarNotes_Week_VisibleChanged);
            this.panWeek.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel panWeek;
        private System.Windows.Forms.Label lblRight;
        private System.Windows.Forms.Label lblWeek_7;
        private System.Windows.Forms.Label lblWeek_6;
        private System.Windows.Forms.Label lblWeek_5;
        private System.Windows.Forms.Label lblWeek_4;
        private System.Windows.Forms.Label lblWeek_3;
        private System.Windows.Forms.Label lblWeek_2;
        private System.Windows.Forms.Label lblWeek_1;
        private System.Windows.Forms.Label lblLeft;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panMain;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblClose;
        private System.Windows.Forms.Label lblAdd;
    }
}

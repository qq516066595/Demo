﻿// ***********************************************************************
// Assembly         : HZH_Controls
// Created          : 2019-09-17
//
// ***********************************************************************
// <copyright file="GraphDirection.cs">
//     Copyright by Huang Zhenghui(黄正辉) All, QQ group:568015492 QQ:623128629 Email:623128629@qq.com
// </copyright>
//
// Blog: https://www.cnblogs.com/bfyx
// GitHub：https://github.com/kwwwvagaa/NetWinformControl
// gitee：https://gitee.com/kwwwvagaa/net_winform_custom_control.git
//
// If you use this code, please keep this note.
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HZH_Controls
{
    /// <summary>
    /// Enum GraphDirection
    /// </summary>
    public enum GraphDirection
    {
        /// <summary>
        /// The upward
        /// </summary>
        Upward = 1,
        /// <summary>
        /// The downward
        /// </summary>
        Downward,
        /// <summary>
        /// The leftward
        /// </summary>
        Leftward,
        /// <summary>
        /// The rightward
        /// </summary>
        Rightward
    }
}

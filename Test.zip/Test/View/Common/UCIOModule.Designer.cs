﻿namespace Test.View.Common
{
    partial class UCIOModule
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.ucSignalLamp16 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp14 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp12 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp10 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp8 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp5 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp3 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp15 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp13 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp11 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp9 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp7 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp4 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp2 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp1 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp6 = new HZH_Controls.Controls.UCSignalLamp();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(24, 3);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(99, 20);
            this.label1.TabIndex = 30;
            this.label1.Text = "##########";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(148, 3);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(99, 20);
            this.label2.TabIndex = 30;
            this.label2.Text = "##########";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(24, 26);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label3.Size = new System.Drawing.Size(99, 20);
            this.label3.TabIndex = 30;
            this.label3.Text = "##########";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(148, 26);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(99, 20);
            this.label4.TabIndex = 30;
            this.label4.Text = "##########";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(24, 49);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(99, 20);
            this.label5.TabIndex = 30;
            this.label5.Text = "##########";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(148, 49);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label6.Size = new System.Drawing.Size(99, 20);
            this.label6.TabIndex = 30;
            this.label6.Text = "##########";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(24, 72);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label7.Size = new System.Drawing.Size(99, 20);
            this.label7.TabIndex = 30;
            this.label7.Text = "##########";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(148, 72);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label8.Size = new System.Drawing.Size(99, 20);
            this.label8.TabIndex = 30;
            this.label8.Text = "##########";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(24, 95);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label9.Size = new System.Drawing.Size(99, 20);
            this.label9.TabIndex = 30;
            this.label9.Text = "##########";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(148, 95);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(99, 20);
            this.label10.TabIndex = 30;
            this.label10.Text = "##########";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(24, 118);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label11.Size = new System.Drawing.Size(99, 20);
            this.label11.TabIndex = 30;
            this.label11.Text = "##########";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(148, 118);
            this.label12.Name = "label12";
            this.label12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label12.Size = new System.Drawing.Size(99, 20);
            this.label12.TabIndex = 30;
            this.label12.Text = "##########";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(24, 141);
            this.label13.Name = "label13";
            this.label13.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label13.Size = new System.Drawing.Size(99, 20);
            this.label13.TabIndex = 30;
            this.label13.Text = "##########";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(148, 141);
            this.label14.Name = "label14";
            this.label14.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label14.Size = new System.Drawing.Size(99, 20);
            this.label14.TabIndex = 30;
            this.label14.Text = "##########";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(24, 164);
            this.label15.Name = "label15";
            this.label15.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label15.Size = new System.Drawing.Size(99, 20);
            this.label15.TabIndex = 30;
            this.label15.Text = "##########";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(148, 164);
            this.label16.Name = "label16";
            this.label16.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label16.Size = new System.Drawing.Size(99, 20);
            this.label16.TabIndex = 30;
            this.label16.Text = "##########";
            // 
            // ucSignalLamp16
            // 
            this.ucSignalLamp16.IsHighlight = true;
            this.ucSignalLamp16.IsShowBorder = false;
            this.ucSignalLamp16.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp16.Location = new System.Drawing.Point(126, 164);
            this.ucSignalLamp16.Name = "ucSignalLamp16";
            this.ucSignalLamp16.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp16.TabIndex = 28;
            this.ucSignalLamp16.TwinkleSpeed = 0;
            // 
            // ucSignalLamp14
            // 
            this.ucSignalLamp14.IsHighlight = true;
            this.ucSignalLamp14.IsShowBorder = false;
            this.ucSignalLamp14.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp14.Location = new System.Drawing.Point(126, 141);
            this.ucSignalLamp14.Name = "ucSignalLamp14";
            this.ucSignalLamp14.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp14.TabIndex = 28;
            this.ucSignalLamp14.TwinkleSpeed = 0;
            // 
            // ucSignalLamp12
            // 
            this.ucSignalLamp12.IsHighlight = true;
            this.ucSignalLamp12.IsShowBorder = false;
            this.ucSignalLamp12.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp12.Location = new System.Drawing.Point(126, 118);
            this.ucSignalLamp12.Name = "ucSignalLamp12";
            this.ucSignalLamp12.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp12.TabIndex = 28;
            this.ucSignalLamp12.TwinkleSpeed = 0;
            // 
            // ucSignalLamp10
            // 
            this.ucSignalLamp10.IsHighlight = true;
            this.ucSignalLamp10.IsShowBorder = false;
            this.ucSignalLamp10.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp10.Location = new System.Drawing.Point(126, 95);
            this.ucSignalLamp10.Name = "ucSignalLamp10";
            this.ucSignalLamp10.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp10.TabIndex = 28;
            this.ucSignalLamp10.TwinkleSpeed = 0;
            // 
            // ucSignalLamp8
            // 
            this.ucSignalLamp8.IsHighlight = true;
            this.ucSignalLamp8.IsShowBorder = false;
            this.ucSignalLamp8.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp8.Location = new System.Drawing.Point(126, 72);
            this.ucSignalLamp8.Name = "ucSignalLamp8";
            this.ucSignalLamp8.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp8.TabIndex = 28;
            this.ucSignalLamp8.TwinkleSpeed = 0;
            // 
            // ucSignalLamp5
            // 
            this.ucSignalLamp5.IsHighlight = true;
            this.ucSignalLamp5.IsShowBorder = false;
            this.ucSignalLamp5.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp5.Location = new System.Drawing.Point(126, 49);
            this.ucSignalLamp5.Name = "ucSignalLamp5";
            this.ucSignalLamp5.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp5.TabIndex = 28;
            this.ucSignalLamp5.TwinkleSpeed = 0;
            // 
            // ucSignalLamp3
            // 
            this.ucSignalLamp3.IsHighlight = true;
            this.ucSignalLamp3.IsShowBorder = false;
            this.ucSignalLamp3.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp3.Location = new System.Drawing.Point(126, 26);
            this.ucSignalLamp3.Name = "ucSignalLamp3";
            this.ucSignalLamp3.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp3.TabIndex = 28;
            this.ucSignalLamp3.TwinkleSpeed = 0;
            // 
            // ucSignalLamp15
            // 
            this.ucSignalLamp15.IsHighlight = true;
            this.ucSignalLamp15.IsShowBorder = false;
            this.ucSignalLamp15.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp15.Location = new System.Drawing.Point(2, 164);
            this.ucSignalLamp15.Name = "ucSignalLamp15";
            this.ucSignalLamp15.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp15.TabIndex = 28;
            this.ucSignalLamp15.TwinkleSpeed = 0;
            // 
            // ucSignalLamp13
            // 
            this.ucSignalLamp13.IsHighlight = true;
            this.ucSignalLamp13.IsShowBorder = false;
            this.ucSignalLamp13.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp13.Location = new System.Drawing.Point(2, 141);
            this.ucSignalLamp13.Name = "ucSignalLamp13";
            this.ucSignalLamp13.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp13.TabIndex = 28;
            this.ucSignalLamp13.TwinkleSpeed = 0;
            // 
            // ucSignalLamp11
            // 
            this.ucSignalLamp11.IsHighlight = true;
            this.ucSignalLamp11.IsShowBorder = false;
            this.ucSignalLamp11.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp11.Location = new System.Drawing.Point(2, 118);
            this.ucSignalLamp11.Name = "ucSignalLamp11";
            this.ucSignalLamp11.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp11.TabIndex = 28;
            this.ucSignalLamp11.TwinkleSpeed = 0;
            // 
            // ucSignalLamp9
            // 
            this.ucSignalLamp9.IsHighlight = true;
            this.ucSignalLamp9.IsShowBorder = false;
            this.ucSignalLamp9.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp9.Location = new System.Drawing.Point(2, 95);
            this.ucSignalLamp9.Name = "ucSignalLamp9";
            this.ucSignalLamp9.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp9.TabIndex = 28;
            this.ucSignalLamp9.TwinkleSpeed = 0;
            // 
            // ucSignalLamp7
            // 
            this.ucSignalLamp7.IsHighlight = true;
            this.ucSignalLamp7.IsShowBorder = false;
            this.ucSignalLamp7.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp7.Location = new System.Drawing.Point(2, 72);
            this.ucSignalLamp7.Name = "ucSignalLamp7";
            this.ucSignalLamp7.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp7.TabIndex = 28;
            this.ucSignalLamp7.TwinkleSpeed = 0;
            // 
            // ucSignalLamp4
            // 
            this.ucSignalLamp4.IsHighlight = true;
            this.ucSignalLamp4.IsShowBorder = false;
            this.ucSignalLamp4.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp4.Location = new System.Drawing.Point(2, 49);
            this.ucSignalLamp4.Name = "ucSignalLamp4";
            this.ucSignalLamp4.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp4.TabIndex = 28;
            this.ucSignalLamp4.TwinkleSpeed = 0;
            // 
            // ucSignalLamp2
            // 
            this.ucSignalLamp2.IsHighlight = true;
            this.ucSignalLamp2.IsShowBorder = false;
            this.ucSignalLamp2.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp2.Location = new System.Drawing.Point(2, 26);
            this.ucSignalLamp2.Name = "ucSignalLamp2";
            this.ucSignalLamp2.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp2.TabIndex = 28;
            this.ucSignalLamp2.TwinkleSpeed = 0;
            // 
            // ucSignalLamp1
            // 
            this.ucSignalLamp1.IsHighlight = true;
            this.ucSignalLamp1.IsShowBorder = false;
            this.ucSignalLamp1.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp1.Location = new System.Drawing.Point(126, 3);
            this.ucSignalLamp1.Name = "ucSignalLamp1";
            this.ucSignalLamp1.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp1.TabIndex = 28;
            this.ucSignalLamp1.TwinkleSpeed = 0;
            // 
            // ucSignalLamp6
            // 
            this.ucSignalLamp6.IsHighlight = true;
            this.ucSignalLamp6.IsShowBorder = false;
            this.ucSignalLamp6.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp6.Location = new System.Drawing.Point(2, 3);
            this.ucSignalLamp6.Name = "ucSignalLamp6";
            this.ucSignalLamp6.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp6.TabIndex = 28;
            this.ucSignalLamp6.TwinkleSpeed = 0;
            // 
            // UCIOModule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ucSignalLamp16);
            this.Controls.Add(this.ucSignalLamp14);
            this.Controls.Add(this.ucSignalLamp12);
            this.Controls.Add(this.ucSignalLamp10);
            this.Controls.Add(this.ucSignalLamp8);
            this.Controls.Add(this.ucSignalLamp5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ucSignalLamp3);
            this.Controls.Add(this.ucSignalLamp15);
            this.Controls.Add(this.ucSignalLamp13);
            this.Controls.Add(this.ucSignalLamp11);
            this.Controls.Add(this.ucSignalLamp9);
            this.Controls.Add(this.ucSignalLamp7);
            this.Controls.Add(this.ucSignalLamp4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ucSignalLamp2);
            this.Controls.Add(this.ucSignalLamp1);
            this.Controls.Add(this.ucSignalLamp6);
            this.Name = "UCIOModule";
            this.Size = new System.Drawing.Size(247, 188);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp6;
        private System.Windows.Forms.Label label1;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp1;
        private System.Windows.Forms.Label label2;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp2;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp4;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp7;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp9;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp11;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp13;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp15;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
    }
}

﻿namespace Test.View.Tube
{
    partial class UCSetMFC
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucSetMFCModule1 = new Test.View.Common.UCSetMFCModule();
            this.ucSetMFCModule2 = new Test.View.Common.UCSetMFCModule();
            this.ucSetMFCModule3 = new Test.View.Common.UCSetMFCModule();
            this.ucSetMFCModule4 = new Test.View.Common.UCSetMFCModule();
            this.ucSetMFCModule5 = new Test.View.Common.UCSetMFCModule();
            this.ucSetMFCModule6 = new Test.View.Common.UCSetMFCModule();
            this.ucSetMFCModule7 = new Test.View.Common.UCSetMFCModule();
            this.ucSetMFCModule8 = new Test.View.Common.UCSetMFCModule();
            this.ucSetMFCModule9 = new Test.View.Common.UCSetMFCModule();
            this.ucSetMFCModule10 = new Test.View.Common.UCSetMFCModule();
            this.ucSetMFCModule11 = new Test.View.Common.UCSetMFCModule();
            this.ucSetMFCModule12 = new Test.View.Common.UCSetMFCModule();
            this.label27 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ucSetMFCModule1
            // 
            this.ucSetMFCModule1.Location = new System.Drawing.Point(0, 8);
            this.ucSetMFCModule1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ucSetMFCModule1.Name = "ucSetMFCModule1";
            this.ucSetMFCModule1.Size = new System.Drawing.Size(248, 160);
            this.ucSetMFCModule1.TabIndex = 0;
            // 
            // ucSetMFCModule2
            // 
            this.ucSetMFCModule2.Location = new System.Drawing.Point(256, 8);
            this.ucSetMFCModule2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ucSetMFCModule2.Name = "ucSetMFCModule2";
            this.ucSetMFCModule2.Size = new System.Drawing.Size(248, 160);
            this.ucSetMFCModule2.TabIndex = 1;
            // 
            // ucSetMFCModule3
            // 
            this.ucSetMFCModule3.Location = new System.Drawing.Point(513, 8);
            this.ucSetMFCModule3.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ucSetMFCModule3.Name = "ucSetMFCModule3";
            this.ucSetMFCModule3.Size = new System.Drawing.Size(248, 160);
            this.ucSetMFCModule3.TabIndex = 2;
            // 
            // ucSetMFCModule4
            // 
            this.ucSetMFCModule4.Location = new System.Drawing.Point(770, 8);
            this.ucSetMFCModule4.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ucSetMFCModule4.Name = "ucSetMFCModule4";
            this.ucSetMFCModule4.Size = new System.Drawing.Size(248, 160);
            this.ucSetMFCModule4.TabIndex = 3;
            // 
            // ucSetMFCModule5
            // 
            this.ucSetMFCModule5.Location = new System.Drawing.Point(0, 166);
            this.ucSetMFCModule5.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ucSetMFCModule5.Name = "ucSetMFCModule5";
            this.ucSetMFCModule5.Size = new System.Drawing.Size(248, 160);
            this.ucSetMFCModule5.TabIndex = 0;
            // 
            // ucSetMFCModule6
            // 
            this.ucSetMFCModule6.Location = new System.Drawing.Point(256, 166);
            this.ucSetMFCModule6.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ucSetMFCModule6.Name = "ucSetMFCModule6";
            this.ucSetMFCModule6.Size = new System.Drawing.Size(248, 160);
            this.ucSetMFCModule6.TabIndex = 1;
            // 
            // ucSetMFCModule7
            // 
            this.ucSetMFCModule7.Location = new System.Drawing.Point(513, 166);
            this.ucSetMFCModule7.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ucSetMFCModule7.Name = "ucSetMFCModule7";
            this.ucSetMFCModule7.Size = new System.Drawing.Size(248, 160);
            this.ucSetMFCModule7.TabIndex = 2;
            // 
            // ucSetMFCModule8
            // 
            this.ucSetMFCModule8.Location = new System.Drawing.Point(770, 166);
            this.ucSetMFCModule8.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ucSetMFCModule8.Name = "ucSetMFCModule8";
            this.ucSetMFCModule8.Size = new System.Drawing.Size(248, 160);
            this.ucSetMFCModule8.TabIndex = 3;
            // 
            // ucSetMFCModule9
            // 
            this.ucSetMFCModule9.Location = new System.Drawing.Point(0, 324);
            this.ucSetMFCModule9.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ucSetMFCModule9.Name = "ucSetMFCModule9";
            this.ucSetMFCModule9.Size = new System.Drawing.Size(248, 160);
            this.ucSetMFCModule9.TabIndex = 0;
            // 
            // ucSetMFCModule10
            // 
            this.ucSetMFCModule10.Location = new System.Drawing.Point(256, 324);
            this.ucSetMFCModule10.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ucSetMFCModule10.Name = "ucSetMFCModule10";
            this.ucSetMFCModule10.Size = new System.Drawing.Size(248, 160);
            this.ucSetMFCModule10.TabIndex = 1;
            // 
            // ucSetMFCModule11
            // 
            this.ucSetMFCModule11.Location = new System.Drawing.Point(513, 324);
            this.ucSetMFCModule11.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ucSetMFCModule11.Name = "ucSetMFCModule11";
            this.ucSetMFCModule11.Size = new System.Drawing.Size(248, 160);
            this.ucSetMFCModule11.TabIndex = 2;
            // 
            // ucSetMFCModule12
            // 
            this.ucSetMFCModule12.Location = new System.Drawing.Point(770, 324);
            this.ucSetMFCModule12.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ucSetMFCModule12.Name = "ucSetMFCModule12";
            this.ucSetMFCModule12.Size = new System.Drawing.Size(248, 160);
            this.ucSetMFCModule12.TabIndex = 3;
            // 
            // label27
            // 
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label27.Dock = System.Windows.Forms.DockStyle.Top;
            this.label27.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(0, 0);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(1150, 2);
            this.label27.TabIndex = 4;
            // 
            // UCSetMFC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label27);
            this.Controls.Add(this.ucSetMFCModule12);
            this.Controls.Add(this.ucSetMFCModule8);
            this.Controls.Add(this.ucSetMFCModule4);
            this.Controls.Add(this.ucSetMFCModule11);
            this.Controls.Add(this.ucSetMFCModule7);
            this.Controls.Add(this.ucSetMFCModule3);
            this.Controls.Add(this.ucSetMFCModule10);
            this.Controls.Add(this.ucSetMFCModule6);
            this.Controls.Add(this.ucSetMFCModule2);
            this.Controls.Add(this.ucSetMFCModule9);
            this.Controls.Add(this.ucSetMFCModule5);
            this.Controls.Add(this.ucSetMFCModule1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "UCSetMFC";
            this.Size = new System.Drawing.Size(1150, 867);
            this.ResumeLayout(false);

        }

        #endregion

        private Common.UCSetMFCModule ucSetMFCModule1;
        private Common.UCSetMFCModule ucSetMFCModule2;
        private Common.UCSetMFCModule ucSetMFCModule3;
        private Common.UCSetMFCModule ucSetMFCModule4;
        private Common.UCSetMFCModule ucSetMFCModule5;
        private Common.UCSetMFCModule ucSetMFCModule6;
        private Common.UCSetMFCModule ucSetMFCModule7;
        private Common.UCSetMFCModule ucSetMFCModule8;
        private Common.UCSetMFCModule ucSetMFCModule9;
        private Common.UCSetMFCModule ucSetMFCModule10;
        private Common.UCSetMFCModule ucSetMFCModule11;
        private Common.UCSetMFCModule ucSetMFCModule12;
        private System.Windows.Forms.Label label27;
    }
}

﻿namespace Test.View.Tube
{
    partial class UCRoad
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.ucConduit34 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit13 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit56 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit31 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit44 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit5 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit2 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit7 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit33 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit30 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit54 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit52 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit6 = new HZH_Controls.Controls.UCConduit();
            this.ucValve8 = new HZH_Controls.Controls.UCValve();
            this.ucConduit27 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit29 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit28 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit26 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit24 = new HZH_Controls.Controls.UCConduit();
            this.ucValve1 = new HZH_Controls.Controls.UCValve();
            this.ucConduit16 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit21 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit10 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit11 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit18 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit19 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit14 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit9 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit50 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit42 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit49 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit40 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit51 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit48 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit47 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit36 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit15 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit41 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit39 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit37 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit35 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit22 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit1 = new HZH_Controls.Controls.UCConduit();
            this.ucValve7 = new HZH_Controls.Controls.UCValve();
            this.ucValve6 = new HZH_Controls.Controls.UCValve();
            this.ucValve5 = new HZH_Controls.Controls.UCValve();
            this.ucValve2 = new HZH_Controls.Controls.UCValve();
            this.ucValve11 = new HZH_Controls.Controls.UCValve();
            this.ucValve10 = new HZH_Controls.Controls.UCValve();
            this.ucValve9 = new HZH_Controls.Controls.UCValve();
            this.ucValve4 = new HZH_Controls.Controls.UCValve();
            this.ucValve12 = new HZH_Controls.Controls.UCValve();
            this.ucValve3 = new HZH_Controls.Controls.UCValve();
            this.ucConduit25 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit32 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit53 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit55 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit3 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit46 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit45 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit20 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit8 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit4 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit43 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit17 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit23 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit12 = new HZH_Controls.Controls.UCConduit();
            this.ucPond2 = new HZH_Controls.Controls.UCPond();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.ucSignalLamp3 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp1 = new HZH_Controls.Controls.UCSignalLamp();
            this.textBox6 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label1.Location = new System.Drawing.Point(22, 3);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(13, 5);
            this.label1.TabIndex = 45;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label2.Location = new System.Drawing.Point(187, 3);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 5);
            this.label2.TabIndex = 45;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label3.Location = new System.Drawing.Point(395, 3);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 5);
            this.label3.TabIndex = 45;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = global::Test.Properties.Resources.单向阀向上;
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox7.Location = new System.Drawing.Point(106, 331);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(39, 36);
            this.pictureBox7.TabIndex = 44;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox6.Image = global::Test.Properties.Resources.流量计蓝1;
            this.pictureBox6.Location = new System.Drawing.Point(71, 327);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(20, 39);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 44;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox9.Image = global::Test.Properties.Resources.流量计蓝1;
            this.pictureBox9.Location = new System.Drawing.Point(323, 35);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(20, 39);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 44;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox8.Image = global::Test.Properties.Resources.流量计蓝1;
            this.pictureBox8.Location = new System.Drawing.Point(255, 35);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(20, 39);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 44;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Image = global::Test.Properties.Resources.流量计蓝1;
            this.pictureBox2.Location = new System.Drawing.Point(185, 35);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(20, 39);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 44;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Image = global::Test.Properties.Resources.流量计蓝1;
            this.pictureBox1.Location = new System.Drawing.Point(18, 35);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(20, 39);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 44;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = global::Test.Properties.Resources.单向阀向上;
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox5.Location = new System.Drawing.Point(63, 235);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(39, 36);
            this.pictureBox5.TabIndex = 44;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox10.Image = global::Test.Properties.Resources.压力计;
            this.pictureBox10.Location = new System.Drawing.Point(43, 158);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(37, 23);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 44;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::Test.Properties.Resources.单向阀向上;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox4.Location = new System.Drawing.Point(63, 136);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(39, 36);
            this.pictureBox4.TabIndex = 44;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox11.Image = global::Test.Properties.Resources.压力计;
            this.pictureBox11.Location = new System.Drawing.Point(154, 144);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(37, 23);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 44;
            this.pictureBox11.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(208, 65);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 17);
            this.label6.TabIndex = 64;
            this.label6.Text = "000.0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(41, 65);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 17);
            this.label10.TabIndex = 64;
            this.label10.Text = "000.0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(276, 65);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(39, 17);
            this.label13.TabIndex = 64;
            this.label13.Text = "000.0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(27, 365);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(39, 17);
            this.label16.TabIndex = 64;
            this.label16.Text = "000.0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(346, 65);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(39, 17);
            this.label19.TabIndex = 64;
            this.label19.Text = "000.0";
            // 
            // ucConduit34
            // 
            this.ucConduit34.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit34.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit34.ConduitWidth = 50;
            this.ucConduit34.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit34.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit34.LiquidSpeed = 100;
            this.ucConduit34.Location = new System.Drawing.Point(23, 455);
            this.ucConduit34.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit34.Name = "ucConduit34";
            this.ucConduit34.Size = new System.Drawing.Size(93, 5);
            this.ucConduit34.TabIndex = 43;
            // 
            // ucConduit13
            // 
            this.ucConduit13.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit13.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit13.ConduitWidth = 50;
            this.ucConduit13.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit13.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit13.LiquidSpeed = 100;
            this.ucConduit13.Location = new System.Drawing.Point(23, 437);
            this.ucConduit13.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit13.Name = "ucConduit13";
            this.ucConduit13.Size = new System.Drawing.Size(93, 5);
            this.ucConduit13.TabIndex = 43;
            // 
            // ucConduit56
            // 
            this.ucConduit56.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit56.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit56.ConduitWidth = 50;
            this.ucConduit56.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit56.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit56.LiquidSpeed = 100;
            this.ucConduit56.Location = new System.Drawing.Point(179, 455);
            this.ucConduit56.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit56.Name = "ucConduit56";
            this.ucConduit56.Size = new System.Drawing.Size(266, 5);
            this.ucConduit56.TabIndex = 43;
            // 
            // ucConduit31
            // 
            this.ucConduit31.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit31.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit31.ConduitWidth = 50;
            this.ucConduit31.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit31.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit31.LiquidSpeed = 100;
            this.ucConduit31.Location = new System.Drawing.Point(130, 437);
            this.ucConduit31.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit31.Name = "ucConduit31";
            this.ucConduit31.Size = new System.Drawing.Size(136, 5);
            this.ucConduit31.TabIndex = 43;
            // 
            // ucConduit44
            // 
            this.ucConduit44.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit44.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit44.ConduitWidth = 50;
            this.ucConduit44.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit44.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit44.LiquidSpeed = 100;
            this.ucConduit44.Location = new System.Drawing.Point(23, 472);
            this.ucConduit44.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit44.Name = "ucConduit44";
            this.ucConduit44.Size = new System.Drawing.Size(402, 5);
            this.ucConduit44.TabIndex = 43;
            // 
            // ucConduit5
            // 
            this.ucConduit5.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit5.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit5.ConduitWidth = 50;
            this.ucConduit5.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit5.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit5.LiquidSpeed = 100;
            this.ucConduit5.Location = new System.Drawing.Point(88, 420);
            this.ucConduit5.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit5.Name = "ucConduit5";
            this.ucConduit5.Size = new System.Drawing.Size(29, 5);
            this.ucConduit5.TabIndex = 43;
            // 
            // ucConduit2
            // 
            this.ucConduit2.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit2.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit2.ConduitWidth = 50;
            this.ucConduit2.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit2.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit2.LiquidSpeed = 100;
            this.ucConduit2.Location = new System.Drawing.Point(23, 420);
            this.ucConduit2.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit2.Name = "ucConduit2";
            this.ucConduit2.Size = new System.Drawing.Size(50, 5);
            this.ucConduit2.TabIndex = 43;
            // 
            // ucConduit7
            // 
            this.ucConduit7.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit7.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Down_Down;
            this.ucConduit7.ConduitWidth = 50;
            this.ucConduit7.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit7.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit7.LiquidSpeed = 100;
            this.ucConduit7.Location = new System.Drawing.Point(66, 415);
            this.ucConduit7.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit7.Name = "ucConduit7";
            this.ucConduit7.Size = new System.Drawing.Size(28, 5);
            this.ucConduit7.TabIndex = 41;
            // 
            // ucConduit33
            // 
            this.ucConduit33.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit33.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Down_Down;
            this.ucConduit33.ConduitWidth = 50;
            this.ucConduit33.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit33.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit33.LiquidSpeed = 100;
            this.ucConduit33.Location = new System.Drawing.Point(109, 450);
            this.ucConduit33.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit33.Name = "ucConduit33";
            this.ucConduit33.Size = new System.Drawing.Size(28, 5);
            this.ucConduit33.TabIndex = 41;
            // 
            // ucConduit30
            // 
            this.ucConduit30.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit30.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Down_Down;
            this.ucConduit30.ConduitWidth = 50;
            this.ucConduit30.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit30.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit30.LiquidSpeed = 100;
            this.ucConduit30.Location = new System.Drawing.Point(109, 432);
            this.ucConduit30.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit30.Name = "ucConduit30";
            this.ucConduit30.Size = new System.Drawing.Size(28, 5);
            this.ucConduit30.TabIndex = 41;
            // 
            // ucConduit54
            // 
            this.ucConduit54.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit54.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Down_Down;
            this.ucConduit54.ConduitWidth = 50;
            this.ucConduit54.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit54.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit54.LiquidSpeed = 100;
            this.ucConduit54.Location = new System.Drawing.Point(249, 416);
            this.ucConduit54.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit54.Name = "ucConduit54";
            this.ucConduit54.Size = new System.Drawing.Size(28, 5);
            this.ucConduit54.TabIndex = 41;
            // 
            // ucConduit52
            // 
            this.ucConduit52.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit52.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Down_Down;
            this.ucConduit52.ConduitWidth = 50;
            this.ucConduit52.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit52.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit52.LiquidSpeed = 100;
            this.ucConduit52.Location = new System.Drawing.Point(179, 416);
            this.ucConduit52.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit52.Name = "ucConduit52";
            this.ucConduit52.Size = new System.Drawing.Size(28, 5);
            this.ucConduit52.TabIndex = 41;
            // 
            // ucConduit6
            // 
            this.ucConduit6.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit6.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Down_Down;
            this.ucConduit6.ConduitWidth = 50;
            this.ucConduit6.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit6.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit6.LiquidSpeed = 100;
            this.ucConduit6.Location = new System.Drawing.Point(109, 416);
            this.ucConduit6.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit6.Name = "ucConduit6";
            this.ucConduit6.Size = new System.Drawing.Size(28, 5);
            this.ucConduit6.TabIndex = 41;
            // 
            // ucValve8
            // 
            this.ucValve8.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve8.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve8.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve8.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucValve8.LiquidSpeed = 100;
            this.ucValve8.Location = new System.Drawing.Point(58, 378);
            this.ucValve8.Margin = new System.Windows.Forms.Padding(2);
            this.ucValve8.Name = "ucValve8";
            this.ucValve8.Opened = true;
            this.ucValve8.Size = new System.Drawing.Size(33, 27);
            this.ucValve8.SwitchColor = System.Drawing.Color.Black;
            this.ucValve8.TabIndex = 42;
            this.ucValve8.ValveColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve8.ValveStyle = HZH_Controls.Controls.ValveStyle.Vertical_Right;
            // 
            // ucConduit27
            // 
            this.ucConduit27.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit27.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit27.ConduitWidth = 50;
            this.ucConduit27.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit27.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit27.LiquidSpeed = 100;
            this.ucConduit27.Location = new System.Drawing.Point(77, 397);
            this.ucConduit27.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit27.Name = "ucConduit27";
            this.ucConduit27.Size = new System.Drawing.Size(5, 45);
            this.ucConduit27.TabIndex = 46;
            // 
            // ucConduit29
            // 
            this.ucConduit29.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit29.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit29.ConduitWidth = 50;
            this.ucConduit29.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit29.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit29.LiquidSpeed = 100;
            this.ucConduit29.Location = new System.Drawing.Point(121, 357);
            this.ucConduit29.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit29.Name = "ucConduit29";
            this.ucConduit29.Size = new System.Drawing.Size(5, 119);
            this.ucConduit29.TabIndex = 46;
            // 
            // ucConduit28
            // 
            this.ucConduit28.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit28.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit28.ConduitWidth = 50;
            this.ucConduit28.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit28.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit28.LiquidSpeed = 100;
            this.ucConduit28.Location = new System.Drawing.Point(120, 306);
            this.ucConduit28.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit28.Name = "ucConduit28";
            this.ucConduit28.Size = new System.Drawing.Size(5, 25);
            this.ucConduit28.TabIndex = 46;
            // 
            // ucConduit26
            // 
            this.ucConduit26.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit26.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit26.ConduitWidth = 50;
            this.ucConduit26.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit26.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit26.LiquidSpeed = 100;
            this.ucConduit26.Location = new System.Drawing.Point(77, 363);
            this.ucConduit26.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit26.Name = "ucConduit26";
            this.ucConduit26.Size = new System.Drawing.Size(5, 25);
            this.ucConduit26.TabIndex = 46;
            // 
            // ucConduit24
            // 
            this.ucConduit24.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit24.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit24.ConduitWidth = 50;
            this.ucConduit24.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit24.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit24.LiquidSpeed = 100;
            this.ucConduit24.Location = new System.Drawing.Point(77, 306);
            this.ucConduit24.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit24.Name = "ucConduit24";
            this.ucConduit24.Size = new System.Drawing.Size(5, 25);
            this.ucConduit24.TabIndex = 46;
            // 
            // ucValve1
            // 
            this.ucValve1.AsisBottomColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve1.AxisColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve1.LiquidColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve1.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucValve1.LiquidSpeed = 100;
            this.ucValve1.Location = new System.Drawing.Point(5, 94);
            this.ucValve1.Margin = new System.Windows.Forms.Padding(2);
            this.ucValve1.Name = "ucValve1";
            this.ucValve1.Opened = true;
            this.ucValve1.Size = new System.Drawing.Size(33, 27);
            this.ucValve1.SwitchColor = System.Drawing.Color.Black;
            this.ucValve1.TabIndex = 42;
            this.ucValve1.ValveColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve1.ValveStyle = HZH_Controls.Controls.ValveStyle.Vertical_Right;
            // 
            // ucConduit16
            // 
            this.ucConduit16.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit16.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_Down;
            this.ucConduit16.ConduitWidth = 50;
            this.ucConduit16.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit16.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit16.LiquidSpeed = 100;
            this.ucConduit16.Location = new System.Drawing.Point(77, 204);
            this.ucConduit16.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit16.Name = "ucConduit16";
            this.ucConduit16.Size = new System.Drawing.Size(35, 5);
            this.ucConduit16.TabIndex = 47;
            // 
            // ucConduit21
            // 
            this.ucConduit21.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit21.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_Down;
            this.ucConduit21.ConduitWidth = 50;
            this.ucConduit21.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit21.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit21.LiquidSpeed = 100;
            this.ucConduit21.Location = new System.Drawing.Point(79, 271);
            this.ucConduit21.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit21.Name = "ucConduit21";
            this.ucConduit21.Size = new System.Drawing.Size(47, 5);
            this.ucConduit21.TabIndex = 47;
            // 
            // ucConduit10
            // 
            this.ucConduit10.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit10.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_Down;
            this.ucConduit10.ConduitWidth = 50;
            this.ucConduit10.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit10.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit10.LiquidSpeed = 100;
            this.ucConduit10.Location = new System.Drawing.Point(79, 192);
            this.ucConduit10.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit10.Name = "ucConduit10";
            this.ucConduit10.Size = new System.Drawing.Size(49, 5);
            this.ucConduit10.TabIndex = 47;
            // 
            // ucConduit11
            // 
            this.ucConduit11.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit11.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit11.ConduitWidth = 50;
            this.ucConduit11.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit11.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit11.LiquidSpeed = 100;
            this.ucConduit11.Location = new System.Drawing.Point(106, 206);
            this.ucConduit11.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit11.Name = "ucConduit11";
            this.ucConduit11.Size = new System.Drawing.Size(5, 25);
            this.ucConduit11.TabIndex = 46;
            // 
            // ucConduit18
            // 
            this.ucConduit18.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit18.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit18.ConduitWidth = 50;
            this.ucConduit18.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit18.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit18.LiquidSpeed = 100;
            this.ucConduit18.Location = new System.Drawing.Point(77, 204);
            this.ucConduit18.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit18.Name = "ucConduit18";
            this.ucConduit18.Size = new System.Drawing.Size(5, 31);
            this.ucConduit18.TabIndex = 46;
            // 
            // ucConduit19
            // 
            this.ucConduit19.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit19.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit19.ConduitWidth = 50;
            this.ucConduit19.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit19.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit19.LiquidSpeed = 100;
            this.ucConduit19.Location = new System.Drawing.Point(77, 262);
            this.ucConduit19.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit19.Name = "ucConduit19";
            this.ucConduit19.Size = new System.Drawing.Size(5, 27);
            this.ucConduit19.TabIndex = 46;
            // 
            // ucConduit14
            // 
            this.ucConduit14.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit14.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit14.ConduitWidth = 50;
            this.ucConduit14.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit14.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit14.LiquidSpeed = 100;
            this.ucConduit14.Location = new System.Drawing.Point(77, 164);
            this.ucConduit14.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit14.Name = "ucConduit14";
            this.ucConduit14.Size = new System.Drawing.Size(5, 33);
            this.ucConduit14.TabIndex = 46;
            // 
            // ucConduit9
            // 
            this.ucConduit9.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit9.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit9.ConduitWidth = 50;
            this.ucConduit9.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit9.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit9.LiquidSpeed = 100;
            this.ucConduit9.Location = new System.Drawing.Point(77, 118);
            this.ucConduit9.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit9.Name = "ucConduit9";
            this.ucConduit9.Size = new System.Drawing.Size(5, 19);
            this.ucConduit9.TabIndex = 46;
            // 
            // ucConduit50
            // 
            this.ucConduit50.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit50.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit50.ConduitWidth = 50;
            this.ucConduit50.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit50.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit50.LiquidSpeed = 100;
            this.ucConduit50.Location = new System.Drawing.Point(329, 118);
            this.ucConduit50.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit50.Name = "ucConduit50";
            this.ucConduit50.Size = new System.Drawing.Size(5, 307);
            this.ucConduit50.TabIndex = 46;
            // 
            // ucConduit42
            // 
            this.ucConduit42.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit42.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit42.ConduitWidth = 50;
            this.ucConduit42.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit42.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit42.LiquidSpeed = 100;
            this.ucConduit42.Location = new System.Drawing.Point(329, 71);
            this.ucConduit42.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit42.Name = "ucConduit42";
            this.ucConduit42.Size = new System.Drawing.Size(5, 33);
            this.ucConduit42.TabIndex = 46;
            // 
            // ucConduit49
            // 
            this.ucConduit49.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit49.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit49.ConduitWidth = 50;
            this.ucConduit49.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit49.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit49.LiquidSpeed = 100;
            this.ucConduit49.Location = new System.Drawing.Point(261, 118);
            this.ucConduit49.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit49.Name = "ucConduit49";
            this.ucConduit49.Size = new System.Drawing.Size(5, 321);
            this.ucConduit49.TabIndex = 46;
            // 
            // ucConduit40
            // 
            this.ucConduit40.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit40.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit40.ConduitWidth = 50;
            this.ucConduit40.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit40.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit40.LiquidSpeed = 100;
            this.ucConduit40.Location = new System.Drawing.Point(261, 71);
            this.ucConduit40.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit40.Name = "ucConduit40";
            this.ucConduit40.Size = new System.Drawing.Size(5, 33);
            this.ucConduit40.TabIndex = 46;
            // 
            // ucConduit51
            // 
            this.ucConduit51.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit51.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit51.ConduitWidth = 50;
            this.ucConduit51.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit51.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit51.LiquidSpeed = 100;
            this.ucConduit51.Location = new System.Drawing.Point(440, 119);
            this.ucConduit51.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit51.Name = "ucConduit51";
            this.ucConduit51.Size = new System.Drawing.Size(5, 349);
            this.ucConduit51.TabIndex = 46;
            // 
            // ucConduit48
            // 
            this.ucConduit48.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit48.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit48.ConduitWidth = 50;
            this.ucConduit48.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit48.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit48.LiquidSpeed = 100;
            this.ucConduit48.Location = new System.Drawing.Point(399, 118);
            this.ucConduit48.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit48.Name = "ucConduit48";
            this.ucConduit48.Size = new System.Drawing.Size(5, 307);
            this.ucConduit48.TabIndex = 46;
            // 
            // ucConduit47
            // 
            this.ucConduit47.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit47.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit47.ConduitWidth = 50;
            this.ucConduit47.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit47.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit47.LiquidSpeed = 100;
            this.ucConduit47.Location = new System.Drawing.Point(191, 116);
            this.ucConduit47.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit47.Name = "ucConduit47";
            this.ucConduit47.Size = new System.Drawing.Size(5, 325);
            this.ucConduit47.TabIndex = 46;
            // 
            // ucConduit36
            // 
            this.ucConduit36.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit36.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit36.ConduitWidth = 50;
            this.ucConduit36.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit36.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit36.LiquidSpeed = 100;
            this.ucConduit36.Location = new System.Drawing.Point(191, 71);
            this.ucConduit36.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit36.Name = "ucConduit36";
            this.ucConduit36.Size = new System.Drawing.Size(5, 27);
            this.ucConduit36.TabIndex = 46;
            // 
            // ucConduit15
            // 
            this.ucConduit15.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit15.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit15.ConduitWidth = 50;
            this.ucConduit15.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit15.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit15.LiquidSpeed = 100;
            this.ucConduit15.Location = new System.Drawing.Point(25, 71);
            this.ucConduit15.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit15.Name = "ucConduit15";
            this.ucConduit15.Size = new System.Drawing.Size(5, 33);
            this.ucConduit15.TabIndex = 46;
            // 
            // ucConduit41
            // 
            this.ucConduit41.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit41.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit41.ConduitWidth = 50;
            this.ucConduit41.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit41.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit41.LiquidSpeed = 100;
            this.ucConduit41.Location = new System.Drawing.Point(329, 21);
            this.ucConduit41.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit41.Name = "ucConduit41";
            this.ucConduit41.Size = new System.Drawing.Size(5, 16);
            this.ucConduit41.TabIndex = 46;
            // 
            // ucConduit39
            // 
            this.ucConduit39.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit39.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit39.ConduitWidth = 50;
            this.ucConduit39.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit39.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit39.LiquidSpeed = 100;
            this.ucConduit39.Location = new System.Drawing.Point(261, 21);
            this.ucConduit39.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit39.Name = "ucConduit39";
            this.ucConduit39.Size = new System.Drawing.Size(5, 16);
            this.ucConduit39.TabIndex = 46;
            // 
            // ucConduit37
            // 
            this.ucConduit37.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit37.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit37.ConduitWidth = 50;
            this.ucConduit37.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit37.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit37.LiquidSpeed = 100;
            this.ucConduit37.Location = new System.Drawing.Point(399, 3);
            this.ucConduit37.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit37.Name = "ucConduit37";
            this.ucConduit37.Size = new System.Drawing.Size(5, 100);
            this.ucConduit37.TabIndex = 46;
            // 
            // ucConduit35
            // 
            this.ucConduit35.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit35.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit35.ConduitWidth = 50;
            this.ucConduit35.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit35.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit35.LiquidSpeed = 100;
            this.ucConduit35.Location = new System.Drawing.Point(191, 3);
            this.ucConduit35.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit35.Name = "ucConduit35";
            this.ucConduit35.Size = new System.Drawing.Size(5, 33);
            this.ucConduit35.TabIndex = 46;
            // 
            // ucConduit22
            // 
            this.ucConduit22.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit22.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit22.ConduitWidth = 50;
            this.ucConduit22.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit22.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit22.LiquidSpeed = 100;
            this.ucConduit22.Location = new System.Drawing.Point(26, 3);
            this.ucConduit22.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit22.Name = "ucConduit22";
            this.ucConduit22.Size = new System.Drawing.Size(5, 33);
            this.ucConduit22.TabIndex = 46;
            // 
            // ucConduit1
            // 
            this.ucConduit1.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit1.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit1.ConduitWidth = 100;
            this.ucConduit1.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit1.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit1.LiquidSpeed = 100;
            this.ucConduit1.Location = new System.Drawing.Point(25, 118);
            this.ucConduit1.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit1.Name = "ucConduit1";
            this.ucConduit1.Size = new System.Drawing.Size(5, 201);
            this.ucConduit1.TabIndex = 43;
            // 
            // ucValve7
            // 
            this.ucValve7.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve7.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve7.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve7.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucValve7.LiquidSpeed = 100;
            this.ucValve7.Location = new System.Drawing.Point(101, 284);
            this.ucValve7.Margin = new System.Windows.Forms.Padding(2);
            this.ucValve7.Name = "ucValve7";
            this.ucValve7.Opened = true;
            this.ucValve7.Size = new System.Drawing.Size(33, 27);
            this.ucValve7.SwitchColor = System.Drawing.Color.Black;
            this.ucValve7.TabIndex = 42;
            this.ucValve7.ValveColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve7.ValveStyle = HZH_Controls.Controls.ValveStyle.Vertical_Right;
            // 
            // ucValve6
            // 
            this.ucValve6.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve6.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve6.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve6.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucValve6.LiquidSpeed = 100;
            this.ucValve6.Location = new System.Drawing.Point(58, 284);
            this.ucValve6.Margin = new System.Windows.Forms.Padding(2);
            this.ucValve6.Name = "ucValve6";
            this.ucValve6.Opened = true;
            this.ucValve6.Size = new System.Drawing.Size(33, 27);
            this.ucValve6.SwitchColor = System.Drawing.Color.Black;
            this.ucValve6.TabIndex = 42;
            this.ucValve6.ValveColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve6.ValveStyle = HZH_Controls.Controls.ValveStyle.Vertical_Right;
            // 
            // ucValve5
            // 
            this.ucValve5.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve5.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve5.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve5.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucValve5.LiquidSpeed = 100;
            this.ucValve5.Location = new System.Drawing.Point(35, 185);
            this.ucValve5.Margin = new System.Windows.Forms.Padding(2);
            this.ucValve5.Name = "ucValve5";
            this.ucValve5.Opened = true;
            this.ucValve5.Size = new System.Drawing.Size(33, 27);
            this.ucValve5.SwitchColor = System.Drawing.Color.Black;
            this.ucValve5.TabIndex = 42;
            this.ucValve5.ValveColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve5.ValveStyle = HZH_Controls.Controls.ValveStyle.Vertical_Right;
            // 
            // ucValve2
            // 
            this.ucValve2.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve2.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve2.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve2.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucValve2.LiquidSpeed = 100;
            this.ucValve2.Location = new System.Drawing.Point(151, 439);
            this.ucValve2.Margin = new System.Windows.Forms.Padding(2);
            this.ucValve2.Name = "ucValve2";
            this.ucValve2.Opened = true;
            this.ucValve2.Size = new System.Drawing.Size(33, 27);
            this.ucValve2.SwitchColor = System.Drawing.Color.Black;
            this.ucValve2.TabIndex = 42;
            this.ucValve2.ValveColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve2.ValveStyle = HZH_Controls.Controls.ValveStyle.Horizontal_Top;
            // 
            // ucValve11
            // 
            this.ucValve11.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve11.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve11.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve11.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucValve11.LiquidSpeed = 100;
            this.ucValve11.Location = new System.Drawing.Point(379, 95);
            this.ucValve11.Margin = new System.Windows.Forms.Padding(2);
            this.ucValve11.Name = "ucValve11";
            this.ucValve11.Opened = true;
            this.ucValve11.Size = new System.Drawing.Size(33, 27);
            this.ucValve11.SwitchColor = System.Drawing.Color.Black;
            this.ucValve11.TabIndex = 42;
            this.ucValve11.ValveColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve11.ValveStyle = HZH_Controls.Controls.ValveStyle.Vertical_Right;
            // 
            // ucValve10
            // 
            this.ucValve10.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve10.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve10.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve10.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucValve10.LiquidSpeed = 100;
            this.ucValve10.Location = new System.Drawing.Point(309, 95);
            this.ucValve10.Margin = new System.Windows.Forms.Padding(2);
            this.ucValve10.Name = "ucValve10";
            this.ucValve10.Opened = true;
            this.ucValve10.Size = new System.Drawing.Size(33, 27);
            this.ucValve10.SwitchColor = System.Drawing.Color.Black;
            this.ucValve10.TabIndex = 42;
            this.ucValve10.ValveColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve10.ValveStyle = HZH_Controls.Controls.ValveStyle.Vertical_Right;
            // 
            // ucValve9
            // 
            this.ucValve9.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve9.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve9.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve9.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucValve9.LiquidSpeed = 100;
            this.ucValve9.Location = new System.Drawing.Point(241, 94);
            this.ucValve9.Margin = new System.Windows.Forms.Padding(2);
            this.ucValve9.Name = "ucValve9";
            this.ucValve9.Opened = true;
            this.ucValve9.Size = new System.Drawing.Size(33, 27);
            this.ucValve9.SwitchColor = System.Drawing.Color.Black;
            this.ucValve9.TabIndex = 42;
            this.ucValve9.ValveColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve9.ValveStyle = HZH_Controls.Controls.ValveStyle.Vertical_Right;
            // 
            // ucValve4
            // 
            this.ucValve4.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve4.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve4.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve4.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucValve4.LiquidSpeed = 100;
            this.ucValve4.Location = new System.Drawing.Point(171, 95);
            this.ucValve4.Margin = new System.Windows.Forms.Padding(2);
            this.ucValve4.Name = "ucValve4";
            this.ucValve4.Opened = true;
            this.ucValve4.Size = new System.Drawing.Size(33, 27);
            this.ucValve4.SwitchColor = System.Drawing.Color.Black;
            this.ucValve4.TabIndex = 42;
            this.ucValve4.ValveColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve4.ValveStyle = HZH_Controls.Controls.ValveStyle.Vertical_Right;
            // 
            // ucValve12
            // 
            this.ucValve12.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve12.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve12.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve12.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucValve12.LiquidSpeed = 100;
            this.ucValve12.Location = new System.Drawing.Point(420, 95);
            this.ucValve12.Margin = new System.Windows.Forms.Padding(2);
            this.ucValve12.Name = "ucValve12";
            this.ucValve12.Opened = true;
            this.ucValve12.Size = new System.Drawing.Size(33, 27);
            this.ucValve12.SwitchColor = System.Drawing.Color.Black;
            this.ucValve12.TabIndex = 42;
            this.ucValve12.ValveColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve12.ValveStyle = HZH_Controls.Controls.ValveStyle.Vertical_Right;
            // 
            // ucValve3
            // 
            this.ucValve3.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve3.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve3.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve3.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucValve3.LiquidSpeed = 100;
            this.ucValve3.Location = new System.Drawing.Point(57, 95);
            this.ucValve3.Margin = new System.Windows.Forms.Padding(2);
            this.ucValve3.Name = "ucValve3";
            this.ucValve3.Opened = true;
            this.ucValve3.Size = new System.Drawing.Size(33, 27);
            this.ucValve3.SwitchColor = System.Drawing.Color.Black;
            this.ucValve3.TabIndex = 42;
            this.ucValve3.ValveColor = System.Drawing.Color.LightSkyBlue;
            this.ucValve3.ValveStyle = HZH_Controls.Controls.ValveStyle.Vertical_Right;
            // 
            // ucConduit25
            // 
            this.ucConduit25.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit25.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Up_None;
            this.ucConduit25.ConduitWidth = 50;
            this.ucConduit25.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit25.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit25.LiquidSpeed = 100;
            this.ucConduit25.Location = new System.Drawing.Point(23, 316);
            this.ucConduit25.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit25.Name = "ucConduit25";
            this.ucConduit25.Size = new System.Drawing.Size(58, 5);
            this.ucConduit25.TabIndex = 43;
            // 
            // ucConduit32
            // 
            this.ucConduit32.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit32.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit32.ConduitWidth = 50;
            this.ucConduit32.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit32.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit32.LiquidSpeed = 100;
            this.ucConduit32.Location = new System.Drawing.Point(131, 455);
            this.ucConduit32.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit32.Name = "ucConduit32";
            this.ucConduit32.Size = new System.Drawing.Size(29, 5);
            this.ucConduit32.TabIndex = 43;
            // 
            // ucConduit53
            // 
            this.ucConduit53.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit53.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit53.ConduitWidth = 50;
            this.ucConduit53.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit53.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit53.LiquidSpeed = 100;
            this.ucConduit53.Location = new System.Drawing.Point(200, 421);
            this.ucConduit53.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit53.Name = "ucConduit53";
            this.ucConduit53.Size = new System.Drawing.Size(58, 5);
            this.ucConduit53.TabIndex = 43;
            // 
            // ucConduit55
            // 
            this.ucConduit55.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit55.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit55.ConduitWidth = 50;
            this.ucConduit55.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit55.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit55.LiquidSpeed = 100;
            this.ucConduit55.Location = new System.Drawing.Point(270, 421);
            this.ucConduit55.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit55.Name = "ucConduit55";
            this.ucConduit55.Size = new System.Drawing.Size(133, 5);
            this.ucConduit55.TabIndex = 43;
            // 
            // ucConduit3
            // 
            this.ucConduit3.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit3.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit3.ConduitWidth = 50;
            this.ucConduit3.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit3.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit3.LiquidSpeed = 100;
            this.ucConduit3.Location = new System.Drawing.Point(131, 421);
            this.ucConduit3.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit3.Name = "ucConduit3";
            this.ucConduit3.Size = new System.Drawing.Size(57, 5);
            this.ucConduit3.TabIndex = 43;
            // 
            // ucConduit46
            // 
            this.ucConduit46.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit46.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit46.ConduitWidth = 50;
            this.ucConduit46.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit46.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit46.LiquidSpeed = 100;
            this.ucConduit46.Location = new System.Drawing.Point(399, 80);
            this.ucConduit46.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit46.Name = "ucConduit46";
            this.ucConduit46.Size = new System.Drawing.Size(43, 5);
            this.ucConduit46.TabIndex = 43;
            // 
            // ucConduit45
            // 
            this.ucConduit45.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit45.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_Left_None;
            this.ucConduit45.ConduitWidth = 50;
            this.ucConduit45.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit45.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit45.LiquidSpeed = 100;
            this.ucConduit45.Location = new System.Drawing.Point(440, 79);
            this.ucConduit45.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit45.Name = "ucConduit45";
            this.ucConduit45.Size = new System.Drawing.Size(5, 25);
            this.ucConduit45.TabIndex = 41;
            // 
            // ucConduit20
            // 
            this.ucConduit20.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit20.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit20.ConduitWidth = 50;
            this.ucConduit20.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit20.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit20.LiquidSpeed = 100;
            this.ucConduit20.Location = new System.Drawing.Point(25, 80);
            this.ucConduit20.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit20.Name = "ucConduit20";
            this.ucConduit20.Size = new System.Drawing.Size(55, 5);
            this.ucConduit20.TabIndex = 43;
            // 
            // ucConduit8
            // 
            this.ucConduit8.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit8.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_Left_None;
            this.ucConduit8.ConduitWidth = 50;
            this.ucConduit8.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit8.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit8.LiquidSpeed = 100;
            this.ucConduit8.Location = new System.Drawing.Point(77, 79);
            this.ucConduit8.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit8.Name = "ucConduit8";
            this.ucConduit8.Size = new System.Drawing.Size(5, 25);
            this.ucConduit8.TabIndex = 41;
            // 
            // ucConduit4
            // 
            this.ucConduit4.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit4.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Up_None;
            this.ucConduit4.ConduitWidth = 50;
            this.ucConduit4.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit4.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit4.LiquidSpeed = 100;
            this.ucConduit4.Location = new System.Drawing.Point(53, 212);
            this.ucConduit4.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit4.Name = "ucConduit4";
            this.ucConduit4.Size = new System.Drawing.Size(28, 5);
            this.ucConduit4.TabIndex = 41;
            // 
            // ucConduit43
            // 
            this.ucConduit43.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit43.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Down_None;
            this.ucConduit43.ConduitWidth = 50;
            this.ucConduit43.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit43.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit43.LiquidSpeed = 100;
            this.ucConduit43.Location = new System.Drawing.Point(260, 16);
            this.ucConduit43.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit43.Name = "ucConduit43";
            this.ucConduit43.Size = new System.Drawing.Size(141, 5);
            this.ucConduit43.TabIndex = 41;
            // 
            // ucConduit17
            // 
            this.ucConduit17.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit17.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Down_None;
            this.ucConduit17.ConduitWidth = 50;
            this.ucConduit17.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit17.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit17.LiquidSpeed = 100;
            this.ucConduit17.Location = new System.Drawing.Point(53, 181);
            this.ucConduit17.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit17.Name = "ucConduit17";
            this.ucConduit17.Size = new System.Drawing.Size(28, 5);
            this.ucConduit17.TabIndex = 41;
            // 
            // ucConduit23
            // 
            this.ucConduit23.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit23.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit23.ConduitWidth = 50;
            this.ucConduit23.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit23.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit23.LiquidSpeed = 100;
            this.ucConduit23.Location = new System.Drawing.Point(120, 275);
            this.ucConduit23.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit23.Name = "ucConduit23";
            this.ucConduit23.Size = new System.Drawing.Size(5, 14);
            this.ucConduit23.TabIndex = 46;
            // 
            // ucConduit12
            // 
            this.ucConduit12.ConduitColor = System.Drawing.Color.LightSkyBlue;
            this.ucConduit12.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit12.ConduitWidth = 50;
            this.ucConduit12.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit12.LiquidDirection = HZH_Controls.Controls.LiquidDirection.None;
            this.ucConduit12.LiquidSpeed = 100;
            this.ucConduit12.Location = new System.Drawing.Point(122, 195);
            this.ucConduit12.Margin = new System.Windows.Forms.Padding(2);
            this.ucConduit12.Name = "ucConduit12";
            this.ucConduit12.Size = new System.Drawing.Size(5, 49);
            this.ucConduit12.TabIndex = 46;
            // 
            // ucPond2
            // 
            this.ucPond2.BackColor = System.Drawing.Color.Transparent;
            this.ucPond2.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucPond2.Location = new System.Drawing.Point(96, 217);
            this.ucPond2.Margin = new System.Windows.Forms.Padding(2);
            this.ucPond2.MaxValue = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.ucPond2.Name = "ucPond2";
            this.ucPond2.Size = new System.Drawing.Size(42, 31);
            this.ucPond2.TabIndex = 62;
            this.ucPond2.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.ucPond2.WallColor = System.Drawing.Color.Black;
            this.ucPond2.WallWidth = 2;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox8.Location = new System.Drawing.Point(208, 43);
            this.textBox8.Margin = new System.Windows.Forms.Padding(2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(44, 23);
            this.textBox8.TabIndex = 65;
            this.textBox8.Text = "000.0";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox1.Location = new System.Drawing.Point(41, 43);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(44, 23);
            this.textBox1.TabIndex = 65;
            this.textBox1.Text = "000.0";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox2.Location = new System.Drawing.Point(276, 43);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(44, 23);
            this.textBox2.TabIndex = 65;
            this.textBox2.Text = "000.0";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox3.Location = new System.Drawing.Point(27, 340);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(44, 23);
            this.textBox3.TabIndex = 65;
            this.textBox3.Text = "000.0";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox4.Location = new System.Drawing.Point(346, 43);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(44, 23);
            this.textBox4.TabIndex = 65;
            this.textBox4.Text = "000.0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(37, 0);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 17);
            this.label8.TabIndex = 63;
            this.label8.Text = "小N2";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(203, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(25, 17);
            this.label11.TabIndex = 63;
            this.label11.Text = "O2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(409, 0);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 17);
            this.label14.TabIndex = 63;
            this.label14.Text = "大N2";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(41, 25);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(41, 17);
            this.label17.TabIndex = 63;
            this.label17.Text = "MFC2";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(208, 25);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(41, 17);
            this.label20.TabIndex = 63;
            this.label20.Text = "MFC1";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(276, 24);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 17);
            this.label23.TabIndex = 63;
            this.label23.Text = "MFC3";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.Location = new System.Drawing.Point(346, 25);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(41, 17);
            this.label24.TabIndex = 63;
            this.label24.Text = "MFC5";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.Location = new System.Drawing.Point(24, 324);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(41, 17);
            this.label25.TabIndex = 63;
            this.label25.Text = "MFC4";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.Location = new System.Drawing.Point(1, 123);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(23, 17);
            this.label26.TabIndex = 63;
            this.label26.Text = "V3";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(51, 123);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(23, 17);
            this.label27.TabIndex = 63;
            this.label27.Text = "V2";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label28.Location = new System.Drawing.Point(168, 123);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(23, 17);
            this.label28.TabIndex = 63;
            this.label28.Text = "V1";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label29.Location = new System.Drawing.Point(235, 123);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(23, 17);
            this.label29.TabIndex = 63;
            this.label29.Text = "V4";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label30.Location = new System.Drawing.Point(296, 123);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(30, 17);
            this.label30.TabIndex = 63;
            this.label30.Text = "V11";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(373, 123);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(23, 17);
            this.label31.TabIndex = 63;
            this.label31.Text = "V6";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.Location = new System.Drawing.Point(414, 123);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(23, 17);
            this.label32.TabIndex = 63;
            this.label32.Text = "V7";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.Location = new System.Drawing.Point(37, 217);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(26, 17);
            this.label33.TabIndex = 63;
            this.label33.Text = "V2i";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label35.Location = new System.Drawing.Point(40, 298);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(23, 17);
            this.label35.TabIndex = 63;
            this.label35.Text = "V9";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.Location = new System.Drawing.Point(137, 298);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(23, 17);
            this.label36.TabIndex = 63;
            this.label36.Text = "V5";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label37.Location = new System.Drawing.Point(40, 402);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(30, 17);
            this.label37.TabIndex = 63;
            this.label37.Text = "V10";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label38.Location = new System.Drawing.Point(130, 459);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(23, 17);
            this.label38.TabIndex = 63;
            this.label38.Text = "V8";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label40.Location = new System.Drawing.Point(474, 4);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(107, 17);
            this.label40.TabIndex = 63;
            this.label40.Text = "真空计值(mBar)：";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label41.Location = new System.Drawing.Point(577, 4);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(39, 17);
            this.label41.TabIndex = 64;
            this.label41.Text = "000.0";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label42.Location = new System.Drawing.Point(474, 23);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(107, 17);
            this.label42.TabIndex = 63;
            this.label42.Text = "设定压力(mBar)：";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label44.Location = new System.Drawing.Point(505, 41);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(75, 17);
            this.label44.TabIndex = 63;
            this.label44.Text = "泵抽速(%)：";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label45.Location = new System.Drawing.Point(498, 60);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(83, 17);
            this.label45.TabIndex = 63;
            this.label45.Text = "漏率(mBar)：";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label46.Location = new System.Drawing.Point(577, 43);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(39, 17);
            this.label46.TabIndex = 64;
            this.label46.Text = "000.0";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label47.Location = new System.Drawing.Point(577, 63);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(39, 17);
            this.label47.TabIndex = 64;
            this.label47.Text = "000.0";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label48.Location = new System.Drawing.Point(512, 79);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(68, 17);
            this.label48.TabIndex = 63;
            this.label48.Text = "常压检测：";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label49.Location = new System.Drawing.Point(512, 97);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(68, 17);
            this.label49.TabIndex = 63;
            this.label49.Text = "真空检测：";
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox12.Image = global::Test.Properties.Resources.泵;
            this.pictureBox12.Location = new System.Drawing.Point(421, 464);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(33, 27);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 44;
            this.pictureBox12.TabStop = false;
            // 
            // ucSignalLamp3
            // 
            this.ucSignalLamp3.IsHighlight = true;
            this.ucSignalLamp3.IsShowBorder = true;
            this.ucSignalLamp3.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp3.Location = new System.Drawing.Point(582, 79);
            this.ucSignalLamp3.Margin = new System.Windows.Forms.Padding(2);
            this.ucSignalLamp3.Name = "ucSignalLamp3";
            this.ucSignalLamp3.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp3.TabIndex = 66;
            this.ucSignalLamp3.TwinkleSpeed = 0;
            // 
            // ucSignalLamp1
            // 
            this.ucSignalLamp1.IsHighlight = true;
            this.ucSignalLamp1.IsShowBorder = true;
            this.ucSignalLamp1.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp1.Location = new System.Drawing.Point(582, 97);
            this.ucSignalLamp1.Margin = new System.Windows.Forms.Padding(2);
            this.ucSignalLamp1.Name = "ucSignalLamp1";
            this.ucSignalLamp1.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp1.TabIndex = 66;
            this.ucSignalLamp1.TwinkleSpeed = 0;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox6.Location = new System.Drawing.Point(580, 23);
            this.textBox6.Margin = new System.Windows.Forms.Padding(2);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(44, 23);
            this.textBox6.TabIndex = 65;
            this.textBox6.Text = "000.0";
            // 
            // UCRoad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ucSignalLamp1);
            this.Controls.Add(this.ucSignalLamp3);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.ucValve11);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.ucValve1);
            this.Controls.Add(this.ucValve10);
            this.Controls.Add(this.ucValve9);
            this.Controls.Add(this.ucValve4);
            this.Controls.Add(this.ucValve12);
            this.Controls.Add(this.ucValve3);
            this.Controls.Add(this.ucConduit6);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.ucConduit34);
            this.Controls.Add(this.ucConduit13);
            this.Controls.Add(this.ucConduit56);
            this.Controls.Add(this.ucConduit31);
            this.Controls.Add(this.ucConduit44);
            this.Controls.Add(this.ucConduit5);
            this.Controls.Add(this.ucConduit2);
            this.Controls.Add(this.ucConduit7);
            this.Controls.Add(this.ucConduit33);
            this.Controls.Add(this.ucConduit30);
            this.Controls.Add(this.ucConduit54);
            this.Controls.Add(this.ucConduit52);
            this.Controls.Add(this.ucValve8);
            this.Controls.Add(this.ucConduit27);
            this.Controls.Add(this.ucConduit29);
            this.Controls.Add(this.ucConduit28);
            this.Controls.Add(this.ucConduit26);
            this.Controls.Add(this.ucConduit24);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ucConduit16);
            this.Controls.Add(this.ucConduit21);
            this.Controls.Add(this.ucConduit10);
            this.Controls.Add(this.ucConduit11);
            this.Controls.Add(this.ucConduit18);
            this.Controls.Add(this.ucConduit19);
            this.Controls.Add(this.ucConduit14);
            this.Controls.Add(this.ucConduit9);
            this.Controls.Add(this.ucConduit50);
            this.Controls.Add(this.ucConduit42);
            this.Controls.Add(this.ucConduit49);
            this.Controls.Add(this.ucConduit40);
            this.Controls.Add(this.ucConduit51);
            this.Controls.Add(this.ucConduit48);
            this.Controls.Add(this.ucConduit47);
            this.Controls.Add(this.ucConduit36);
            this.Controls.Add(this.ucConduit15);
            this.Controls.Add(this.ucConduit41);
            this.Controls.Add(this.ucConduit39);
            this.Controls.Add(this.ucConduit37);
            this.Controls.Add(this.ucConduit35);
            this.Controls.Add(this.ucConduit22);
            this.Controls.Add(this.ucConduit1);
            this.Controls.Add(this.ucValve7);
            this.Controls.Add(this.ucValve6);
            this.Controls.Add(this.ucValve5);
            this.Controls.Add(this.ucValve2);
            this.Controls.Add(this.ucConduit25);
            this.Controls.Add(this.ucConduit32);
            this.Controls.Add(this.ucConduit53);
            this.Controls.Add(this.ucConduit55);
            this.Controls.Add(this.ucConduit3);
            this.Controls.Add(this.ucConduit46);
            this.Controls.Add(this.ucConduit45);
            this.Controls.Add(this.ucConduit20);
            this.Controls.Add(this.ucConduit8);
            this.Controls.Add(this.ucConduit4);
            this.Controls.Add(this.ucConduit43);
            this.Controls.Add(this.ucConduit17);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ucConduit23);
            this.Controls.Add(this.ucConduit12);
            this.Controls.Add(this.ucPond2);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox11);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "UCRoad";
            this.Size = new System.Drawing.Size(623, 500);
            this.Load += new System.EventHandler(this.UCRoad_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private HZH_Controls.Controls.UCValve ucValve1;
        private HZH_Controls.Controls.UCConduit ucConduit20;
        private System.Windows.Forms.PictureBox pictureBox1;
        private HZH_Controls.Controls.UCConduit ucConduit1;
        private System.Windows.Forms.Label label1;
        private HZH_Controls.Controls.UCConduit ucConduit22;
        private HZH_Controls.Controls.UCConduit ucConduit6;
        private HZH_Controls.Controls.UCValve ucValve3;
        private HZH_Controls.Controls.UCConduit ucConduit8;
        private HZH_Controls.Controls.UCConduit ucConduit9;
        private HZH_Controls.Controls.UCConduit ucConduit10;
        private HZH_Controls.Controls.UCConduit ucConduit11;
        private HZH_Controls.Controls.UCConduit ucConduit12;
        private HZH_Controls.Controls.UCPond ucPond2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private HZH_Controls.Controls.UCConduit ucConduit14;
        private HZH_Controls.Controls.UCConduit ucConduit15;
        private HZH_Controls.Controls.UCValve ucValve5;
        private HZH_Controls.Controls.UCConduit ucConduit16;
        private HZH_Controls.Controls.UCConduit ucConduit17;
        private HZH_Controls.Controls.UCConduit ucConduit18;
        private HZH_Controls.Controls.UCConduit ucConduit4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private HZH_Controls.Controls.UCConduit ucConduit19;
        private HZH_Controls.Controls.UCValve ucValve6;
        private HZH_Controls.Controls.UCConduit ucConduit21;
        private HZH_Controls.Controls.UCConduit ucConduit23;
        private HZH_Controls.Controls.UCValve ucValve7;
        private HZH_Controls.Controls.UCConduit ucConduit24;
        private HZH_Controls.Controls.UCConduit ucConduit25;
        private System.Windows.Forms.PictureBox pictureBox6;
        private HZH_Controls.Controls.UCConduit ucConduit26;
        private HZH_Controls.Controls.UCValve ucValve8;
        private HZH_Controls.Controls.UCConduit ucConduit27;
        private HZH_Controls.Controls.UCConduit ucConduit28;
        private System.Windows.Forms.PictureBox pictureBox7;
        private HZH_Controls.Controls.UCConduit ucConduit29;
        private HZH_Controls.Controls.UCConduit ucConduit3;
        private HZH_Controls.Controls.UCConduit ucConduit5;
        private HZH_Controls.Controls.UCConduit ucConduit7;
        private HZH_Controls.Controls.UCConduit ucConduit2;
        private HZH_Controls.Controls.UCConduit ucConduit13;
        private HZH_Controls.Controls.UCConduit ucConduit30;
        private HZH_Controls.Controls.UCConduit ucConduit31;
        private HZH_Controls.Controls.UCConduit ucConduit32;
        private HZH_Controls.Controls.UCConduit ucConduit33;
        private HZH_Controls.Controls.UCConduit ucConduit34;
        private HZH_Controls.Controls.UCValve ucValve2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private HZH_Controls.Controls.UCConduit ucConduit35;
        private HZH_Controls.Controls.UCConduit ucConduit36;
        private System.Windows.Forms.Label label2;
        private HZH_Controls.Controls.UCConduit ucConduit37;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox8;
        private HZH_Controls.Controls.UCConduit ucConduit39;
        private HZH_Controls.Controls.UCConduit ucConduit40;
        private System.Windows.Forms.PictureBox pictureBox9;
        private HZH_Controls.Controls.UCConduit ucConduit41;
        private HZH_Controls.Controls.UCConduit ucConduit42;
        private HZH_Controls.Controls.UCConduit ucConduit43;
        private HZH_Controls.Controls.UCConduit ucConduit44;
        private HZH_Controls.Controls.UCValve ucValve4;
        private HZH_Controls.Controls.UCValve ucValve9;
        private HZH_Controls.Controls.UCValve ucValve10;
        private HZH_Controls.Controls.UCValve ucValve11;
        private HZH_Controls.Controls.UCConduit ucConduit45;
        private HZH_Controls.Controls.UCConduit ucConduit46;
        private HZH_Controls.Controls.UCValve ucValve12;
        private HZH_Controls.Controls.UCConduit ucConduit47;
        private HZH_Controls.Controls.UCConduit ucConduit48;
        private HZH_Controls.Controls.UCConduit ucConduit49;
        private HZH_Controls.Controls.UCConduit ucConduit50;
        private HZH_Controls.Controls.UCConduit ucConduit51;
        private HZH_Controls.Controls.UCConduit ucConduit52;
        private HZH_Controls.Controls.UCConduit ucConduit53;
        private HZH_Controls.Controls.UCConduit ucConduit54;
        private HZH_Controls.Controls.UCConduit ucConduit55;
        private HZH_Controls.Controls.UCConduit ucConduit56;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.PictureBox pictureBox12;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp3;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp1;
        private System.Windows.Forms.TextBox textBox6;
    }
}

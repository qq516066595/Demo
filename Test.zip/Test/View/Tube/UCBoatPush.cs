﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test.View.Tube
{
    public partial class UCBoatPush : UserControl
    {
        public UCBoatPush()
        {
            InitializeComponent();
        }

        private void UCBoatPush_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 信号灯变化
        /// </summary>
        /// <param name="bsignal"></param>
        /// <param name="label"></param>
        public void LampStatesChange(bool bsignal, Label label)
        {
            if (bsignal)
                label.BackColor = Color.Lime;
            else
                label.BackColor = Color.White;
        }
    }
}

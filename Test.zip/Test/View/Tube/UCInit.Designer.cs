﻿namespace Test.View.Tube
{
    partial class UCInit
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucSignalLamp1 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp2 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp3 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp4 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp5 = new HZH_Controls.Controls.UCSignalLamp();
            this.label27 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ucSignalLamp1
            // 
            this.ucSignalLamp1.IsHighlight = true;
            this.ucSignalLamp1.IsShowBorder = false;
            this.ucSignalLamp1.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp1.Location = new System.Drawing.Point(115, 18);
            this.ucSignalLamp1.Name = "ucSignalLamp1";
            this.ucSignalLamp1.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp1.TabIndex = 29;
            this.ucSignalLamp1.TwinkleSpeed = 0;
            // 
            // ucSignalLamp2
            // 
            this.ucSignalLamp2.IsHighlight = true;
            this.ucSignalLamp2.IsShowBorder = false;
            this.ucSignalLamp2.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp2.Location = new System.Drawing.Point(115, 45);
            this.ucSignalLamp2.Name = "ucSignalLamp2";
            this.ucSignalLamp2.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp2.TabIndex = 29;
            this.ucSignalLamp2.TwinkleSpeed = 0;
            // 
            // ucSignalLamp3
            // 
            this.ucSignalLamp3.IsHighlight = true;
            this.ucSignalLamp3.IsShowBorder = false;
            this.ucSignalLamp3.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp3.Location = new System.Drawing.Point(115, 72);
            this.ucSignalLamp3.Name = "ucSignalLamp3";
            this.ucSignalLamp3.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp3.TabIndex = 29;
            this.ucSignalLamp3.TwinkleSpeed = 0;
            // 
            // ucSignalLamp4
            // 
            this.ucSignalLamp4.IsHighlight = true;
            this.ucSignalLamp4.IsShowBorder = false;
            this.ucSignalLamp4.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp4.Location = new System.Drawing.Point(115, 99);
            this.ucSignalLamp4.Name = "ucSignalLamp4";
            this.ucSignalLamp4.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp4.TabIndex = 29;
            this.ucSignalLamp4.TwinkleSpeed = 0;
            // 
            // ucSignalLamp5
            // 
            this.ucSignalLamp5.IsHighlight = true;
            this.ucSignalLamp5.IsShowBorder = false;
            this.ucSignalLamp5.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp5.Location = new System.Drawing.Point(115, 126);
            this.ucSignalLamp5.Name = "ucSignalLamp5";
            this.ucSignalLamp5.Size = new System.Drawing.Size(20, 20);
            this.ucSignalLamp5.TabIndex = 29;
            this.ucSignalLamp5.TwinkleSpeed = 0;
            // 
            // label27
            // 
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label27.Dock = System.Windows.Forms.DockStyle.Top;
            this.label27.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(0, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(764, 1);
            this.label27.TabIndex = 30;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(19, 15);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 23);
            this.button1.TabIndex = 31;
            this.button1.Text = "工艺单元";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(19, 42);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(90, 23);
            this.button2.TabIndex = 31;
            this.button2.Text = "加热系统";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(19, 69);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(90, 23);
            this.button3.TabIndex = 31;
            this.button3.Text = "气路系统";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button4.Location = new System.Drawing.Point(19, 96);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(90, 23);
            this.button4.TabIndex = 31;
            this.button4.Text = "推舟系统";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button5.Location = new System.Drawing.Point(19, 123);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(90, 23);
            this.button5.TabIndex = 31;
            this.button5.Text = "真空系统";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // UCInit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.ucSignalLamp5);
            this.Controls.Add(this.ucSignalLamp4);
            this.Controls.Add(this.ucSignalLamp3);
            this.Controls.Add(this.ucSignalLamp2);
            this.Controls.Add(this.ucSignalLamp1);
            this.Name = "UCInit";
            this.Size = new System.Drawing.Size(764, 581);
            this.ResumeLayout(false);

        }

        #endregion
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp1;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp2;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp3;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp4;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp5;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
    }
}

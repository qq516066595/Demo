﻿namespace Test.View.Tube
{
    partial class UCIO
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucioModule1 = new Test.View.Common.UCIOModule();
            this.ucioModule2 = new Test.View.Common.UCIOModule();
            this.ucioModule3 = new Test.View.Common.UCIOModule();
            this.ucioModule4 = new Test.View.Common.UCIOModule();
            this.ucioModule5 = new Test.View.Common.UCIOModule();
            this.ucioModule6 = new Test.View.Common.UCIOModule();
            this.ucioModule7 = new Test.View.Common.UCIOModule();
            this.ucioModule8 = new Test.View.Common.UCIOModule();
            this.ucioModule9 = new Test.View.Common.UCIOModule();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ucioModule1
            // 
            this.ucioModule1.Location = new System.Drawing.Point(7, 3);
            this.ucioModule1.Name = "ucioModule1";
            this.ucioModule1.Size = new System.Drawing.Size(247, 188);
            this.ucioModule1.TabIndex = 0;
            // 
            // ucioModule2
            // 
            this.ucioModule2.Location = new System.Drawing.Point(260, 3);
            this.ucioModule2.Name = "ucioModule2";
            this.ucioModule2.Size = new System.Drawing.Size(247, 188);
            this.ucioModule2.TabIndex = 1;
            // 
            // ucioModule3
            // 
            this.ucioModule3.Location = new System.Drawing.Point(7, 197);
            this.ucioModule3.Name = "ucioModule3";
            this.ucioModule3.Size = new System.Drawing.Size(247, 188);
            this.ucioModule3.TabIndex = 2;
            // 
            // ucioModule4
            // 
            this.ucioModule4.Location = new System.Drawing.Point(260, 197);
            this.ucioModule4.Name = "ucioModule4";
            this.ucioModule4.Size = new System.Drawing.Size(247, 188);
            this.ucioModule4.TabIndex = 3;
            // 
            // ucioModule5
            // 
            this.ucioModule5.Location = new System.Drawing.Point(513, 3);
            this.ucioModule5.Name = "ucioModule5";
            this.ucioModule5.Size = new System.Drawing.Size(247, 188);
            this.ucioModule5.TabIndex = 4;
            // 
            // ucioModule6
            // 
            this.ucioModule6.Location = new System.Drawing.Point(513, 197);
            this.ucioModule6.Name = "ucioModule6";
            this.ucioModule6.Size = new System.Drawing.Size(247, 188);
            this.ucioModule6.TabIndex = 5;
            // 
            // ucioModule7
            // 
            this.ucioModule7.Location = new System.Drawing.Point(7, 391);
            this.ucioModule7.Name = "ucioModule7";
            this.ucioModule7.Size = new System.Drawing.Size(247, 188);
            this.ucioModule7.TabIndex = 2;
            // 
            // ucioModule8
            // 
            this.ucioModule8.Location = new System.Drawing.Point(260, 391);
            this.ucioModule8.Name = "ucioModule8";
            this.ucioModule8.Size = new System.Drawing.Size(247, 188);
            this.ucioModule8.TabIndex = 3;
            // 
            // ucioModule9
            // 
            this.ucioModule9.Location = new System.Drawing.Point(513, 391);
            this.ucioModule9.Name = "ucioModule9";
            this.ucioModule9.Size = new System.Drawing.Size(247, 188);
            this.ucioModule9.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(671, 1);
            this.label1.TabIndex = 6;
            // 
            // UCIO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ucioModule9);
            this.Controls.Add(this.ucioModule6);
            this.Controls.Add(this.ucioModule5);
            this.Controls.Add(this.ucioModule8);
            this.Controls.Add(this.ucioModule7);
            this.Controls.Add(this.ucioModule4);
            this.Controls.Add(this.ucioModule3);
            this.Controls.Add(this.ucioModule2);
            this.Controls.Add(this.ucioModule1);
            this.Name = "UCIO";
            this.Size = new System.Drawing.Size(671, 513);
            this.ResumeLayout(false);

        }

        #endregion

        private Common.UCIOModule ucioModule1;
        private Common.UCIOModule ucioModule2;
        private Common.UCIOModule ucioModule3;
        private Common.UCIOModule ucioModule4;
        private Common.UCIOModule ucioModule5;
        private Common.UCIOModule ucioModule6;
        private Common.UCIOModule ucioModule7;
        private Common.UCIOModule ucioModule8;
        private Common.UCIOModule ucioModule9;
        private System.Windows.Forms.Label label1;
    }
}

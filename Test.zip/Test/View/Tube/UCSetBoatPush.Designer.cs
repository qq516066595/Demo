﻿namespace Test.View.Tube
{
    partial class UCSetBoatPush
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxEx1 = new HZH_Controls.Controls.TextBoxEx();
            this.textBoxEx2 = new HZH_Controls.Controls.TextBoxEx();
            this.textBoxEx3 = new HZH_Controls.Controls.TextBoxEx();
            this.textBoxEx4 = new HZH_Controls.Controls.TextBoxEx();
            this.textBoxEx5 = new HZH_Controls.Controls.TextBoxEx();
            this.textBoxEx6 = new HZH_Controls.Controls.TextBoxEx();
            this.button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxEx7 = new HZH_Controls.Controls.TextBoxEx();
            this.textBoxEx8 = new HZH_Controls.Controls.TextBoxEx();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxEx9 = new HZH_Controls.Controls.TextBoxEx();
            this.textBoxEx10 = new HZH_Controls.Controls.TextBoxEx();
            this.button2 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxEx11 = new HZH_Controls.Controls.TextBoxEx();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxEx12 = new HZH_Controls.Controls.TextBoxEx();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(22, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "名称";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(90, 16);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "设定位置(mm)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(223, 16);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(144, 24);
            this.label3.TabIndex = 0;
            this.label3.Text = "设定速度(mm/s)";
            // 
            // label27
            // 
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label27.Dock = System.Windows.Forms.DockStyle.Top;
            this.label27.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(0, 0);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(1004, 2);
            this.label27.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(6, 42);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 24);
            this.label4.TabIndex = 0;
            this.label4.Text = "2.工艺位";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(6, 68);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 24);
            this.label5.TabIndex = 0;
            this.label5.Text = "5.放舟位";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(6, 93);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 24);
            this.label6.TabIndex = 0;
            this.label6.Text = "7.取舟位";
            // 
            // textBoxEx1
            // 
            this.textBoxEx1.DecLength = 2;
            this.textBoxEx1.InputType = HZH_Controls.TextInputType.NotControl;
            this.textBoxEx1.Location = new System.Drawing.Point(103, 43);
            this.textBoxEx1.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.textBoxEx1.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.textBoxEx1.MyRectangle = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.textBoxEx1.Name = "textBoxEx1";
            this.textBoxEx1.OldText = null;
            this.textBoxEx1.PromptColor = System.Drawing.Color.Gray;
            this.textBoxEx1.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.textBoxEx1.PromptText = "";
            this.textBoxEx1.RegexPattern = "";
            this.textBoxEx1.Size = new System.Drawing.Size(100, 28);
            this.textBoxEx1.TabIndex = 4;
            // 
            // textBoxEx2
            // 
            this.textBoxEx2.DecLength = 2;
            this.textBoxEx2.InputType = HZH_Controls.TextInputType.NotControl;
            this.textBoxEx2.Location = new System.Drawing.Point(103, 69);
            this.textBoxEx2.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.textBoxEx2.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.textBoxEx2.MyRectangle = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.textBoxEx2.Name = "textBoxEx2";
            this.textBoxEx2.OldText = null;
            this.textBoxEx2.PromptColor = System.Drawing.Color.Gray;
            this.textBoxEx2.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.textBoxEx2.PromptText = "";
            this.textBoxEx2.RegexPattern = "";
            this.textBoxEx2.Size = new System.Drawing.Size(100, 28);
            this.textBoxEx2.TabIndex = 4;
            // 
            // textBoxEx3
            // 
            this.textBoxEx3.DecLength = 2;
            this.textBoxEx3.InputType = HZH_Controls.TextInputType.NotControl;
            this.textBoxEx3.Location = new System.Drawing.Point(103, 94);
            this.textBoxEx3.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.textBoxEx3.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.textBoxEx3.MyRectangle = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.textBoxEx3.Name = "textBoxEx3";
            this.textBoxEx3.OldText = null;
            this.textBoxEx3.PromptColor = System.Drawing.Color.Gray;
            this.textBoxEx3.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.textBoxEx3.PromptText = "";
            this.textBoxEx3.RegexPattern = "";
            this.textBoxEx3.Size = new System.Drawing.Size(100, 28);
            this.textBoxEx3.TabIndex = 4;
            // 
            // textBoxEx4
            // 
            this.textBoxEx4.DecLength = 2;
            this.textBoxEx4.InputType = HZH_Controls.TextInputType.NotControl;
            this.textBoxEx4.Location = new System.Drawing.Point(237, 43);
            this.textBoxEx4.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.textBoxEx4.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.textBoxEx4.MyRectangle = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.textBoxEx4.Name = "textBoxEx4";
            this.textBoxEx4.OldText = null;
            this.textBoxEx4.PromptColor = System.Drawing.Color.Gray;
            this.textBoxEx4.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.textBoxEx4.PromptText = "";
            this.textBoxEx4.RegexPattern = "";
            this.textBoxEx4.Size = new System.Drawing.Size(100, 28);
            this.textBoxEx4.TabIndex = 4;
            // 
            // textBoxEx5
            // 
            this.textBoxEx5.DecLength = 2;
            this.textBoxEx5.InputType = HZH_Controls.TextInputType.NotControl;
            this.textBoxEx5.Location = new System.Drawing.Point(237, 69);
            this.textBoxEx5.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.textBoxEx5.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.textBoxEx5.MyRectangle = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.textBoxEx5.Name = "textBoxEx5";
            this.textBoxEx5.OldText = null;
            this.textBoxEx5.PromptColor = System.Drawing.Color.Gray;
            this.textBoxEx5.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.textBoxEx5.PromptText = "";
            this.textBoxEx5.RegexPattern = "";
            this.textBoxEx5.Size = new System.Drawing.Size(100, 28);
            this.textBoxEx5.TabIndex = 4;
            // 
            // textBoxEx6
            // 
            this.textBoxEx6.DecLength = 2;
            this.textBoxEx6.InputType = HZH_Controls.TextInputType.NotControl;
            this.textBoxEx6.Location = new System.Drawing.Point(237, 94);
            this.textBoxEx6.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.textBoxEx6.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.textBoxEx6.MyRectangle = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.textBoxEx6.Name = "textBoxEx6";
            this.textBoxEx6.OldText = null;
            this.textBoxEx6.PromptColor = System.Drawing.Color.Gray;
            this.textBoxEx6.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.textBoxEx6.PromptText = "";
            this.textBoxEx6.RegexPattern = "";
            this.textBoxEx6.Size = new System.Drawing.Size(100, 28);
            this.textBoxEx6.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(374, 66);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(129, 41);
            this.button1.TabIndex = 5;
            this.button1.Text = "回原点";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(92, 152);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(126, 24);
            this.label7.TabIndex = 0;
            this.label7.Text = "加速度(mm/s)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(233, 152);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 24);
            this.label8.TabIndex = 0;
            this.label8.Text = "最大扭矩(%)";
            // 
            // textBoxEx7
            // 
            this.textBoxEx7.DecLength = 2;
            this.textBoxEx7.InputType = HZH_Controls.TextInputType.NotControl;
            this.textBoxEx7.Location = new System.Drawing.Point(103, 179);
            this.textBoxEx7.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.textBoxEx7.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.textBoxEx7.MyRectangle = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.textBoxEx7.Name = "textBoxEx7";
            this.textBoxEx7.OldText = null;
            this.textBoxEx7.PromptColor = System.Drawing.Color.Gray;
            this.textBoxEx7.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.textBoxEx7.PromptText = "";
            this.textBoxEx7.RegexPattern = "";
            this.textBoxEx7.Size = new System.Drawing.Size(100, 28);
            this.textBoxEx7.TabIndex = 4;
            // 
            // textBoxEx8
            // 
            this.textBoxEx8.DecLength = 2;
            this.textBoxEx8.InputType = HZH_Controls.TextInputType.NotControl;
            this.textBoxEx8.Location = new System.Drawing.Point(237, 179);
            this.textBoxEx8.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.textBoxEx8.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.textBoxEx8.MyRectangle = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.textBoxEx8.Name = "textBoxEx8";
            this.textBoxEx8.OldText = null;
            this.textBoxEx8.PromptColor = System.Drawing.Color.Gray;
            this.textBoxEx8.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.textBoxEx8.PromptText = "";
            this.textBoxEx8.RegexPattern = "";
            this.textBoxEx8.Size = new System.Drawing.Size(100, 28);
            this.textBoxEx8.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(103, 210);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 24);
            this.label9.TabIndex = 0;
            this.label9.Text = "正向软极限";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(237, 210);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 24);
            this.label10.TabIndex = 0;
            this.label10.Text = "反向软极限";
            // 
            // textBoxEx9
            // 
            this.textBoxEx9.DecLength = 2;
            this.textBoxEx9.InputType = HZH_Controls.TextInputType.NotControl;
            this.textBoxEx9.Location = new System.Drawing.Point(103, 237);
            this.textBoxEx9.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.textBoxEx9.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.textBoxEx9.MyRectangle = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.textBoxEx9.Name = "textBoxEx9";
            this.textBoxEx9.OldText = null;
            this.textBoxEx9.PromptColor = System.Drawing.Color.Gray;
            this.textBoxEx9.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.textBoxEx9.PromptText = "";
            this.textBoxEx9.RegexPattern = "";
            this.textBoxEx9.Size = new System.Drawing.Size(100, 28);
            this.textBoxEx9.TabIndex = 4;
            // 
            // textBoxEx10
            // 
            this.textBoxEx10.DecLength = 2;
            this.textBoxEx10.InputType = HZH_Controls.TextInputType.NotControl;
            this.textBoxEx10.Location = new System.Drawing.Point(237, 237);
            this.textBoxEx10.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.textBoxEx10.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.textBoxEx10.MyRectangle = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.textBoxEx10.Name = "textBoxEx10";
            this.textBoxEx10.OldText = null;
            this.textBoxEx10.PromptColor = System.Drawing.Color.Gray;
            this.textBoxEx10.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.textBoxEx10.PromptText = "";
            this.textBoxEx10.RegexPattern = "";
            this.textBoxEx10.Size = new System.Drawing.Size(100, 28);
            this.textBoxEx10.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(374, 193);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(129, 41);
            this.button2.TabIndex = 5;
            this.button2.Text = "扭矩保护使能";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(39, 286);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(298, 24);
            this.label11.TabIndex = 0;
            this.label11.Text = "出舟时，舟相对于传感器的偏差位置";
            // 
            // textBoxEx11
            // 
            this.textBoxEx11.DecLength = 2;
            this.textBoxEx11.InputType = HZH_Controls.TextInputType.NotControl;
            this.textBoxEx11.Location = new System.Drawing.Point(344, 284);
            this.textBoxEx11.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.textBoxEx11.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.textBoxEx11.MyRectangle = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.textBoxEx11.Name = "textBoxEx11";
            this.textBoxEx11.OldText = null;
            this.textBoxEx11.PromptColor = System.Drawing.Color.Gray;
            this.textBoxEx11.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.textBoxEx11.PromptText = "";
            this.textBoxEx11.RegexPattern = "";
            this.textBoxEx11.Size = new System.Drawing.Size(100, 28);
            this.textBoxEx11.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(39, 319);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(298, 24);
            this.label12.TabIndex = 0;
            this.label12.Text = "出舟时，有舟位与无舟位的偏差位置";
            // 
            // textBoxEx12
            // 
            this.textBoxEx12.DecLength = 2;
            this.textBoxEx12.InputType = HZH_Controls.TextInputType.NotControl;
            this.textBoxEx12.Location = new System.Drawing.Point(344, 317);
            this.textBoxEx12.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.textBoxEx12.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.textBoxEx12.MyRectangle = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.textBoxEx12.Name = "textBoxEx12";
            this.textBoxEx12.OldText = null;
            this.textBoxEx12.PromptColor = System.Drawing.Color.Gray;
            this.textBoxEx12.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.textBoxEx12.PromptText = "";
            this.textBoxEx12.RegexPattern = "";
            this.textBoxEx12.Size = new System.Drawing.Size(100, 28);
            this.textBoxEx12.TabIndex = 4;
            // 
            // UCSetBoatPush
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBoxEx6);
            this.Controls.Add(this.textBoxEx3);
            this.Controls.Add(this.textBoxEx5);
            this.Controls.Add(this.textBoxEx2);
            this.Controls.Add(this.textBoxEx12);
            this.Controls.Add(this.textBoxEx11);
            this.Controls.Add(this.textBoxEx10);
            this.Controls.Add(this.textBoxEx8);
            this.Controls.Add(this.textBoxEx4);
            this.Controls.Add(this.textBoxEx9);
            this.Controls.Add(this.textBoxEx7);
            this.Controls.Add(this.textBoxEx1);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "UCSetBoatPush";
            this.Size = new System.Drawing.Size(1004, 952);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private HZH_Controls.Controls.TextBoxEx textBoxEx1;
        private HZH_Controls.Controls.TextBoxEx textBoxEx2;
        private HZH_Controls.Controls.TextBoxEx textBoxEx3;
        private HZH_Controls.Controls.TextBoxEx textBoxEx4;
        private HZH_Controls.Controls.TextBoxEx textBoxEx5;
        private HZH_Controls.Controls.TextBoxEx textBoxEx6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private HZH_Controls.Controls.TextBoxEx textBoxEx7;
        private HZH_Controls.Controls.TextBoxEx textBoxEx8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private HZH_Controls.Controls.TextBoxEx textBoxEx9;
        private HZH_Controls.Controls.TextBoxEx textBoxEx10;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label11;
        private HZH_Controls.Controls.TextBoxEx textBoxEx11;
        private System.Windows.Forms.Label label12;
        private HZH_Controls.Controls.TextBoxEx textBoxEx12;
    }
}

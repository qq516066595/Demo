﻿namespace Test.View.Tube
{
    partial class UCZone
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.lblOnHeating = new System.Windows.Forms.Label();
            this.lblLineH = new System.Windows.Forms.Label();
            this.lblLineH2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblZoneEx1 = new System.Windows.Forms.Label();
            this.lblZoneEx2 = new System.Windows.Forms.Label();
            this.lblZoneEx3 = new System.Windows.Forms.Label();
            this.lblZoneEx4 = new System.Windows.Forms.Label();
            this.lblZoneEx5 = new System.Windows.Forms.Label();
            this.lblZoneEx6 = new System.Windows.Forms.Label();
            this.lblZoneEx7 = new System.Windows.Forms.Label();
            this.lblZoneEx8 = new System.Windows.Forms.Label();
            this.lblZoneIn1 = new System.Windows.Forms.Label();
            this.lblZoneIn2 = new System.Windows.Forms.Label();
            this.lblZoneIn3 = new System.Windows.Forms.Label();
            this.lblZoneIn4 = new System.Windows.Forms.Label();
            this.lblZoneIn5 = new System.Windows.Forms.Label();
            this.lblZoneIn6 = new System.Windows.Forms.Label();
            this.lblZoneIn7 = new System.Windows.Forms.Label();
            this.lblZoneIn8 = new System.Windows.Forms.Label();
            this.lblZoneMV1 = new System.Windows.Forms.Label();
            this.lblZoneMV2 = new System.Windows.Forms.Label();
            this.lblZoneMV3 = new System.Windows.Forms.Label();
            this.lblZoneMV4 = new System.Windows.Forms.Label();
            this.lblZoneMV5 = new System.Windows.Forms.Label();
            this.lblZoneMV6 = new System.Windows.Forms.Label();
            this.lblZoneMV7 = new System.Windows.Forms.Label();
            this.lblZoneMV8 = new System.Windows.Forms.Label();
            this.lblZoneSP1 = new System.Windows.Forms.Label();
            this.lblZoneSP2 = new System.Windows.Forms.Label();
            this.lblZoneSP3 = new System.Windows.Forms.Label();
            this.lblZoneSP4 = new System.Windows.Forms.Label();
            this.lblZoneSP5 = new System.Windows.Forms.Label();
            this.lblZoneSP6 = new System.Windows.Forms.Label();
            this.lblZoneSP7 = new System.Windows.Forms.Label();
            this.lblZoneSP8 = new System.Windows.Forms.Label();
            this.txtZoneSV1 = new System.Windows.Forms.TextBox();
            this.txtZoneSV2 = new System.Windows.Forms.TextBox();
            this.txtZoneSV3 = new System.Windows.Forms.TextBox();
            this.txtZoneSV4 = new System.Windows.Forms.TextBox();
            this.txtZoneSV5 = new System.Windows.Forms.TextBox();
            this.txtZoneSV6 = new System.Windows.Forms.TextBox();
            this.txtZoneSV7 = new System.Windows.Forms.TextBox();
            this.txtZoneSV8 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.lblCoolingPV1 = new System.Windows.Forms.Label();
            this.lblCoolingPV2 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblOnHeating
            // 
            this.lblOnHeating.AutoSize = true;
            this.lblOnHeating.Font = new System.Drawing.Font("微软雅黑", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblOnHeating.ForeColor = System.Drawing.Color.Red;
            this.lblOnHeating.Location = new System.Drawing.Point(26, 13);
            this.lblOnHeating.Name = "lblOnHeating";
            this.lblOnHeating.Size = new System.Drawing.Size(84, 25);
            this.lblOnHeating.TabIndex = 0;
            this.lblOnHeating.Text = "开启加热";
            this.lblOnHeating.Click += new System.EventHandler(this.lblOnHeating_Click);
            // 
            // lblLineH
            // 
            this.lblLineH.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblLineH.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblLineH.Location = new System.Drawing.Point(0, 0);
            this.lblLineH.Name = "lblLineH";
            this.lblLineH.Size = new System.Drawing.Size(976, 1);
            this.lblLineH.TabIndex = 1;
            // 
            // lblLineH2
            // 
            this.lblLineH2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblLineH2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblLineH2.Location = new System.Drawing.Point(0, 202);
            this.lblLineH2.Name = "lblLineH2";
            this.lblLineH2.Size = new System.Drawing.Size(976, 1);
            this.lblLineH2.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(26, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "外偶温度";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(26, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "内偶温度";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(26, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "设定温度";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(26, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 25);
            this.label4.TabIndex = 4;
            this.label4.Text = "功率输出";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(26, 169);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "过渡温度";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(114, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 25);
            this.label6.TabIndex = 4;
            this.label6.Text = "温区一";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(184, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 25);
            this.label7.TabIndex = 4;
            this.label7.Text = "温区二";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(254, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 25);
            this.label8.TabIndex = 4;
            this.label8.Text = "温区三";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(324, 13);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 25);
            this.label9.TabIndex = 4;
            this.label9.Text = "温区四";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(394, 13);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 25);
            this.label10.TabIndex = 4;
            this.label10.Text = "温区五";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(464, 13);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 25);
            this.label11.TabIndex = 4;
            this.label11.Text = "温区六";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(534, 13);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 25);
            this.label12.TabIndex = 4;
            this.label12.Text = "温区七";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(604, 13);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 25);
            this.label13.TabIndex = 4;
            this.label13.Text = "温区八";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(735, 13);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 25);
            this.label14.TabIndex = 4;
            this.label14.Text = "水冷";
            // 
            // lblZoneEx1
            // 
            this.lblZoneEx1.AutoSize = true;
            this.lblZoneEx1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneEx1.Location = new System.Drawing.Point(114, 47);
            this.lblZoneEx1.Name = "lblZoneEx1";
            this.lblZoneEx1.Size = new System.Drawing.Size(58, 24);
            this.lblZoneEx1.TabIndex = 4;
            this.lblZoneEx1.Text = "000.0";
            // 
            // lblZoneEx2
            // 
            this.lblZoneEx2.AutoSize = true;
            this.lblZoneEx2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneEx2.Location = new System.Drawing.Point(184, 47);
            this.lblZoneEx2.Name = "lblZoneEx2";
            this.lblZoneEx2.Size = new System.Drawing.Size(58, 24);
            this.lblZoneEx2.TabIndex = 4;
            this.lblZoneEx2.Text = "000.0";
            // 
            // lblZoneEx3
            // 
            this.lblZoneEx3.AutoSize = true;
            this.lblZoneEx3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneEx3.Location = new System.Drawing.Point(254, 47);
            this.lblZoneEx3.Name = "lblZoneEx3";
            this.lblZoneEx3.Size = new System.Drawing.Size(58, 24);
            this.lblZoneEx3.TabIndex = 4;
            this.lblZoneEx3.Text = "000.0";
            // 
            // lblZoneEx4
            // 
            this.lblZoneEx4.AutoSize = true;
            this.lblZoneEx4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneEx4.Location = new System.Drawing.Point(324, 47);
            this.lblZoneEx4.Name = "lblZoneEx4";
            this.lblZoneEx4.Size = new System.Drawing.Size(58, 24);
            this.lblZoneEx4.TabIndex = 4;
            this.lblZoneEx4.Text = "000.0";
            // 
            // lblZoneEx5
            // 
            this.lblZoneEx5.AutoSize = true;
            this.lblZoneEx5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneEx5.Location = new System.Drawing.Point(394, 47);
            this.lblZoneEx5.Name = "lblZoneEx5";
            this.lblZoneEx5.Size = new System.Drawing.Size(58, 24);
            this.lblZoneEx5.TabIndex = 4;
            this.lblZoneEx5.Text = "000.0";
            // 
            // lblZoneEx6
            // 
            this.lblZoneEx6.AutoSize = true;
            this.lblZoneEx6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneEx6.Location = new System.Drawing.Point(464, 47);
            this.lblZoneEx6.Name = "lblZoneEx6";
            this.lblZoneEx6.Size = new System.Drawing.Size(58, 24);
            this.lblZoneEx6.TabIndex = 4;
            this.lblZoneEx6.Text = "000.0";
            // 
            // lblZoneEx7
            // 
            this.lblZoneEx7.AutoSize = true;
            this.lblZoneEx7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneEx7.Location = new System.Drawing.Point(534, 47);
            this.lblZoneEx7.Name = "lblZoneEx7";
            this.lblZoneEx7.Size = new System.Drawing.Size(58, 24);
            this.lblZoneEx7.TabIndex = 4;
            this.lblZoneEx7.Text = "000.0";
            // 
            // lblZoneEx8
            // 
            this.lblZoneEx8.AutoSize = true;
            this.lblZoneEx8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneEx8.Location = new System.Drawing.Point(604, 47);
            this.lblZoneEx8.Name = "lblZoneEx8";
            this.lblZoneEx8.Size = new System.Drawing.Size(58, 24);
            this.lblZoneEx8.TabIndex = 4;
            this.lblZoneEx8.Text = "000.0";
            // 
            // lblZoneIn1
            // 
            this.lblZoneIn1.AutoSize = true;
            this.lblZoneIn1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneIn1.Location = new System.Drawing.Point(114, 77);
            this.lblZoneIn1.Name = "lblZoneIn1";
            this.lblZoneIn1.Size = new System.Drawing.Size(58, 24);
            this.lblZoneIn1.TabIndex = 4;
            this.lblZoneIn1.Text = "000.0";
            // 
            // lblZoneIn2
            // 
            this.lblZoneIn2.AutoSize = true;
            this.lblZoneIn2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneIn2.Location = new System.Drawing.Point(184, 77);
            this.lblZoneIn2.Name = "lblZoneIn2";
            this.lblZoneIn2.Size = new System.Drawing.Size(58, 24);
            this.lblZoneIn2.TabIndex = 4;
            this.lblZoneIn2.Text = "000.0";
            // 
            // lblZoneIn3
            // 
            this.lblZoneIn3.AutoSize = true;
            this.lblZoneIn3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneIn3.Location = new System.Drawing.Point(254, 77);
            this.lblZoneIn3.Name = "lblZoneIn3";
            this.lblZoneIn3.Size = new System.Drawing.Size(58, 24);
            this.lblZoneIn3.TabIndex = 4;
            this.lblZoneIn3.Text = "000.0";
            // 
            // lblZoneIn4
            // 
            this.lblZoneIn4.AutoSize = true;
            this.lblZoneIn4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneIn4.Location = new System.Drawing.Point(324, 77);
            this.lblZoneIn4.Name = "lblZoneIn4";
            this.lblZoneIn4.Size = new System.Drawing.Size(58, 24);
            this.lblZoneIn4.TabIndex = 4;
            this.lblZoneIn4.Text = "000.0";
            // 
            // lblZoneIn5
            // 
            this.lblZoneIn5.AutoSize = true;
            this.lblZoneIn5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneIn5.Location = new System.Drawing.Point(394, 77);
            this.lblZoneIn5.Name = "lblZoneIn5";
            this.lblZoneIn5.Size = new System.Drawing.Size(58, 24);
            this.lblZoneIn5.TabIndex = 4;
            this.lblZoneIn5.Text = "000.0";
            // 
            // lblZoneIn6
            // 
            this.lblZoneIn6.AutoSize = true;
            this.lblZoneIn6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneIn6.Location = new System.Drawing.Point(464, 77);
            this.lblZoneIn6.Name = "lblZoneIn6";
            this.lblZoneIn6.Size = new System.Drawing.Size(58, 24);
            this.lblZoneIn6.TabIndex = 4;
            this.lblZoneIn6.Text = "000.0";
            // 
            // lblZoneIn7
            // 
            this.lblZoneIn7.AutoSize = true;
            this.lblZoneIn7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneIn7.Location = new System.Drawing.Point(534, 77);
            this.lblZoneIn7.Name = "lblZoneIn7";
            this.lblZoneIn7.Size = new System.Drawing.Size(58, 24);
            this.lblZoneIn7.TabIndex = 4;
            this.lblZoneIn7.Text = "000.0";
            // 
            // lblZoneIn8
            // 
            this.lblZoneIn8.AutoSize = true;
            this.lblZoneIn8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneIn8.Location = new System.Drawing.Point(604, 77);
            this.lblZoneIn8.Name = "lblZoneIn8";
            this.lblZoneIn8.Size = new System.Drawing.Size(58, 24);
            this.lblZoneIn8.TabIndex = 4;
            this.lblZoneIn8.Text = "000.0";
            // 
            // lblZoneMV1
            // 
            this.lblZoneMV1.AutoSize = true;
            this.lblZoneMV1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneMV1.Location = new System.Drawing.Point(114, 139);
            this.lblZoneMV1.Name = "lblZoneMV1";
            this.lblZoneMV1.Size = new System.Drawing.Size(58, 24);
            this.lblZoneMV1.TabIndex = 4;
            this.lblZoneMV1.Text = "000.0";
            // 
            // lblZoneMV2
            // 
            this.lblZoneMV2.AutoSize = true;
            this.lblZoneMV2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneMV2.Location = new System.Drawing.Point(184, 139);
            this.lblZoneMV2.Name = "lblZoneMV2";
            this.lblZoneMV2.Size = new System.Drawing.Size(58, 24);
            this.lblZoneMV2.TabIndex = 4;
            this.lblZoneMV2.Text = "000.0";
            // 
            // lblZoneMV3
            // 
            this.lblZoneMV3.AutoSize = true;
            this.lblZoneMV3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneMV3.Location = new System.Drawing.Point(254, 139);
            this.lblZoneMV3.Name = "lblZoneMV3";
            this.lblZoneMV3.Size = new System.Drawing.Size(58, 24);
            this.lblZoneMV3.TabIndex = 4;
            this.lblZoneMV3.Text = "000.0";
            // 
            // lblZoneMV4
            // 
            this.lblZoneMV4.AutoSize = true;
            this.lblZoneMV4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneMV4.Location = new System.Drawing.Point(324, 139);
            this.lblZoneMV4.Name = "lblZoneMV4";
            this.lblZoneMV4.Size = new System.Drawing.Size(58, 24);
            this.lblZoneMV4.TabIndex = 4;
            this.lblZoneMV4.Text = "000.0";
            // 
            // lblZoneMV5
            // 
            this.lblZoneMV5.AutoSize = true;
            this.lblZoneMV5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneMV5.Location = new System.Drawing.Point(394, 139);
            this.lblZoneMV5.Name = "lblZoneMV5";
            this.lblZoneMV5.Size = new System.Drawing.Size(58, 24);
            this.lblZoneMV5.TabIndex = 4;
            this.lblZoneMV5.Text = "000.0";
            // 
            // lblZoneMV6
            // 
            this.lblZoneMV6.AutoSize = true;
            this.lblZoneMV6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneMV6.Location = new System.Drawing.Point(464, 139);
            this.lblZoneMV6.Name = "lblZoneMV6";
            this.lblZoneMV6.Size = new System.Drawing.Size(58, 24);
            this.lblZoneMV6.TabIndex = 4;
            this.lblZoneMV6.Text = "000.0";
            // 
            // lblZoneMV7
            // 
            this.lblZoneMV7.AutoSize = true;
            this.lblZoneMV7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneMV7.Location = new System.Drawing.Point(534, 139);
            this.lblZoneMV7.Name = "lblZoneMV7";
            this.lblZoneMV7.Size = new System.Drawing.Size(58, 24);
            this.lblZoneMV7.TabIndex = 4;
            this.lblZoneMV7.Text = "000.0";
            // 
            // lblZoneMV8
            // 
            this.lblZoneMV8.AutoSize = true;
            this.lblZoneMV8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneMV8.Location = new System.Drawing.Point(604, 139);
            this.lblZoneMV8.Name = "lblZoneMV8";
            this.lblZoneMV8.Size = new System.Drawing.Size(58, 24);
            this.lblZoneMV8.TabIndex = 4;
            this.lblZoneMV8.Text = "000.0";
            // 
            // lblZoneSP1
            // 
            this.lblZoneSP1.AutoSize = true;
            this.lblZoneSP1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneSP1.Location = new System.Drawing.Point(114, 169);
            this.lblZoneSP1.Name = "lblZoneSP1";
            this.lblZoneSP1.Size = new System.Drawing.Size(58, 24);
            this.lblZoneSP1.TabIndex = 4;
            this.lblZoneSP1.Text = "000.0";
            // 
            // lblZoneSP2
            // 
            this.lblZoneSP2.AutoSize = true;
            this.lblZoneSP2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneSP2.Location = new System.Drawing.Point(184, 169);
            this.lblZoneSP2.Name = "lblZoneSP2";
            this.lblZoneSP2.Size = new System.Drawing.Size(58, 24);
            this.lblZoneSP2.TabIndex = 4;
            this.lblZoneSP2.Text = "000.0";
            // 
            // lblZoneSP3
            // 
            this.lblZoneSP3.AutoSize = true;
            this.lblZoneSP3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneSP3.Location = new System.Drawing.Point(254, 169);
            this.lblZoneSP3.Name = "lblZoneSP3";
            this.lblZoneSP3.Size = new System.Drawing.Size(58, 24);
            this.lblZoneSP3.TabIndex = 4;
            this.lblZoneSP3.Text = "000.0";
            // 
            // lblZoneSP4
            // 
            this.lblZoneSP4.AutoSize = true;
            this.lblZoneSP4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneSP4.Location = new System.Drawing.Point(324, 169);
            this.lblZoneSP4.Name = "lblZoneSP4";
            this.lblZoneSP4.Size = new System.Drawing.Size(58, 24);
            this.lblZoneSP4.TabIndex = 4;
            this.lblZoneSP4.Text = "000.0";
            // 
            // lblZoneSP5
            // 
            this.lblZoneSP5.AutoSize = true;
            this.lblZoneSP5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneSP5.Location = new System.Drawing.Point(394, 169);
            this.lblZoneSP5.Name = "lblZoneSP5";
            this.lblZoneSP5.Size = new System.Drawing.Size(58, 24);
            this.lblZoneSP5.TabIndex = 4;
            this.lblZoneSP5.Text = "000.0";
            // 
            // lblZoneSP6
            // 
            this.lblZoneSP6.AutoSize = true;
            this.lblZoneSP6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneSP6.Location = new System.Drawing.Point(464, 169);
            this.lblZoneSP6.Name = "lblZoneSP6";
            this.lblZoneSP6.Size = new System.Drawing.Size(58, 24);
            this.lblZoneSP6.TabIndex = 4;
            this.lblZoneSP6.Text = "000.0";
            // 
            // lblZoneSP7
            // 
            this.lblZoneSP7.AutoSize = true;
            this.lblZoneSP7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneSP7.Location = new System.Drawing.Point(534, 169);
            this.lblZoneSP7.Name = "lblZoneSP7";
            this.lblZoneSP7.Size = new System.Drawing.Size(58, 24);
            this.lblZoneSP7.TabIndex = 4;
            this.lblZoneSP7.Text = "000.0";
            // 
            // lblZoneSP8
            // 
            this.lblZoneSP8.AutoSize = true;
            this.lblZoneSP8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblZoneSP8.Location = new System.Drawing.Point(604, 169);
            this.lblZoneSP8.Name = "lblZoneSP8";
            this.lblZoneSP8.Size = new System.Drawing.Size(58, 24);
            this.lblZoneSP8.TabIndex = 4;
            this.lblZoneSP8.Text = "000.0";
            // 
            // txtZoneSV1
            // 
            this.txtZoneSV1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtZoneSV1.Location = new System.Drawing.Point(118, 104);
            this.txtZoneSV1.Name = "txtZoneSV1";
            this.txtZoneSV1.Size = new System.Drawing.Size(64, 31);
            this.txtZoneSV1.TabIndex = 5;
            this.txtZoneSV1.Text = "000.0";
            // 
            // txtZoneSV2
            // 
            this.txtZoneSV2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtZoneSV2.Location = new System.Drawing.Point(188, 104);
            this.txtZoneSV2.Name = "txtZoneSV2";
            this.txtZoneSV2.Size = new System.Drawing.Size(64, 31);
            this.txtZoneSV2.TabIndex = 5;
            this.txtZoneSV2.Text = "000.0";
            // 
            // txtZoneSV3
            // 
            this.txtZoneSV3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtZoneSV3.Location = new System.Drawing.Point(258, 104);
            this.txtZoneSV3.Name = "txtZoneSV3";
            this.txtZoneSV3.Size = new System.Drawing.Size(64, 31);
            this.txtZoneSV3.TabIndex = 5;
            this.txtZoneSV3.Text = "000.0";
            // 
            // txtZoneSV4
            // 
            this.txtZoneSV4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtZoneSV4.Location = new System.Drawing.Point(328, 104);
            this.txtZoneSV4.Name = "txtZoneSV4";
            this.txtZoneSV4.Size = new System.Drawing.Size(64, 31);
            this.txtZoneSV4.TabIndex = 5;
            this.txtZoneSV4.Text = "000.0";
            // 
            // txtZoneSV5
            // 
            this.txtZoneSV5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtZoneSV5.Location = new System.Drawing.Point(398, 104);
            this.txtZoneSV5.Name = "txtZoneSV5";
            this.txtZoneSV5.Size = new System.Drawing.Size(64, 31);
            this.txtZoneSV5.TabIndex = 5;
            this.txtZoneSV5.Text = "000.0";
            // 
            // txtZoneSV6
            // 
            this.txtZoneSV6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtZoneSV6.Location = new System.Drawing.Point(468, 104);
            this.txtZoneSV6.Name = "txtZoneSV6";
            this.txtZoneSV6.Size = new System.Drawing.Size(64, 31);
            this.txtZoneSV6.TabIndex = 5;
            this.txtZoneSV6.Text = "000.0";
            // 
            // txtZoneSV7
            // 
            this.txtZoneSV7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtZoneSV7.Location = new System.Drawing.Point(538, 104);
            this.txtZoneSV7.Name = "txtZoneSV7";
            this.txtZoneSV7.Size = new System.Drawing.Size(64, 31);
            this.txtZoneSV7.TabIndex = 5;
            this.txtZoneSV7.Text = "000.0";
            // 
            // txtZoneSV8
            // 
            this.txtZoneSV8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtZoneSV8.Location = new System.Drawing.Point(608, 104);
            this.txtZoneSV8.Name = "txtZoneSV8";
            this.txtZoneSV8.Size = new System.Drawing.Size(64, 31);
            this.txtZoneSV8.TabIndex = 5;
            this.txtZoneSV8.Text = "000.0";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(735, 47);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(35, 24);
            this.label31.TabIndex = 4;
            this.label31.Text = "T1:";
            // 
            // lblCoolingPV1
            // 
            this.lblCoolingPV1.AutoSize = true;
            this.lblCoolingPV1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblCoolingPV1.Location = new System.Drawing.Point(776, 47);
            this.lblCoolingPV1.Name = "lblCoolingPV1";
            this.lblCoolingPV1.Size = new System.Drawing.Size(58, 24);
            this.lblCoolingPV1.TabIndex = 4;
            this.lblCoolingPV1.Text = "000.0";
            // 
            // lblCoolingPV2
            // 
            this.lblCoolingPV2.AutoSize = true;
            this.lblCoolingPV2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblCoolingPV2.Location = new System.Drawing.Point(776, 81);
            this.lblCoolingPV2.Name = "lblCoolingPV2";
            this.lblCoolingPV2.Size = new System.Drawing.Size(58, 24);
            this.lblCoolingPV2.TabIndex = 4;
            this.lblCoolingPV2.Text = "000.0";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.Location = new System.Drawing.Point(735, 81);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(35, 24);
            this.label34.TabIndex = 4;
            this.label34.Text = "T2:";
            // 
            // label35
            // 
            this.label35.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label35.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label35.Location = new System.Drawing.Point(707, 13);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(1, 177);
            this.label35.TabIndex = 4;
            // 
            // UCZone
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtZoneSV8);
            this.Controls.Add(this.txtZoneSV7);
            this.Controls.Add(this.txtZoneSV6);
            this.Controls.Add(this.txtZoneSV5);
            this.Controls.Add(this.txtZoneSV4);
            this.Controls.Add(this.txtZoneSV3);
            this.Controls.Add(this.txtZoneSV2);
            this.Controls.Add(this.txtZoneSV1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblZoneSP8);
            this.Controls.Add(this.lblZoneMV8);
            this.Controls.Add(this.lblZoneIn8);
            this.Controls.Add(this.lblZoneEx8);
            this.Controls.Add(this.lblZoneSP7);
            this.Controls.Add(this.lblZoneMV7);
            this.Controls.Add(this.lblZoneIn7);
            this.Controls.Add(this.lblZoneEx7);
            this.Controls.Add(this.lblZoneSP6);
            this.Controls.Add(this.lblZoneMV6);
            this.Controls.Add(this.lblZoneIn6);
            this.Controls.Add(this.lblZoneEx6);
            this.Controls.Add(this.lblZoneSP5);
            this.Controls.Add(this.lblZoneMV5);
            this.Controls.Add(this.lblZoneIn5);
            this.Controls.Add(this.lblZoneEx5);
            this.Controls.Add(this.lblZoneSP4);
            this.Controls.Add(this.lblZoneMV4);
            this.Controls.Add(this.lblZoneIn4);
            this.Controls.Add(this.lblZoneEx4);
            this.Controls.Add(this.lblZoneSP3);
            this.Controls.Add(this.lblZoneMV3);
            this.Controls.Add(this.lblZoneIn3);
            this.Controls.Add(this.lblZoneEx3);
            this.Controls.Add(this.lblZoneSP2);
            this.Controls.Add(this.lblZoneMV2);
            this.Controls.Add(this.lblZoneIn2);
            this.Controls.Add(this.lblZoneEx2);
            this.Controls.Add(this.lblZoneSP1);
            this.Controls.Add(this.lblZoneMV1);
            this.Controls.Add(this.lblCoolingPV2);
            this.Controls.Add(this.lblZoneIn1);
            this.Controls.Add(this.lblCoolingPV1);
            this.Controls.Add(this.lblZoneEx1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblLineH2);
            this.Controls.Add(this.lblLineH);
            this.Controls.Add(this.lblOnHeating);
            this.Name = "UCZone";
            this.Size = new System.Drawing.Size(976, 203);
            this.Load += new System.EventHandler(this.UCZone_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label lblOnHeating;
        private System.Windows.Forms.Label lblLineH;
        private System.Windows.Forms.Label lblLineH2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        public System.Windows.Forms.Label lblZoneEx1;
        public System.Windows.Forms.Label lblZoneEx2;
        public System.Windows.Forms.Label lblZoneEx3;
        public System.Windows.Forms.Label lblZoneEx4;
        public System.Windows.Forms.Label lblZoneEx5;
        public System.Windows.Forms.Label lblZoneEx6;
        public System.Windows.Forms.Label lblZoneEx7;
        public System.Windows.Forms.Label lblZoneEx8;
        public System.Windows.Forms.Label lblZoneIn1;
        public System.Windows.Forms.Label lblZoneIn2;
        public System.Windows.Forms.Label lblZoneIn3;
        public System.Windows.Forms.Label lblZoneIn4;
        public System.Windows.Forms.Label lblZoneIn5;
        public System.Windows.Forms.Label lblZoneIn6;
        public System.Windows.Forms.Label lblZoneIn7;
        public System.Windows.Forms.Label lblZoneIn8;
        public System.Windows.Forms.Label lblZoneMV1;
        public System.Windows.Forms.Label lblZoneMV2;
        public System.Windows.Forms.Label lblZoneMV3;
        public System.Windows.Forms.Label lblZoneMV4;
        public System.Windows.Forms.Label lblZoneMV5;
        public System.Windows.Forms.Label lblZoneMV6;
        public System.Windows.Forms.Label lblZoneMV7;
        public System.Windows.Forms.Label lblZoneMV8;
        public System.Windows.Forms.Label lblZoneSP1;
        public System.Windows.Forms.Label lblZoneSP2;
        public System.Windows.Forms.Label lblZoneSP3;
        public System.Windows.Forms.Label lblZoneSP4;
        public System.Windows.Forms.Label lblZoneSP5;
        public System.Windows.Forms.Label lblZoneSP6;
        public System.Windows.Forms.Label lblZoneSP7;
        public System.Windows.Forms.Label lblZoneSP8;
        public System.Windows.Forms.TextBox txtZoneSV1;
        public System.Windows.Forms.TextBox txtZoneSV2;
        public System.Windows.Forms.TextBox txtZoneSV3;
        public System.Windows.Forms.TextBox txtZoneSV4;
        public System.Windows.Forms.TextBox txtZoneSV5;
        public System.Windows.Forms.TextBox txtZoneSV6;
        public System.Windows.Forms.TextBox txtZoneSV7;
        public System.Windows.Forms.TextBox txtZoneSV8;
        private System.Windows.Forms.Label label31;
        public System.Windows.Forms.Label lblCoolingPV1;
        public System.Windows.Forms.Label lblCoolingPV2;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
    }
}

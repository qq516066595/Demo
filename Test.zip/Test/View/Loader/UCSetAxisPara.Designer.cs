﻿namespace Test.View.Loader
{
    partial class UCSetAxisPara
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.label90 = new System.Windows.Forms.Label();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.label91 = new System.Windows.Forms.Label();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.label92 = new System.Windows.Forms.Label();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.label97 = new System.Windows.Forms.Label();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.label99 = new System.Windows.Forms.Label();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.label100 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.label101 = new System.Windows.Forms.Label();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.label102 = new System.Windows.Forms.Label();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.label103 = new System.Windows.Forms.Label();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.label104 = new System.Windows.Forms.Label();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.label114 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImage = global::Test.Properties.Resources.炉管;
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(12, 51);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(275, 131);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "炉管一";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(102, 84);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 31);
            this.textBox3.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(102, 54);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 31);
            this.textBox2.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(102, 24);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 31);
            this.textBox1.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(208, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 24);
            this.label6.TabIndex = 2;
            this.label6.Text = "mm";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(39, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "X工位";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(208, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 24);
            this.label5.TabIndex = 2;
            this.label5.Text = "mm";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(39, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Z下位";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(208, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 24);
            this.label4.TabIndex = 2;
            this.label4.Text = "mm";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(39, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Z上位";
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundImage = global::Test.Properties.Resources.炉管;
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.textBox6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.Location = new System.Drawing.Point(12, 188);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(275, 131);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "炉管二";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(102, 84);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 31);
            this.textBox4.TabIndex = 3;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(102, 54);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 31);
            this.textBox5.TabIndex = 3;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(102, 24);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 31);
            this.textBox6.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(208, 87);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 24);
            this.label7.TabIndex = 2;
            this.label7.Text = "mm";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(39, 87);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 24);
            this.label8.TabIndex = 2;
            this.label8.Text = "X工位";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(208, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 24);
            this.label9.TabIndex = 2;
            this.label9.Text = "mm";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(39, 57);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 24);
            this.label10.TabIndex = 2;
            this.label10.Text = "Z下位";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(208, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 24);
            this.label11.TabIndex = 2;
            this.label11.Text = "mm";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(39, 27);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 24);
            this.label12.TabIndex = 2;
            this.label12.Text = "Z上位";
            // 
            // groupBox3
            // 
            this.groupBox3.BackgroundImage = global::Test.Properties.Resources.炉管;
            this.groupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox3.Controls.Add(this.textBox7);
            this.groupBox3.Controls.Add(this.textBox8);
            this.groupBox3.Controls.Add(this.textBox9);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox3.Location = new System.Drawing.Point(12, 325);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(275, 131);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "炉管三";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(102, 84);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 31);
            this.textBox7.TabIndex = 3;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(102, 54);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 31);
            this.textBox8.TabIndex = 3;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(102, 24);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 31);
            this.textBox9.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(208, 87);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 24);
            this.label13.TabIndex = 2;
            this.label13.Text = "mm";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(39, 87);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(58, 24);
            this.label14.TabIndex = 2;
            this.label14.Text = "X工位";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(208, 57);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 24);
            this.label15.TabIndex = 2;
            this.label15.Text = "mm";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(39, 57);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 24);
            this.label16.TabIndex = 2;
            this.label16.Text = "Z下位";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(208, 27);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 24);
            this.label17.TabIndex = 2;
            this.label17.Text = "mm";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(39, 27);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(57, 24);
            this.label18.TabIndex = 2;
            this.label18.Text = "Z上位";
            // 
            // groupBox4
            // 
            this.groupBox4.BackgroundImage = global::Test.Properties.Resources.炉管;
            this.groupBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox4.Controls.Add(this.textBox10);
            this.groupBox4.Controls.Add(this.textBox11);
            this.groupBox4.Controls.Add(this.textBox12);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox4.Location = new System.Drawing.Point(12, 462);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(275, 131);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "炉管四";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(102, 84);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 31);
            this.textBox10.TabIndex = 3;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(102, 54);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 31);
            this.textBox11.TabIndex = 3;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(102, 24);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 31);
            this.textBox12.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(208, 87);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(44, 24);
            this.label19.TabIndex = 2;
            this.label19.Text = "mm";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(39, 87);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(58, 24);
            this.label20.TabIndex = 2;
            this.label20.Text = "X工位";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(208, 57);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(44, 24);
            this.label21.TabIndex = 2;
            this.label21.Text = "mm";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(39, 57);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(57, 24);
            this.label22.TabIndex = 2;
            this.label22.Text = "Z下位";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(208, 27);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(44, 24);
            this.label23.TabIndex = 2;
            this.label23.Text = "mm";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.Location = new System.Drawing.Point(39, 27);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(57, 24);
            this.label24.TabIndex = 2;
            this.label24.Text = "Z上位";
            // 
            // groupBox5
            // 
            this.groupBox5.BackgroundImage = global::Test.Properties.Resources.炉管;
            this.groupBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox5.Controls.Add(this.textBox13);
            this.groupBox5.Controls.Add(this.textBox14);
            this.groupBox5.Controls.Add(this.textBox15);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Controls.Add(this.label28);
            this.groupBox5.Controls.Add(this.label29);
            this.groupBox5.Controls.Add(this.label30);
            this.groupBox5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox5.Location = new System.Drawing.Point(12, 599);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(275, 131);
            this.groupBox5.TabIndex = 8;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "炉管五";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(102, 84);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 31);
            this.textBox13.TabIndex = 3;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(102, 54);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 31);
            this.textBox14.TabIndex = 3;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(102, 24);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 31);
            this.textBox15.TabIndex = 3;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.Location = new System.Drawing.Point(208, 87);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(44, 24);
            this.label25.TabIndex = 2;
            this.label25.Text = "mm";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.Location = new System.Drawing.Point(39, 87);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(58, 24);
            this.label26.TabIndex = 2;
            this.label26.Text = "X工位";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(208, 57);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(44, 24);
            this.label27.TabIndex = 2;
            this.label27.Text = "mm";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label28.Location = new System.Drawing.Point(39, 57);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(57, 24);
            this.label28.TabIndex = 2;
            this.label28.Text = "Z下位";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label29.Location = new System.Drawing.Point(208, 27);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(44, 24);
            this.label29.TabIndex = 2;
            this.label29.Text = "mm";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label30.Location = new System.Drawing.Point(39, 27);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(57, 24);
            this.label30.TabIndex = 2;
            this.label30.Text = "Z上位";
            // 
            // groupBox6
            // 
            this.groupBox6.BackgroundImage = global::Test.Properties.Resources.炉管;
            this.groupBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox6.Controls.Add(this.textBox16);
            this.groupBox6.Controls.Add(this.textBox17);
            this.groupBox6.Controls.Add(this.textBox18);
            this.groupBox6.Controls.Add(this.label31);
            this.groupBox6.Controls.Add(this.label32);
            this.groupBox6.Controls.Add(this.label33);
            this.groupBox6.Controls.Add(this.label34);
            this.groupBox6.Controls.Add(this.label35);
            this.groupBox6.Controls.Add(this.label36);
            this.groupBox6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox6.Location = new System.Drawing.Point(12, 745);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(275, 131);
            this.groupBox6.TabIndex = 8;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "通道位";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(102, 84);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 31);
            this.textBox16.TabIndex = 3;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(102, 54);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(100, 31);
            this.textBox17.TabIndex = 3;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(102, 24);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(100, 31);
            this.textBox18.TabIndex = 3;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(208, 87);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(44, 24);
            this.label31.TabIndex = 2;
            this.label31.Text = "mm";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.Location = new System.Drawing.Point(39, 87);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(58, 24);
            this.label32.TabIndex = 2;
            this.label32.Text = "X工位";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.Location = new System.Drawing.Point(208, 57);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(44, 24);
            this.label33.TabIndex = 2;
            this.label33.Text = "mm";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.Location = new System.Drawing.Point(39, 57);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(57, 24);
            this.label34.TabIndex = 2;
            this.label34.Text = "Z下位";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label35.Location = new System.Drawing.Point(208, 27);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(44, 24);
            this.label35.TabIndex = 2;
            this.label35.Text = "mm";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.Location = new System.Drawing.Point(39, 27);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(57, 24);
            this.label36.TabIndex = 2;
            this.label36.Text = "Z上位";
            // 
            // groupBox7
            // 
            this.groupBox7.BackgroundImage = global::Test.Properties.Resources.缓存;
            this.groupBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox7.Controls.Add(this.textBox21);
            this.groupBox7.Controls.Add(this.label37);
            this.groupBox7.Controls.Add(this.textBox20);
            this.groupBox7.Controls.Add(this.label38);
            this.groupBox7.Controls.Add(this.textBox19);
            this.groupBox7.Controls.Add(this.label39);
            this.groupBox7.Controls.Add(this.label42);
            this.groupBox7.Controls.Add(this.label40);
            this.groupBox7.Controls.Add(this.label41);
            this.groupBox7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox7.Location = new System.Drawing.Point(300, 51);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(275, 131);
            this.groupBox7.TabIndex = 9;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "缓存一";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(96, 84);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(100, 31);
            this.textBox21.TabIndex = 3;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label37.Location = new System.Drawing.Point(33, 27);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(57, 24);
            this.label37.TabIndex = 2;
            this.label37.Text = "Z上位";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(96, 54);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 31);
            this.textBox20.TabIndex = 3;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label38.Location = new System.Drawing.Point(202, 27);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(44, 24);
            this.label38.TabIndex = 2;
            this.label38.Text = "mm";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(96, 24);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(100, 31);
            this.textBox19.TabIndex = 3;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label39.Location = new System.Drawing.Point(33, 57);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(57, 24);
            this.label39.TabIndex = 2;
            this.label39.Text = "Z下位";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label42.Location = new System.Drawing.Point(202, 87);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(44, 24);
            this.label42.TabIndex = 2;
            this.label42.Text = "mm";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label40.Location = new System.Drawing.Point(202, 57);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(44, 24);
            this.label40.TabIndex = 2;
            this.label40.Text = "mm";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label41.Location = new System.Drawing.Point(33, 87);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(58, 24);
            this.label41.TabIndex = 2;
            this.label41.Text = "X工位";
            // 
            // groupBox8
            // 
            this.groupBox8.BackgroundImage = global::Test.Properties.Resources.缓存;
            this.groupBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox8.Controls.Add(this.textBox22);
            this.groupBox8.Controls.Add(this.label43);
            this.groupBox8.Controls.Add(this.textBox23);
            this.groupBox8.Controls.Add(this.label44);
            this.groupBox8.Controls.Add(this.textBox24);
            this.groupBox8.Controls.Add(this.label45);
            this.groupBox8.Controls.Add(this.label46);
            this.groupBox8.Controls.Add(this.label47);
            this.groupBox8.Controls.Add(this.label48);
            this.groupBox8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox8.Location = new System.Drawing.Point(300, 188);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(275, 131);
            this.groupBox8.TabIndex = 9;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "缓存二";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(96, 84);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(100, 31);
            this.textBox22.TabIndex = 3;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label43.Location = new System.Drawing.Point(33, 27);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(57, 24);
            this.label43.TabIndex = 2;
            this.label43.Text = "Z上位";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(96, 54);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(100, 31);
            this.textBox23.TabIndex = 3;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label44.Location = new System.Drawing.Point(202, 27);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(44, 24);
            this.label44.TabIndex = 2;
            this.label44.Text = "mm";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(96, 24);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 31);
            this.textBox24.TabIndex = 3;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label45.Location = new System.Drawing.Point(33, 57);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(57, 24);
            this.label45.TabIndex = 2;
            this.label45.Text = "Z下位";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label46.Location = new System.Drawing.Point(202, 87);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(44, 24);
            this.label46.TabIndex = 2;
            this.label46.Text = "mm";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label47.Location = new System.Drawing.Point(202, 57);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(44, 24);
            this.label47.TabIndex = 2;
            this.label47.Text = "mm";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label48.Location = new System.Drawing.Point(33, 87);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(58, 24);
            this.label48.TabIndex = 2;
            this.label48.Text = "X工位";
            // 
            // groupBox9
            // 
            this.groupBox9.BackgroundImage = global::Test.Properties.Resources.缓存;
            this.groupBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox9.Controls.Add(this.textBox25);
            this.groupBox9.Controls.Add(this.label49);
            this.groupBox9.Controls.Add(this.textBox26);
            this.groupBox9.Controls.Add(this.label50);
            this.groupBox9.Controls.Add(this.textBox27);
            this.groupBox9.Controls.Add(this.label51);
            this.groupBox9.Controls.Add(this.label52);
            this.groupBox9.Controls.Add(this.label53);
            this.groupBox9.Controls.Add(this.label54);
            this.groupBox9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox9.Location = new System.Drawing.Point(300, 325);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(275, 131);
            this.groupBox9.TabIndex = 9;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "缓存三";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(96, 84);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(100, 31);
            this.textBox25.TabIndex = 3;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label49.Location = new System.Drawing.Point(33, 27);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(57, 24);
            this.label49.TabIndex = 2;
            this.label49.Text = "Z上位";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(96, 54);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(100, 31);
            this.textBox26.TabIndex = 3;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label50.Location = new System.Drawing.Point(202, 27);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(44, 24);
            this.label50.TabIndex = 2;
            this.label50.Text = "mm";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(96, 24);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(100, 31);
            this.textBox27.TabIndex = 3;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label51.Location = new System.Drawing.Point(33, 57);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(57, 24);
            this.label51.TabIndex = 2;
            this.label51.Text = "Z下位";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label52.Location = new System.Drawing.Point(202, 87);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(44, 24);
            this.label52.TabIndex = 2;
            this.label52.Text = "mm";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label53.Location = new System.Drawing.Point(202, 57);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(44, 24);
            this.label53.TabIndex = 2;
            this.label53.Text = "mm";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label54.Location = new System.Drawing.Point(33, 87);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(58, 24);
            this.label54.TabIndex = 2;
            this.label54.Text = "X工位";
            // 
            // groupBox10
            // 
            this.groupBox10.BackgroundImage = global::Test.Properties.Resources.缓存;
            this.groupBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox10.Controls.Add(this.textBox28);
            this.groupBox10.Controls.Add(this.label55);
            this.groupBox10.Controls.Add(this.textBox29);
            this.groupBox10.Controls.Add(this.label56);
            this.groupBox10.Controls.Add(this.textBox30);
            this.groupBox10.Controls.Add(this.label57);
            this.groupBox10.Controls.Add(this.label58);
            this.groupBox10.Controls.Add(this.label59);
            this.groupBox10.Controls.Add(this.label60);
            this.groupBox10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox10.Location = new System.Drawing.Point(300, 462);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(275, 131);
            this.groupBox10.TabIndex = 9;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "缓存四";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(96, 84);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(100, 31);
            this.textBox28.TabIndex = 3;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label55.Location = new System.Drawing.Point(33, 27);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(57, 24);
            this.label55.TabIndex = 2;
            this.label55.Text = "Z上位";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(96, 54);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(100, 31);
            this.textBox29.TabIndex = 3;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label56.Location = new System.Drawing.Point(202, 27);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(44, 24);
            this.label56.TabIndex = 2;
            this.label56.Text = "mm";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(96, 24);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(100, 31);
            this.textBox30.TabIndex = 3;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label57.Location = new System.Drawing.Point(33, 57);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(57, 24);
            this.label57.TabIndex = 2;
            this.label57.Text = "Z下位";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label58.Location = new System.Drawing.Point(202, 87);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(44, 24);
            this.label58.TabIndex = 2;
            this.label58.Text = "mm";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label59.Location = new System.Drawing.Point(202, 57);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(44, 24);
            this.label59.TabIndex = 2;
            this.label59.Text = "mm";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label60.Location = new System.Drawing.Point(33, 87);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(58, 24);
            this.label60.TabIndex = 2;
            this.label60.Text = "X工位";
            // 
            // groupBox11
            // 
            this.groupBox11.BackgroundImage = global::Test.Properties.Resources.缓存;
            this.groupBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox11.Controls.Add(this.textBox31);
            this.groupBox11.Controls.Add(this.label61);
            this.groupBox11.Controls.Add(this.textBox32);
            this.groupBox11.Controls.Add(this.label62);
            this.groupBox11.Controls.Add(this.textBox33);
            this.groupBox11.Controls.Add(this.label63);
            this.groupBox11.Controls.Add(this.label64);
            this.groupBox11.Controls.Add(this.label65);
            this.groupBox11.Controls.Add(this.label66);
            this.groupBox11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox11.Location = new System.Drawing.Point(300, 599);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(275, 131);
            this.groupBox11.TabIndex = 9;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "缓存五";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(96, 84);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(100, 31);
            this.textBox31.TabIndex = 3;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label61.Location = new System.Drawing.Point(33, 27);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(57, 24);
            this.label61.TabIndex = 2;
            this.label61.Text = "Z上位";
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(96, 54);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(100, 31);
            this.textBox32.TabIndex = 3;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label62.Location = new System.Drawing.Point(202, 27);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(44, 24);
            this.label62.TabIndex = 2;
            this.label62.Text = "mm";
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(96, 24);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(100, 31);
            this.textBox33.TabIndex = 3;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label63.Location = new System.Drawing.Point(33, 57);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(57, 24);
            this.label63.TabIndex = 2;
            this.label63.Text = "Z下位";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label64.Location = new System.Drawing.Point(202, 87);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(44, 24);
            this.label64.TabIndex = 2;
            this.label64.Text = "mm";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label65.Location = new System.Drawing.Point(202, 57);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(44, 24);
            this.label65.TabIndex = 2;
            this.label65.Text = "mm";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label66.Location = new System.Drawing.Point(33, 87);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(58, 24);
            this.label66.TabIndex = 2;
            this.label66.Text = "X工位";
            // 
            // groupBox12
            // 
            this.groupBox12.BackgroundImage = global::Test.Properties.Resources.缓存;
            this.groupBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox12.Controls.Add(this.textBox34);
            this.groupBox12.Controls.Add(this.label67);
            this.groupBox12.Controls.Add(this.textBox35);
            this.groupBox12.Controls.Add(this.label68);
            this.groupBox12.Controls.Add(this.textBox36);
            this.groupBox12.Controls.Add(this.label69);
            this.groupBox12.Controls.Add(this.label70);
            this.groupBox12.Controls.Add(this.label71);
            this.groupBox12.Controls.Add(this.label72);
            this.groupBox12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox12.Location = new System.Drawing.Point(300, 745);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(275, 131);
            this.groupBox12.TabIndex = 9;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "缓存六";
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(96, 84);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(100, 31);
            this.textBox34.TabIndex = 3;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label67.Location = new System.Drawing.Point(33, 27);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(57, 24);
            this.label67.TabIndex = 2;
            this.label67.Text = "Z上位";
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(96, 54);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(100, 31);
            this.textBox35.TabIndex = 3;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label68.Location = new System.Drawing.Point(202, 27);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(44, 24);
            this.label68.TabIndex = 2;
            this.label68.Text = "mm";
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(96, 24);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(100, 31);
            this.textBox36.TabIndex = 3;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label69.Location = new System.Drawing.Point(33, 57);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(57, 24);
            this.label69.TabIndex = 2;
            this.label69.Text = "Z下位";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label70.Location = new System.Drawing.Point(202, 87);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(44, 24);
            this.label70.TabIndex = 2;
            this.label70.Text = "mm";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label71.Location = new System.Drawing.Point(202, 57);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(44, 24);
            this.label71.TabIndex = 2;
            this.label71.Text = "mm";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label72.Location = new System.Drawing.Point(33, 87);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(58, 24);
            this.label72.TabIndex = 2;
            this.label72.Text = "X工位";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label73.Location = new System.Drawing.Point(13, 12);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(96, 28);
            this.label73.TabIndex = 10;
            this.label73.Text = "位置参数";
            // 
            // label74
            // 
            this.label74.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label74.Dock = System.Windows.Forms.DockStyle.Top;
            this.label74.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label74.Location = new System.Drawing.Point(0, 0);
            this.label74.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(1184, 2);
            this.label74.TabIndex = 31;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label75.Location = new System.Drawing.Point(609, 12);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(96, 28);
            this.label75.TabIndex = 10;
            this.label75.Text = "运动参数";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label76.Location = new System.Drawing.Point(894, 12);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(96, 28);
            this.label76.TabIndex = 10;
            this.label76.Text = "扩展参数";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.button2);
            this.groupBox13.Controls.Add(this.button1);
            this.groupBox13.Controls.Add(this.label84);
            this.groupBox13.Controls.Add(this.label82);
            this.groupBox13.Controls.Add(this.label80);
            this.groupBox13.Controls.Add(this.label78);
            this.groupBox13.Controls.Add(this.textBox40);
            this.groupBox13.Controls.Add(this.label83);
            this.groupBox13.Controls.Add(this.textBox39);
            this.groupBox13.Controls.Add(this.label81);
            this.groupBox13.Controls.Add(this.textBox38);
            this.groupBox13.Controls.Add(this.label79);
            this.groupBox13.Controls.Add(this.textBox37);
            this.groupBox13.Controls.Add(this.label77);
            this.groupBox13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox13.Location = new System.Drawing.Point(581, 51);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(272, 248);
            this.groupBox13.TabIndex = 32;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "升降轴";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(92, 24);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(100, 31);
            this.textBox37.TabIndex = 3;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label77.Location = new System.Drawing.Point(198, 27);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(67, 24);
            this.label77.TabIndex = 2;
            this.label77.Text = "mm/s²";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label78.Location = new System.Drawing.Point(27, 27);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(64, 24);
            this.label78.TabIndex = 2;
            this.label78.Text = "加速度";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label79.Location = new System.Drawing.Point(198, 57);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(44, 24);
            this.label79.TabIndex = 2;
            this.label79.Text = "mm";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(92, 54);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(100, 31);
            this.textBox38.TabIndex = 3;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label80.Location = new System.Drawing.Point(9, 57);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(82, 24);
            this.label80.TabIndex = 2;
            this.label80.Text = "正软极限";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label81.Location = new System.Drawing.Point(198, 87);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(44, 24);
            this.label81.TabIndex = 2;
            this.label81.Text = "mm";
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(92, 84);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(100, 31);
            this.textBox39.TabIndex = 3;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label82.Location = new System.Drawing.Point(9, 87);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(82, 24);
            this.label82.TabIndex = 2;
            this.label82.Text = "负软极限";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label83.Location = new System.Drawing.Point(198, 117);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(26, 24);
            this.label83.TabIndex = 2;
            this.label83.Text = "%";
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(92, 114);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(100, 31);
            this.textBox40.TabIndex = 3;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label84.Location = new System.Drawing.Point(9, 117);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(82, 24);
            this.label84.TabIndex = 2;
            this.label84.Text = "最大力矩";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.button1.Location = new System.Drawing.Point(74, 149);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 37);
            this.button1.TabIndex = 4;
            this.button1.Text = "扭矩保护使能";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.button2.Location = new System.Drawing.Point(74, 187);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 37);
            this.button2.TabIndex = 4;
            this.button2.Text = "回原点";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.button3);
            this.groupBox14.Controls.Add(this.button4);
            this.groupBox14.Controls.Add(this.label85);
            this.groupBox14.Controls.Add(this.label86);
            this.groupBox14.Controls.Add(this.label87);
            this.groupBox14.Controls.Add(this.label88);
            this.groupBox14.Controls.Add(this.textBox41);
            this.groupBox14.Controls.Add(this.label89);
            this.groupBox14.Controls.Add(this.textBox42);
            this.groupBox14.Controls.Add(this.label90);
            this.groupBox14.Controls.Add(this.textBox43);
            this.groupBox14.Controls.Add(this.label91);
            this.groupBox14.Controls.Add(this.textBox44);
            this.groupBox14.Controls.Add(this.label92);
            this.groupBox14.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox14.Location = new System.Drawing.Point(581, 325);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(272, 248);
            this.groupBox14.TabIndex = 32;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "水平轴";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.button3.Location = new System.Drawing.Point(74, 187);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(118, 37);
            this.button3.TabIndex = 4;
            this.button3.Text = "回原点";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.button4.Location = new System.Drawing.Point(74, 149);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(118, 37);
            this.button4.TabIndex = 4;
            this.button4.Text = "扭矩保护使能";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label85.Location = new System.Drawing.Point(9, 117);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(82, 24);
            this.label85.TabIndex = 2;
            this.label85.Text = "最大力矩";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label86.Location = new System.Drawing.Point(9, 87);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(82, 24);
            this.label86.TabIndex = 2;
            this.label86.Text = "负软极限";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label87.Location = new System.Drawing.Point(9, 57);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(82, 24);
            this.label87.TabIndex = 2;
            this.label87.Text = "正软极限";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label88.Location = new System.Drawing.Point(27, 27);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(64, 24);
            this.label88.TabIndex = 2;
            this.label88.Text = "加速度";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(92, 114);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(100, 31);
            this.textBox41.TabIndex = 3;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label89.Location = new System.Drawing.Point(198, 117);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(26, 24);
            this.label89.TabIndex = 2;
            this.label89.Text = "%";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(92, 84);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(100, 31);
            this.textBox42.TabIndex = 3;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label90.Location = new System.Drawing.Point(198, 87);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(44, 24);
            this.label90.TabIndex = 2;
            this.label90.Text = "mm";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(92, 54);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(100, 31);
            this.textBox43.TabIndex = 3;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label91.Location = new System.Drawing.Point(198, 57);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(44, 24);
            this.label91.TabIndex = 2;
            this.label91.Text = "mm";
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(92, 24);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(100, 31);
            this.textBox44.TabIndex = 3;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label92.Location = new System.Drawing.Point(198, 27);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(67, 24);
            this.label92.TabIndex = 2;
            this.label92.Text = "mm/s²";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.button5);
            this.groupBox15.Controls.Add(this.button6);
            this.groupBox15.Controls.Add(this.label93);
            this.groupBox15.Controls.Add(this.label94);
            this.groupBox15.Controls.Add(this.label95);
            this.groupBox15.Controls.Add(this.label96);
            this.groupBox15.Controls.Add(this.textBox45);
            this.groupBox15.Controls.Add(this.label97);
            this.groupBox15.Controls.Add(this.textBox46);
            this.groupBox15.Controls.Add(this.label98);
            this.groupBox15.Controls.Add(this.textBox47);
            this.groupBox15.Controls.Add(this.label99);
            this.groupBox15.Controls.Add(this.textBox48);
            this.groupBox15.Controls.Add(this.label100);
            this.groupBox15.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox15.Location = new System.Drawing.Point(581, 599);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(272, 257);
            this.groupBox15.TabIndex = 32;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "输送机";
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.button5.Location = new System.Drawing.Point(74, 187);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(118, 37);
            this.button5.TabIndex = 4;
            this.button5.Text = "回原点";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.button6.Location = new System.Drawing.Point(74, 149);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(118, 37);
            this.button6.TabIndex = 4;
            this.button6.Text = "扭矩保护使能";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label93.Location = new System.Drawing.Point(9, 117);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(82, 24);
            this.label93.TabIndex = 2;
            this.label93.Text = "最大力矩";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label94.Location = new System.Drawing.Point(9, 87);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(82, 24);
            this.label94.TabIndex = 2;
            this.label94.Text = "负软极限";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label95.Location = new System.Drawing.Point(9, 57);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(82, 24);
            this.label95.TabIndex = 2;
            this.label95.Text = "正软极限";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label96.Location = new System.Drawing.Point(27, 27);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(64, 24);
            this.label96.TabIndex = 2;
            this.label96.Text = "加速度";
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(92, 114);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(100, 31);
            this.textBox45.TabIndex = 3;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label97.Location = new System.Drawing.Point(198, 117);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(26, 24);
            this.label97.TabIndex = 2;
            this.label97.Text = "%";
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(92, 84);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(100, 31);
            this.textBox46.TabIndex = 3;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label98.Location = new System.Drawing.Point(198, 87);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(44, 24);
            this.label98.TabIndex = 2;
            this.label98.Text = "mm";
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(92, 54);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(100, 31);
            this.textBox47.TabIndex = 3;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label99.Location = new System.Drawing.Point(198, 57);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(44, 24);
            this.label99.TabIndex = 2;
            this.label99.Text = "mm";
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(92, 24);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(100, 31);
            this.textBox48.TabIndex = 3;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label100.Location = new System.Drawing.Point(198, 27);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(67, 24);
            this.label100.TabIndex = 2;
            this.label100.Text = "mm/s²";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.label105);
            this.groupBox16.Controls.Add(this.label101);
            this.groupBox16.Controls.Add(this.label132);
            this.groupBox16.Controls.Add(this.label131);
            this.groupBox16.Controls.Add(this.label126);
            this.groupBox16.Controls.Add(this.label130);
            this.groupBox16.Controls.Add(this.label124);
            this.groupBox16.Controls.Add(this.label122);
            this.groupBox16.Controls.Add(this.label120);
            this.groupBox16.Controls.Add(this.label116);
            this.groupBox16.Controls.Add(this.label112);
            this.groupBox16.Controls.Add(this.label108);
            this.groupBox16.Controls.Add(this.textBox49);
            this.groupBox16.Controls.Add(this.label119);
            this.groupBox16.Controls.Add(this.label115);
            this.groupBox16.Controls.Add(this.label111);
            this.groupBox16.Controls.Add(this.label107);
            this.groupBox16.Controls.Add(this.label102);
            this.groupBox16.Controls.Add(this.label106);
            this.groupBox16.Controls.Add(this.label118);
            this.groupBox16.Controls.Add(this.textBox64);
            this.groupBox16.Controls.Add(this.label114);
            this.groupBox16.Controls.Add(this.textBox61);
            this.groupBox16.Controls.Add(this.textBox63);
            this.groupBox16.Controls.Add(this.label110);
            this.groupBox16.Controls.Add(this.textBox62);
            this.groupBox16.Controls.Add(this.textBox60);
            this.groupBox16.Controls.Add(this.textBox59);
            this.groupBox16.Controls.Add(this.textBox50);
            this.groupBox16.Controls.Add(this.textBox58);
            this.groupBox16.Controls.Add(this.textBox56);
            this.groupBox16.Controls.Add(this.label129);
            this.groupBox16.Controls.Add(this.textBox54);
            this.groupBox16.Controls.Add(this.label125);
            this.groupBox16.Controls.Add(this.label128);
            this.groupBox16.Controls.Add(this.label103);
            this.groupBox16.Controls.Add(this.label123);
            this.groupBox16.Controls.Add(this.label127);
            this.groupBox16.Controls.Add(this.textBox57);
            this.groupBox16.Controls.Add(this.label121);
            this.groupBox16.Controls.Add(this.textBox55);
            this.groupBox16.Controls.Add(this.label117);
            this.groupBox16.Controls.Add(this.textBox53);
            this.groupBox16.Controls.Add(this.label113);
            this.groupBox16.Controls.Add(this.textBox52);
            this.groupBox16.Controls.Add(this.label109);
            this.groupBox16.Controls.Add(this.textBox51);
            this.groupBox16.Controls.Add(this.label104);
            this.groupBox16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox16.Location = new System.Drawing.Point(859, 51);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(311, 825);
            this.groupBox16.TabIndex = 33;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "扩展";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label101.Location = new System.Drawing.Point(246, 27);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(60, 24);
            this.label101.TabIndex = 2;
            this.label101.Text = "mm/s";
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(141, 24);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(100, 31);
            this.textBox49.TabIndex = 3;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label102.Location = new System.Drawing.Point(246, 57);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(60, 24);
            this.label102.TabIndex = 2;
            this.label102.Text = "mm/s";
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(141, 54);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(100, 31);
            this.textBox50.TabIndex = 3;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label103.Location = new System.Drawing.Point(246, 94);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(60, 24);
            this.label103.TabIndex = 2;
            this.label103.Text = "mm/s";
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(141, 91);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(100, 31);
            this.textBox51.TabIndex = 3;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label104.Location = new System.Drawing.Point(246, 124);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(60, 24);
            this.label104.TabIndex = 2;
            this.label104.Text = "mm/s";
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(141, 121);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(100, 31);
            this.textBox52.TabIndex = 3;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label105.Location = new System.Drawing.Point(28, 27);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(112, 24);
            this.label105.TabIndex = 2;
            this.label105.Text = "X轴无舟速度";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label106.Location = new System.Drawing.Point(28, 57);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(112, 24);
            this.label106.TabIndex = 2;
            this.label106.Text = "X轴有舟速度";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label107.Location = new System.Drawing.Point(4, 95);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(136, 24);
            this.label107.TabIndex = 2;
            this.label107.Text = "输送机快速速度";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label108.Location = new System.Drawing.Point(4, 124);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(136, 24);
            this.label108.TabIndex = 2;
            this.label108.Text = "输送机慢速速度";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label109.Location = new System.Drawing.Point(246, 191);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(67, 24);
            this.label109.TabIndex = 2;
            this.label109.Text = "mm/s²";
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(141, 158);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(100, 31);
            this.textBox53.TabIndex = 3;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(141, 188);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(100, 31);
            this.textBox54.TabIndex = 3;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label110.Location = new System.Drawing.Point(246, 161);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(67, 24);
            this.label110.TabIndex = 2;
            this.label110.Text = "mm/s²";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label111.Location = new System.Drawing.Point(4, 162);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(130, 24);
            this.label111.TabIndex = 2;
            this.label111.Text = "X轴快速加速度";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label112.Location = new System.Drawing.Point(4, 191);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(130, 24);
            this.label112.TabIndex = 2;
            this.label112.Text = "X轴慢速加速度";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label113.Location = new System.Drawing.Point(246, 258);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(67, 24);
            this.label113.TabIndex = 2;
            this.label113.Text = "mm/s²";
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(141, 225);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(100, 31);
            this.textBox55.TabIndex = 3;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(141, 255);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(100, 31);
            this.textBox56.TabIndex = 3;
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label114.Location = new System.Drawing.Point(246, 228);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(67, 24);
            this.label114.TabIndex = 2;
            this.label114.Text = "mm/s²";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label115.Location = new System.Drawing.Point(4, 229);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(129, 24);
            this.label115.TabIndex = 2;
            this.label115.Text = "Z轴快速加速度";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label116.Location = new System.Drawing.Point(4, 258);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(129, 24);
            this.label116.TabIndex = 2;
            this.label116.Text = "Z轴慢速加速度";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label117.Location = new System.Drawing.Point(246, 356);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(44, 24);
            this.label117.TabIndex = 2;
            this.label117.Text = "mm";
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(141, 292);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(100, 31);
            this.textBox57.TabIndex = 3;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(141, 353);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(100, 31);
            this.textBox58.TabIndex = 3;
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label118.Location = new System.Drawing.Point(246, 295);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(44, 24);
            this.label118.TabIndex = 2;
            this.label118.Text = "mm";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label119.Location = new System.Drawing.Point(13, 295);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(118, 24);
            this.label119.TabIndex = 2;
            this.label119.Text = "磁栅尺分辨率";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label120.Location = new System.Drawing.Point(13, 326);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(190, 24);
            this.label120.TabIndex = 2;
            this.label120.Text = "编码器与磁尺最大偏差";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label121.Location = new System.Drawing.Point(246, 424);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(60, 24);
            this.label121.TabIndex = 2;
            this.label121.Text = "mm/s";
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(141, 421);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(100, 31);
            this.textBox59.TabIndex = 3;
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label122.Location = new System.Drawing.Point(13, 394);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(231, 24);
            this.label122.TabIndex = 2;
            this.label122.Text = "X轴在通道位，Z轴无舟速度";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label123.Location = new System.Drawing.Point(246, 485);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(60, 24);
            this.label123.TabIndex = 2;
            this.label123.Text = "mm/s";
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(141, 482);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(100, 31);
            this.textBox60.TabIndex = 3;
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label124.Location = new System.Drawing.Point(10, 455);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(231, 24);
            this.label124.TabIndex = 2;
            this.label124.Text = "X轴在通道位，Z轴有舟速度";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label125.Location = new System.Drawing.Point(246, 546);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(60, 24);
            this.label125.TabIndex = 2;
            this.label125.Text = "mm/s";
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(141, 543);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(100, 31);
            this.textBox61.TabIndex = 3;
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label126.Location = new System.Drawing.Point(10, 516);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(213, 24);
            this.label126.TabIndex = 2;
            this.label126.Text = "X轴在侧边，Z轴无舟速度";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label127.Location = new System.Drawing.Point(246, 616);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(44, 24);
            this.label127.TabIndex = 2;
            this.label127.Text = "mm";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label128.Location = new System.Drawing.Point(246, 677);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(44, 24);
            this.label128.TabIndex = 2;
            this.label128.Text = "mm";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label129.Location = new System.Drawing.Point(246, 738);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(44, 24);
            this.label129.TabIndex = 2;
            this.label129.Text = "mm";
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(141, 613);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(100, 31);
            this.textBox62.TabIndex = 3;
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(141, 674);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(100, 31);
            this.textBox63.TabIndex = 3;
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(141, 735);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(100, 31);
            this.textBox64.TabIndex = 3;
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label130.Location = new System.Drawing.Point(13, 586);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(255, 24);
            this.label130.TabIndex = 2;
            this.label130.Text = "从桨取舟时相对Z轴下位的偏差";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label131.Location = new System.Drawing.Point(10, 647);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(273, 24);
            this.label131.TabIndex = 2;
            this.label131.Text = "从缓存取舟时相对Z轴下位的偏差";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label132.Location = new System.Drawing.Point(10, 708);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(291, 24);
            this.label132.TabIndex = 2;
            this.label132.Text = "从输送位取舟时相对Z舟下位的偏差";
            // 
            // UCSetAxisPara
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox16);
            this.Controls.Add(this.groupBox15);
            this.Controls.Add(this.groupBox14);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.label74);
            this.Controls.Add(this.label76);
            this.Controls.Add(this.label75);
            this.Controls.Add(this.label73);
            this.Controls.Add(this.groupBox12);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "UCSetAxisPara";
            this.Size = new System.Drawing.Size(1184, 985);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label121;
    }
}

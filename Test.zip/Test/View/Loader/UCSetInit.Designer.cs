﻿namespace Test.View.Loader
{
    partial class UCSetInit
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.ucSignalLamp5 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp4 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp3 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp2 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp1 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp6 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp7 = new HZH_Controls.Controls.UCSignalLamp();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button5.Location = new System.Drawing.Point(16, 178);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(135, 34);
            this.button5.TabIndex = 37;
            this.button5.Text = "炉管5通讯";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button4.Location = new System.Drawing.Point(16, 138);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(135, 34);
            this.button4.TabIndex = 38;
            this.button4.Text = "炉管4通讯";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(16, 98);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(135, 34);
            this.button3.TabIndex = 39;
            this.button3.Text = "炉管3通讯";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(16, 57);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(135, 34);
            this.button2.TabIndex = 40;
            this.button2.Text = "炉管2通讯";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(16, 16);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(135, 34);
            this.button1.TabIndex = 41;
            this.button1.Text = "炉管1通讯";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // ucSignalLamp5
            // 
            this.ucSignalLamp5.IsHighlight = true;
            this.ucSignalLamp5.IsShowBorder = false;
            this.ucSignalLamp5.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp5.Location = new System.Drawing.Point(160, 183);
            this.ucSignalLamp5.Margin = new System.Windows.Forms.Padding(4);
            this.ucSignalLamp5.Name = "ucSignalLamp5";
            this.ucSignalLamp5.Size = new System.Drawing.Size(30, 30);
            this.ucSignalLamp5.TabIndex = 32;
            this.ucSignalLamp5.TwinkleSpeed = 0;
            // 
            // ucSignalLamp4
            // 
            this.ucSignalLamp4.IsHighlight = true;
            this.ucSignalLamp4.IsShowBorder = false;
            this.ucSignalLamp4.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp4.Location = new System.Drawing.Point(160, 142);
            this.ucSignalLamp4.Margin = new System.Windows.Forms.Padding(4);
            this.ucSignalLamp4.Name = "ucSignalLamp4";
            this.ucSignalLamp4.Size = new System.Drawing.Size(30, 30);
            this.ucSignalLamp4.TabIndex = 33;
            this.ucSignalLamp4.TwinkleSpeed = 0;
            // 
            // ucSignalLamp3
            // 
            this.ucSignalLamp3.IsHighlight = true;
            this.ucSignalLamp3.IsShowBorder = false;
            this.ucSignalLamp3.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp3.Location = new System.Drawing.Point(160, 102);
            this.ucSignalLamp3.Margin = new System.Windows.Forms.Padding(4);
            this.ucSignalLamp3.Name = "ucSignalLamp3";
            this.ucSignalLamp3.Size = new System.Drawing.Size(30, 30);
            this.ucSignalLamp3.TabIndex = 34;
            this.ucSignalLamp3.TwinkleSpeed = 0;
            // 
            // ucSignalLamp2
            // 
            this.ucSignalLamp2.IsHighlight = true;
            this.ucSignalLamp2.IsShowBorder = false;
            this.ucSignalLamp2.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp2.Location = new System.Drawing.Point(160, 62);
            this.ucSignalLamp2.Margin = new System.Windows.Forms.Padding(4);
            this.ucSignalLamp2.Name = "ucSignalLamp2";
            this.ucSignalLamp2.Size = new System.Drawing.Size(30, 30);
            this.ucSignalLamp2.TabIndex = 35;
            this.ucSignalLamp2.TwinkleSpeed = 0;
            // 
            // ucSignalLamp1
            // 
            this.ucSignalLamp1.IsHighlight = true;
            this.ucSignalLamp1.IsShowBorder = false;
            this.ucSignalLamp1.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp1.Location = new System.Drawing.Point(160, 21);
            this.ucSignalLamp1.Margin = new System.Windows.Forms.Padding(4);
            this.ucSignalLamp1.Name = "ucSignalLamp1";
            this.ucSignalLamp1.Size = new System.Drawing.Size(30, 30);
            this.ucSignalLamp1.TabIndex = 36;
            this.ucSignalLamp1.TwinkleSpeed = 0;
            // 
            // ucSignalLamp6
            // 
            this.ucSignalLamp6.IsHighlight = true;
            this.ucSignalLamp6.IsShowBorder = false;
            this.ucSignalLamp6.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp6.Location = new System.Drawing.Point(160, 222);
            this.ucSignalLamp6.Margin = new System.Windows.Forms.Padding(4);
            this.ucSignalLamp6.Name = "ucSignalLamp6";
            this.ucSignalLamp6.Size = new System.Drawing.Size(30, 30);
            this.ucSignalLamp6.TabIndex = 33;
            this.ucSignalLamp6.TwinkleSpeed = 0;
            // 
            // ucSignalLamp7
            // 
            this.ucSignalLamp7.IsHighlight = true;
            this.ucSignalLamp7.IsShowBorder = false;
            this.ucSignalLamp7.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.Silver,
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp7.Location = new System.Drawing.Point(160, 263);
            this.ucSignalLamp7.Margin = new System.Windows.Forms.Padding(4);
            this.ucSignalLamp7.Name = "ucSignalLamp7";
            this.ucSignalLamp7.Size = new System.Drawing.Size(30, 30);
            this.ucSignalLamp7.TabIndex = 32;
            this.ucSignalLamp7.TwinkleSpeed = 0;
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button6.Location = new System.Drawing.Point(16, 218);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(135, 34);
            this.button6.TabIndex = 38;
            this.button6.Text = "机械手通讯";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button7.Location = new System.Drawing.Point(16, 258);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(135, 34);
            this.button7.TabIndex = 37;
            this.button7.Text = "输送机通讯";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // UCSetInit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.ucSignalLamp7);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ucSignalLamp6);
            this.Controls.Add(this.ucSignalLamp5);
            this.Controls.Add(this.ucSignalLamp4);
            this.Controls.Add(this.ucSignalLamp3);
            this.Controls.Add(this.ucSignalLamp2);
            this.Controls.Add(this.ucSignalLamp1);
            this.Name = "UCSetInit";
            this.Size = new System.Drawing.Size(1051, 993);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp5;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp4;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp3;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp2;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp1;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp6;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
    }
}

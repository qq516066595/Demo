﻿namespace Test.View.Loader
{
    partial class UCMain
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label27 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.ucSwitch5 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch1 = new HZH_Controls.Controls.UCSwitch();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.ucPanelTitle5 = new HZH_Controls.Controls.UCPanelTitle();
            this.label79 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label71 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.ucPanelTitle1 = new HZH_Controls.Controls.UCPanelTitle();
            this.label80 = new System.Windows.Forms.Label();
            this.button30 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.ucPanelTitle2 = new HZH_Controls.Controls.UCPanelTitle();
            this.label93 = new System.Windows.Forms.Label();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label94 = new System.Windows.Forms.Label();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox14.SuspendLayout();
            this.ucPanelTitle5.SuspendLayout();
            this.ucPanelTitle1.SuspendLayout();
            this.ucPanelTitle2.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label27
            // 
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label27.Dock = System.Windows.Forms.DockStyle.Top;
            this.label27.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(0, 0);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(1394, 2);
            this.label27.TabIndex = 5;
            // 
            // groupBox14
            // 
            this.groupBox14.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox14.Controls.Add(this.button1);
            this.groupBox14.Controls.Add(this.label56);
            this.groupBox14.Controls.Add(this.label55);
            this.groupBox14.Controls.Add(this.label54);
            this.groupBox14.Controls.Add(this.comboBox15);
            this.groupBox14.Controls.Add(this.comboBox14);
            this.groupBox14.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox14.Location = new System.Drawing.Point(348, 53);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(333, 335);
            this.groupBox14.TabIndex = 7;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "手动搬舟";
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.button1.Location = new System.Drawing.Point(126, 129);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 41);
            this.button1.TabIndex = 5;
            this.button1.Text = "搬舟启动";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label56.ForeColor = System.Drawing.Color.Red;
            this.label56.Location = new System.Drawing.Point(6, 182);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(388, 144);
            this.label56.TabIndex = 4;
            this.label56.Text = "注意：\r\n若需中途中止手动搬舟路径，请按下急停按钮，\r\n并在设置--初始化页面点击搬舟初始化，然后\r\n弹起急停，按下复位。\r\n操作条件：\r\n①机械手无搬舟任务；②" +
    "桨在取舟位。";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label55.Location = new System.Drawing.Point(73, 83);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(82, 24);
            this.label55.TabIndex = 4;
            this.label55.Text = "放舟位：";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label54.Location = new System.Drawing.Point(73, 44);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(82, 24);
            this.label54.TabIndex = 4;
            this.label54.Text = "取舟位：";
            // 
            // comboBox15
            // 
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.Items.AddRange(new object[] {
            " ",
            "炉管1",
            "炉管2",
            "炉管3",
            "炉管4",
            "炉管5",
            "缓存1",
            "缓存2",
            "缓存3",
            "缓存4",
            "缓存5",
            "缓存6",
            "输送位",
            "机械手"});
            this.comboBox15.Location = new System.Drawing.Point(156, 79);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(121, 33);
            this.comboBox15.TabIndex = 3;
            // 
            // comboBox14
            // 
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Items.AddRange(new object[] {
            " ",
            "炉管1",
            "炉管2",
            "炉管3",
            "炉管4",
            "炉管5",
            "缓存1",
            "缓存2",
            "缓存3",
            "缓存4",
            "缓存5",
            "缓存6",
            "输送位",
            "机械手"});
            this.comboBox14.Location = new System.Drawing.Point(156, 40);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(121, 33);
            this.comboBox14.TabIndex = 3;
            // 
            // label57
            // 
            this.label57.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label57.Location = new System.Drawing.Point(1048, 107);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(325, 1);
            this.label57.TabIndex = 8;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label58.Location = new System.Drawing.Point(1044, 36);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(46, 48);
            this.label58.TabIndex = 9;
            this.label58.Text = "门禁\r\n屏蔽";
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.Color.LightGray;
            this.label59.Location = new System.Drawing.Point(1096, 35);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(24, 23);
            this.label59.TabIndex = 10;
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.Color.LightGray;
            this.label60.Location = new System.Drawing.Point(1096, 62);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(24, 23);
            this.label60.TabIndex = 10;
            // 
            // label61
            // 
            this.label61.BackColor = System.Drawing.Color.LightGray;
            this.label61.Location = new System.Drawing.Point(1126, 35);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(24, 23);
            this.label61.TabIndex = 10;
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.Color.LightGray;
            this.label62.Location = new System.Drawing.Point(1126, 62);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(24, 23);
            this.label62.TabIndex = 10;
            // 
            // label63
            // 
            this.label63.BackColor = System.Drawing.Color.LightGray;
            this.label63.Location = new System.Drawing.Point(1156, 35);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(24, 23);
            this.label63.TabIndex = 10;
            // 
            // label64
            // 
            this.label64.BackColor = System.Drawing.Color.LightGray;
            this.label64.Location = new System.Drawing.Point(1156, 62);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(24, 23);
            this.label64.TabIndex = 10;
            // 
            // ucSwitch5
            // 
            this.ucSwitch5.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch5.Checked = false;
            this.ucSwitch5.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch5.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch5.Location = new System.Drawing.Point(1201, 26);
            this.ucSwitch5.Name = "ucSwitch5";
            this.ucSwitch5.Size = new System.Drawing.Size(86, 32);
            this.ucSwitch5.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch5.TabIndex = 15;
            this.ucSwitch5.Texts = new string[0];
            this.ucSwitch5.TrueColor = System.Drawing.Color.LimeGreen;
            this.ucSwitch5.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch1
            // 
            this.ucSwitch1.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch1.Checked = false;
            this.ucSwitch1.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch1.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch1.Location = new System.Drawing.Point(1201, 64);
            this.ucSwitch1.Name = "ucSwitch1";
            this.ucSwitch1.Size = new System.Drawing.Size(86, 32);
            this.ucSwitch1.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch1.TabIndex = 15;
            this.ucSwitch1.Texts = new string[0];
            this.ucSwitch1.TrueColor = System.Drawing.Color.LimeGreen;
            this.ucSwitch1.TrueTextColr = System.Drawing.Color.White;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label65.Location = new System.Drawing.Point(1293, 30);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(82, 24);
            this.label65.TabIndex = 9;
            this.label65.Text = "手动模式";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label66.Location = new System.Drawing.Point(1291, 68);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(82, 24);
            this.label66.TabIndex = 9;
            this.label66.Text = "门禁屏蔽";
            // 
            // ucPanelTitle5
            // 
            this.ucPanelTitle5.BackColor = System.Drawing.Color.Transparent;
            this.ucPanelTitle5.BorderColor = System.Drawing.Color.Silver;
            this.ucPanelTitle5.ConerRadius = 10;
            this.ucPanelTitle5.Controls.Add(this.label79);
            this.ucPanelTitle5.Controls.Add(this.button4);
            this.ucPanelTitle5.Controls.Add(this.button29);
            this.ucPanelTitle5.Controls.Add(this.button25);
            this.ucPanelTitle5.Controls.Add(this.button21);
            this.ucPanelTitle5.Controls.Add(this.button17);
            this.ucPanelTitle5.Controls.Add(this.button13);
            this.ucPanelTitle5.Controls.Add(this.button9);
            this.ucPanelTitle5.Controls.Add(this.button28);
            this.ucPanelTitle5.Controls.Add(this.button24);
            this.ucPanelTitle5.Controls.Add(this.button20);
            this.ucPanelTitle5.Controls.Add(this.button16);
            this.ucPanelTitle5.Controls.Add(this.button12);
            this.ucPanelTitle5.Controls.Add(this.button7);
            this.ucPanelTitle5.Controls.Add(this.button27);
            this.ucPanelTitle5.Controls.Add(this.button23);
            this.ucPanelTitle5.Controls.Add(this.button19);
            this.ucPanelTitle5.Controls.Add(this.button15);
            this.ucPanelTitle5.Controls.Add(this.button11);
            this.ucPanelTitle5.Controls.Add(this.button8);
            this.ucPanelTitle5.Controls.Add(this.button26);
            this.ucPanelTitle5.Controls.Add(this.button22);
            this.ucPanelTitle5.Controls.Add(this.button18);
            this.ucPanelTitle5.Controls.Add(this.button14);
            this.ucPanelTitle5.Controls.Add(this.button10);
            this.ucPanelTitle5.Controls.Add(this.button6);
            this.ucPanelTitle5.Controls.Add(this.button5);
            this.ucPanelTitle5.Controls.Add(this.textBox14);
            this.ucPanelTitle5.Controls.Add(this.label78);
            this.ucPanelTitle5.Controls.Add(this.button2);
            this.ucPanelTitle5.Controls.Add(this.button3);
            this.ucPanelTitle5.Controls.Add(this.label71);
            this.ucPanelTitle5.Controls.Add(this.label76);
            this.ucPanelTitle5.Controls.Add(this.label77);
            this.ucPanelTitle5.Controls.Add(this.label75);
            this.ucPanelTitle5.Controls.Add(this.label69);
            this.ucPanelTitle5.Controls.Add(this.label74);
            this.ucPanelTitle5.Controls.Add(this.label67);
            this.ucPanelTitle5.Controls.Add(this.label73);
            this.ucPanelTitle5.Controls.Add(this.label68);
            this.ucPanelTitle5.Controls.Add(this.label70);
            this.ucPanelTitle5.Controls.Add(this.label72);
            this.ucPanelTitle5.FillColor = System.Drawing.Color.Transparent;
            this.ucPanelTitle5.Font = new System.Drawing.Font("微软雅黑", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucPanelTitle5.IsCanExpand = true;
            this.ucPanelTitle5.IsExpand = true;
            this.ucPanelTitle5.IsRadius = true;
            this.ucPanelTitle5.IsShowRect = true;
            this.ucPanelTitle5.Location = new System.Drawing.Point(1048, 113);
            this.ucPanelTitle5.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.ucPanelTitle5.Name = "ucPanelTitle5";
            this.ucPanelTitle5.Padding = new System.Windows.Forms.Padding(2);
            this.ucPanelTitle5.RectColor = System.Drawing.Color.Silver;
            this.ucPanelTitle5.RectWidth = 1;
            this.ucPanelTitle5.Size = new System.Drawing.Size(325, 704);
            this.ucPanelTitle5.TabIndex = 23;
            this.ucPanelTitle5.Title = "垂直轴";
            // 
            // label79
            // 
            this.label79.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label79.Location = new System.Drawing.Point(14, 209);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(230, 1);
            this.label79.TabIndex = 32;
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(137, 179);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 25);
            this.button4.TabIndex = 30;
            this.button4.Text = "后  退";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button29.ForeColor = System.Drawing.Color.Black;
            this.button29.Location = new System.Drawing.Point(137, 556);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(75, 25);
            this.button29.TabIndex = 31;
            this.button29.Text = "缓存6下";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button25.ForeColor = System.Drawing.Color.Black;
            this.button25.Location = new System.Drawing.Point(137, 494);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(75, 25);
            this.button25.TabIndex = 31;
            this.button25.Text = "缓存5下";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button21.ForeColor = System.Drawing.Color.Black;
            this.button21.Location = new System.Drawing.Point(137, 432);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(75, 25);
            this.button21.TabIndex = 31;
            this.button21.Text = "缓存4下";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button17.ForeColor = System.Drawing.Color.Black;
            this.button17.Location = new System.Drawing.Point(137, 370);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 25);
            this.button17.TabIndex = 31;
            this.button17.Text = "缓存3下";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button13.ForeColor = System.Drawing.Color.Black;
            this.button13.Location = new System.Drawing.Point(137, 308);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 25);
            this.button13.TabIndex = 31;
            this.button13.Text = "缓存2下";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button9.ForeColor = System.Drawing.Color.Black;
            this.button9.Location = new System.Drawing.Point(137, 246);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 25);
            this.button9.TabIndex = 31;
            this.button9.Text = "缓存1下";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button28.ForeColor = System.Drawing.Color.Black;
            this.button28.Location = new System.Drawing.Point(31, 556);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(75, 25);
            this.button28.TabIndex = 31;
            this.button28.Text = "输送位下";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button24.ForeColor = System.Drawing.Color.Black;
            this.button24.Location = new System.Drawing.Point(31, 494);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(75, 25);
            this.button24.TabIndex = 31;
            this.button24.Text = "炉管5下";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button20.ForeColor = System.Drawing.Color.Black;
            this.button20.Location = new System.Drawing.Point(31, 432);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(75, 25);
            this.button20.TabIndex = 31;
            this.button20.Text = "炉管4下";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button16.ForeColor = System.Drawing.Color.Black;
            this.button16.Location = new System.Drawing.Point(31, 370);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 25);
            this.button16.TabIndex = 31;
            this.button16.Text = "炉管3下";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button12.ForeColor = System.Drawing.Color.Black;
            this.button12.Location = new System.Drawing.Point(31, 308);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 25);
            this.button12.TabIndex = 31;
            this.button12.Text = "炉管2下";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button7.ForeColor = System.Drawing.Color.Black;
            this.button7.Location = new System.Drawing.Point(31, 246);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 25);
            this.button7.TabIndex = 31;
            this.button7.Text = "炉管1下";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button27.ForeColor = System.Drawing.Color.Black;
            this.button27.Location = new System.Drawing.Point(137, 525);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(75, 25);
            this.button27.TabIndex = 31;
            this.button27.Text = "缓存6上";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button23.ForeColor = System.Drawing.Color.Black;
            this.button23.Location = new System.Drawing.Point(137, 463);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(75, 25);
            this.button23.TabIndex = 31;
            this.button23.Text = "缓存5上";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button19.ForeColor = System.Drawing.Color.Black;
            this.button19.Location = new System.Drawing.Point(137, 401);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(75, 25);
            this.button19.TabIndex = 31;
            this.button19.Text = "缓存4上";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button15.ForeColor = System.Drawing.Color.Black;
            this.button15.Location = new System.Drawing.Point(137, 339);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 25);
            this.button15.TabIndex = 31;
            this.button15.Text = "缓存3上";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button11.ForeColor = System.Drawing.Color.Black;
            this.button11.Location = new System.Drawing.Point(137, 277);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 25);
            this.button11.TabIndex = 31;
            this.button11.Text = "缓存2上";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button8.ForeColor = System.Drawing.Color.Black;
            this.button8.Location = new System.Drawing.Point(137, 215);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 25);
            this.button8.TabIndex = 31;
            this.button8.Text = "缓存1上";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button26.ForeColor = System.Drawing.Color.Black;
            this.button26.Location = new System.Drawing.Point(31, 525);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(75, 25);
            this.button26.TabIndex = 31;
            this.button26.Text = "输送位上";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button22.ForeColor = System.Drawing.Color.Black;
            this.button22.Location = new System.Drawing.Point(31, 463);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(75, 25);
            this.button22.TabIndex = 31;
            this.button22.Text = "炉管5上";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button18.ForeColor = System.Drawing.Color.Black;
            this.button18.Location = new System.Drawing.Point(31, 401);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 25);
            this.button18.TabIndex = 31;
            this.button18.Text = "炉管4上";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button14.ForeColor = System.Drawing.Color.Black;
            this.button14.Location = new System.Drawing.Point(31, 339);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 25);
            this.button14.TabIndex = 31;
            this.button14.Text = "炉管3上";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button10.ForeColor = System.Drawing.Color.Black;
            this.button10.Location = new System.Drawing.Point(31, 277);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 25);
            this.button10.TabIndex = 31;
            this.button10.Text = "炉管2上";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button6.ForeColor = System.Drawing.Color.Black;
            this.button6.Location = new System.Drawing.Point(31, 215);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 25);
            this.button6.TabIndex = 31;
            this.button6.Text = "炉管1上";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button5.ForeColor = System.Drawing.Color.Black;
            this.button5.Location = new System.Drawing.Point(31, 179);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 25);
            this.button5.TabIndex = 31;
            this.button5.Text = "前  进";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox14.Location = new System.Drawing.Point(141, 147);
            this.textBox14.Margin = new System.Windows.Forms.Padding(2);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(44, 35);
            this.textBox14.TabIndex = 29;
            this.textBox14.Text = "000.0";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label78.ForeColor = System.Drawing.Color.Black;
            this.label78.Location = new System.Drawing.Point(22, 150);
            this.label78.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(190, 28);
            this.label78.TabIndex = 28;
            this.label78.Text = "点动速度(mm/s)：";
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(137, 119);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 25);
            this.button2.TabIndex = 26;
            this.button2.Text = "解除联锁";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(31, 119);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 25);
            this.button3.TabIndex = 27;
            this.button3.Text = "使  能";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.Gray;
            this.label71.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label71.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label71.Location = new System.Drawing.Point(173, 92);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(66, 26);
            this.label71.TabIndex = 23;
            this.label71.Text = "正极限";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.Gray;
            this.label76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label76.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label76.Location = new System.Drawing.Point(105, 92);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(58, 26);
            this.label76.TabIndex = 24;
            this.label76.Text = " 原点 ";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.BackColor = System.Drawing.Color.Gray;
            this.label77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label77.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label77.Location = new System.Drawing.Point(29, 92);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(66, 26);
            this.label77.TabIndex = 25;
            this.label77.Text = "负极限";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label75.ForeColor = System.Drawing.Color.Black;
            this.label75.Location = new System.Drawing.Point(212, 64);
            this.label75.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(54, 24);
            this.label75.TabIndex = 0;
            this.label75.Text = "0000";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label69.ForeColor = System.Drawing.Color.Black;
            this.label69.Location = new System.Drawing.Point(212, 40);
            this.label69.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(54, 24);
            this.label69.TabIndex = 0;
            this.label69.Text = "0000";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label74.ForeColor = System.Drawing.Color.Black;
            this.label74.Location = new System.Drawing.Point(78, 64);
            this.label74.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(54, 24);
            this.label74.TabIndex = 0;
            this.label74.Text = "0000";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label67.ForeColor = System.Drawing.Color.Black;
            this.label67.Location = new System.Drawing.Point(78, 40);
            this.label67.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(54, 24);
            this.label67.TabIndex = 0;
            this.label67.Text = "0000";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label73.ForeColor = System.Drawing.Color.Black;
            this.label73.Location = new System.Drawing.Point(126, 64);
            this.label73.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(102, 24);
            this.label73.TabIndex = 0;
            this.label73.Text = "磁尺( mm )";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label68.ForeColor = System.Drawing.Color.Black;
            this.label68.Location = new System.Drawing.Point(126, 40);
            this.label68.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(108, 24);
            this.label68.TabIndex = 0;
            this.label68.Text = "速度(mm/s)";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label70.ForeColor = System.Drawing.Color.Black;
            this.label70.Location = new System.Drawing.Point(4, 64);
            this.label70.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(94, 24);
            this.label70.TabIndex = 0;
            this.label70.Text = "扭矩(N·m)";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label72.ForeColor = System.Drawing.Color.Black;
            this.label72.Location = new System.Drawing.Point(4, 40);
            this.label72.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(92, 24);
            this.label72.TabIndex = 0;
            this.label72.Text = "位置(mm)";
            // 
            // ucPanelTitle1
            // 
            this.ucPanelTitle1.BackColor = System.Drawing.Color.Transparent;
            this.ucPanelTitle1.BorderColor = System.Drawing.Color.Silver;
            this.ucPanelTitle1.ConerRadius = 10;
            this.ucPanelTitle1.Controls.Add(this.label80);
            this.ucPanelTitle1.Controls.Add(this.button30);
            this.ucPanelTitle1.Controls.Add(this.button34);
            this.ucPanelTitle1.Controls.Add(this.button35);
            this.ucPanelTitle1.Controls.Add(this.button36);
            this.ucPanelTitle1.Controls.Add(this.button40);
            this.ucPanelTitle1.Controls.Add(this.button41);
            this.ucPanelTitle1.Controls.Add(this.button42);
            this.ucPanelTitle1.Controls.Add(this.button46);
            this.ucPanelTitle1.Controls.Add(this.button47);
            this.ucPanelTitle1.Controls.Add(this.button48);
            this.ucPanelTitle1.Controls.Add(this.button51);
            this.ucPanelTitle1.Controls.Add(this.button52);
            this.ucPanelTitle1.Controls.Add(this.button53);
            this.ucPanelTitle1.Controls.Add(this.button54);
            this.ucPanelTitle1.Controls.Add(this.button55);
            this.ucPanelTitle1.Controls.Add(this.textBox15);
            this.ucPanelTitle1.Controls.Add(this.label81);
            this.ucPanelTitle1.Controls.Add(this.button56);
            this.ucPanelTitle1.Controls.Add(this.button57);
            this.ucPanelTitle1.Controls.Add(this.label82);
            this.ucPanelTitle1.Controls.Add(this.label83);
            this.ucPanelTitle1.Controls.Add(this.label84);
            this.ucPanelTitle1.Controls.Add(this.label85);
            this.ucPanelTitle1.Controls.Add(this.label86);
            this.ucPanelTitle1.Controls.Add(this.label87);
            this.ucPanelTitle1.Controls.Add(this.label88);
            this.ucPanelTitle1.Controls.Add(this.label89);
            this.ucPanelTitle1.Controls.Add(this.label90);
            this.ucPanelTitle1.Controls.Add(this.label91);
            this.ucPanelTitle1.Controls.Add(this.label92);
            this.ucPanelTitle1.FillColor = System.Drawing.Color.Transparent;
            this.ucPanelTitle1.Font = new System.Drawing.Font("微软雅黑", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucPanelTitle1.IsCanExpand = true;
            this.ucPanelTitle1.IsExpand = true;
            this.ucPanelTitle1.IsRadius = true;
            this.ucPanelTitle1.IsShowRect = true;
            this.ucPanelTitle1.Location = new System.Drawing.Point(1048, 149);
            this.ucPanelTitle1.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.ucPanelTitle1.Name = "ucPanelTitle1";
            this.ucPanelTitle1.Padding = new System.Windows.Forms.Padding(2);
            this.ucPanelTitle1.RectColor = System.Drawing.Color.Silver;
            this.ucPanelTitle1.RectWidth = 1;
            this.ucPanelTitle1.Size = new System.Drawing.Size(325, 668);
            this.ucPanelTitle1.TabIndex = 24;
            this.ucPanelTitle1.Title = "水平轴";
            // 
            // label80
            // 
            this.label80.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label80.Location = new System.Drawing.Point(14, 209);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(230, 1);
            this.label80.TabIndex = 32;
            // 
            // button30
            // 
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button30.ForeColor = System.Drawing.Color.Black;
            this.button30.Location = new System.Drawing.Point(137, 179);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(75, 25);
            this.button30.TabIndex = 30;
            this.button30.Text = "后  退";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button34.ForeColor = System.Drawing.Color.Black;
            this.button34.Location = new System.Drawing.Point(137, 370);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(75, 25);
            this.button34.TabIndex = 31;
            this.button34.Text = "缓存6工位";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button35.ForeColor = System.Drawing.Color.Black;
            this.button35.Location = new System.Drawing.Point(137, 308);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(75, 25);
            this.button35.TabIndex = 31;
            this.button35.Text = "缓存4工位";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button36.ForeColor = System.Drawing.Color.Black;
            this.button36.Location = new System.Drawing.Point(137, 246);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(75, 25);
            this.button36.TabIndex = 31;
            this.button36.Text = "缓存2工位";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button40.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button40.ForeColor = System.Drawing.Color.Black;
            this.button40.Location = new System.Drawing.Point(31, 370);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(75, 25);
            this.button40.TabIndex = 31;
            this.button40.Text = "输送位";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button41.ForeColor = System.Drawing.Color.Black;
            this.button41.Location = new System.Drawing.Point(31, 308);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(75, 25);
            this.button41.TabIndex = 31;
            this.button41.Text = "炉管4工位";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button42.ForeColor = System.Drawing.Color.Black;
            this.button42.Location = new System.Drawing.Point(31, 246);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(75, 25);
            this.button42.TabIndex = 31;
            this.button42.Text = "炉管2工位";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button46.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button46.ForeColor = System.Drawing.Color.Black;
            this.button46.Location = new System.Drawing.Point(137, 339);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(75, 25);
            this.button46.TabIndex = 31;
            this.button46.Text = "缓存5工位";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button47.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button47.ForeColor = System.Drawing.Color.Black;
            this.button47.Location = new System.Drawing.Point(137, 277);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(75, 25);
            this.button47.TabIndex = 31;
            this.button47.Text = "缓存3工位";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button48.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button48.ForeColor = System.Drawing.Color.Black;
            this.button48.Location = new System.Drawing.Point(137, 215);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(75, 25);
            this.button48.TabIndex = 31;
            this.button48.Text = "缓存1工位";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button51
            // 
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button51.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button51.ForeColor = System.Drawing.Color.Black;
            this.button51.Location = new System.Drawing.Point(31, 401);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(181, 25);
            this.button51.TabIndex = 31;
            this.button51.Text = "通道位";
            this.button51.UseVisualStyleBackColor = true;
            // 
            // button52
            // 
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button52.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button52.ForeColor = System.Drawing.Color.Black;
            this.button52.Location = new System.Drawing.Point(31, 339);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(75, 25);
            this.button52.TabIndex = 31;
            this.button52.Text = "炉管5工位";
            this.button52.UseVisualStyleBackColor = true;
            // 
            // button53
            // 
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button53.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button53.ForeColor = System.Drawing.Color.Black;
            this.button53.Location = new System.Drawing.Point(31, 277);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(75, 25);
            this.button53.TabIndex = 31;
            this.button53.Text = "炉管3工位";
            this.button53.UseVisualStyleBackColor = true;
            // 
            // button54
            // 
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button54.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button54.ForeColor = System.Drawing.Color.Black;
            this.button54.Location = new System.Drawing.Point(31, 215);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(75, 25);
            this.button54.TabIndex = 31;
            this.button54.Text = "炉管1工位";
            this.button54.UseVisualStyleBackColor = true;
            // 
            // button55
            // 
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button55.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button55.ForeColor = System.Drawing.Color.Black;
            this.button55.Location = new System.Drawing.Point(31, 179);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(75, 25);
            this.button55.TabIndex = 31;
            this.button55.Text = "前  进";
            this.button55.UseVisualStyleBackColor = true;
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox15.Location = new System.Drawing.Point(141, 147);
            this.textBox15.Margin = new System.Windows.Forms.Padding(2);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(44, 35);
            this.textBox15.TabIndex = 29;
            this.textBox15.Text = "000.0";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label81.ForeColor = System.Drawing.Color.Black;
            this.label81.Location = new System.Drawing.Point(22, 150);
            this.label81.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(190, 28);
            this.label81.TabIndex = 28;
            this.label81.Text = "点动速度(mm/s)：";
            // 
            // button56
            // 
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button56.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button56.ForeColor = System.Drawing.Color.Black;
            this.button56.Location = new System.Drawing.Point(137, 119);
            this.button56.Margin = new System.Windows.Forms.Padding(4);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(75, 25);
            this.button56.TabIndex = 26;
            this.button56.Text = "解除联锁";
            this.button56.UseVisualStyleBackColor = true;
            // 
            // button57
            // 
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button57.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button57.ForeColor = System.Drawing.Color.Black;
            this.button57.Location = new System.Drawing.Point(31, 119);
            this.button57.Margin = new System.Windows.Forms.Padding(4);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(75, 25);
            this.button57.TabIndex = 27;
            this.button57.Text = "使  能";
            this.button57.UseVisualStyleBackColor = true;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.BackColor = System.Drawing.Color.Gray;
            this.label82.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label82.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label82.Location = new System.Drawing.Point(173, 92);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(66, 26);
            this.label82.TabIndex = 23;
            this.label82.Text = "正极限";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.BackColor = System.Drawing.Color.Gray;
            this.label83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label83.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label83.Location = new System.Drawing.Point(105, 92);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(58, 26);
            this.label83.TabIndex = 24;
            this.label83.Text = " 原点 ";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.BackColor = System.Drawing.Color.Gray;
            this.label84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label84.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label84.Location = new System.Drawing.Point(29, 92);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(66, 26);
            this.label84.TabIndex = 25;
            this.label84.Text = "负极限";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label85.ForeColor = System.Drawing.Color.Black;
            this.label85.Location = new System.Drawing.Point(212, 64);
            this.label85.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(54, 24);
            this.label85.TabIndex = 0;
            this.label85.Text = "0000";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label86.ForeColor = System.Drawing.Color.Black;
            this.label86.Location = new System.Drawing.Point(212, 40);
            this.label86.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(54, 24);
            this.label86.TabIndex = 0;
            this.label86.Text = "0000";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label87.ForeColor = System.Drawing.Color.Black;
            this.label87.Location = new System.Drawing.Point(78, 64);
            this.label87.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(54, 24);
            this.label87.TabIndex = 0;
            this.label87.Text = "0000";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label88.ForeColor = System.Drawing.Color.Black;
            this.label88.Location = new System.Drawing.Point(78, 40);
            this.label88.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(54, 24);
            this.label88.TabIndex = 0;
            this.label88.Text = "0000";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label89.ForeColor = System.Drawing.Color.Black;
            this.label89.Location = new System.Drawing.Point(126, 64);
            this.label89.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(102, 24);
            this.label89.TabIndex = 0;
            this.label89.Text = "磁尺( mm )";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label90.ForeColor = System.Drawing.Color.Black;
            this.label90.Location = new System.Drawing.Point(126, 40);
            this.label90.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(108, 24);
            this.label90.TabIndex = 0;
            this.label90.Text = "速度(mm/s)";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label91.ForeColor = System.Drawing.Color.Black;
            this.label91.Location = new System.Drawing.Point(4, 64);
            this.label91.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(94, 24);
            this.label91.TabIndex = 0;
            this.label91.Text = "扭矩(N·m)";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label92.ForeColor = System.Drawing.Color.Black;
            this.label92.Location = new System.Drawing.Point(4, 40);
            this.label92.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(92, 24);
            this.label92.TabIndex = 0;
            this.label92.Text = "位置(mm)";
            // 
            // ucPanelTitle2
            // 
            this.ucPanelTitle2.BackColor = System.Drawing.Color.Transparent;
            this.ucPanelTitle2.BorderColor = System.Drawing.Color.Silver;
            this.ucPanelTitle2.ConerRadius = 10;
            this.ucPanelTitle2.Controls.Add(this.label93);
            this.ucPanelTitle2.Controls.Add(this.button31);
            this.ucPanelTitle2.Controls.Add(this.button32);
            this.ucPanelTitle2.Controls.Add(this.button33);
            this.ucPanelTitle2.Controls.Add(this.button37);
            this.ucPanelTitle2.Controls.Add(this.button38);
            this.ucPanelTitle2.Controls.Add(this.button39);
            this.ucPanelTitle2.Controls.Add(this.button43);
            this.ucPanelTitle2.Controls.Add(this.button44);
            this.ucPanelTitle2.Controls.Add(this.button45);
            this.ucPanelTitle2.Controls.Add(this.button49);
            this.ucPanelTitle2.Controls.Add(this.button50);
            this.ucPanelTitle2.Controls.Add(this.button58);
            this.ucPanelTitle2.Controls.Add(this.button59);
            this.ucPanelTitle2.Controls.Add(this.button60);
            this.ucPanelTitle2.Controls.Add(this.button61);
            this.ucPanelTitle2.Controls.Add(this.textBox16);
            this.ucPanelTitle2.Controls.Add(this.label94);
            this.ucPanelTitle2.Controls.Add(this.button62);
            this.ucPanelTitle2.Controls.Add(this.button63);
            this.ucPanelTitle2.Controls.Add(this.label95);
            this.ucPanelTitle2.Controls.Add(this.label96);
            this.ucPanelTitle2.Controls.Add(this.label97);
            this.ucPanelTitle2.Controls.Add(this.label98);
            this.ucPanelTitle2.Controls.Add(this.label99);
            this.ucPanelTitle2.Controls.Add(this.label100);
            this.ucPanelTitle2.Controls.Add(this.label101);
            this.ucPanelTitle2.Controls.Add(this.label102);
            this.ucPanelTitle2.Controls.Add(this.label103);
            this.ucPanelTitle2.Controls.Add(this.label104);
            this.ucPanelTitle2.Controls.Add(this.label105);
            this.ucPanelTitle2.FillColor = System.Drawing.Color.Transparent;
            this.ucPanelTitle2.Font = new System.Drawing.Font("微软雅黑", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucPanelTitle2.IsCanExpand = true;
            this.ucPanelTitle2.IsExpand = true;
            this.ucPanelTitle2.IsRadius = true;
            this.ucPanelTitle2.IsShowRect = true;
            this.ucPanelTitle2.Location = new System.Drawing.Point(1048, 185);
            this.ucPanelTitle2.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.ucPanelTitle2.Name = "ucPanelTitle2";
            this.ucPanelTitle2.Padding = new System.Windows.Forms.Padding(2);
            this.ucPanelTitle2.RectColor = System.Drawing.Color.Silver;
            this.ucPanelTitle2.RectWidth = 1;
            this.ucPanelTitle2.Size = new System.Drawing.Size(325, 632);
            this.ucPanelTitle2.TabIndex = 33;
            this.ucPanelTitle2.Title = "输送机";
            // 
            // label93
            // 
            this.label93.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label93.Location = new System.Drawing.Point(14, 209);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(230, 1);
            this.label93.TabIndex = 32;
            // 
            // button31
            // 
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button31.ForeColor = System.Drawing.Color.Black;
            this.button31.Location = new System.Drawing.Point(137, 179);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(75, 25);
            this.button31.TabIndex = 30;
            this.button31.Text = "后  退";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button32.ForeColor = System.Drawing.Color.Black;
            this.button32.Location = new System.Drawing.Point(137, 370);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(75, 25);
            this.button32.TabIndex = 31;
            this.button32.Text = "缓存6工位";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button33.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button33.ForeColor = System.Drawing.Color.Black;
            this.button33.Location = new System.Drawing.Point(137, 308);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(75, 25);
            this.button33.TabIndex = 31;
            this.button33.Text = "缓存4工位";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button37.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button37.ForeColor = System.Drawing.Color.Black;
            this.button37.Location = new System.Drawing.Point(137, 246);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(75, 25);
            this.button37.TabIndex = 31;
            this.button37.Text = "缓存2工位";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button38.ForeColor = System.Drawing.Color.Black;
            this.button38.Location = new System.Drawing.Point(31, 370);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(75, 25);
            this.button38.TabIndex = 31;
            this.button38.Text = "输送位";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button39.ForeColor = System.Drawing.Color.Black;
            this.button39.Location = new System.Drawing.Point(31, 308);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(75, 25);
            this.button39.TabIndex = 31;
            this.button39.Text = "炉管4工位";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button43.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button43.ForeColor = System.Drawing.Color.Black;
            this.button43.Location = new System.Drawing.Point(31, 246);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(75, 25);
            this.button43.TabIndex = 31;
            this.button43.Text = "炉管2工位";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button44.ForeColor = System.Drawing.Color.Black;
            this.button44.Location = new System.Drawing.Point(137, 339);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(75, 25);
            this.button44.TabIndex = 31;
            this.button44.Text = "缓存5工位";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button45.ForeColor = System.Drawing.Color.Black;
            this.button45.Location = new System.Drawing.Point(137, 277);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(75, 25);
            this.button45.TabIndex = 31;
            this.button45.Text = "缓存3工位";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button49.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button49.ForeColor = System.Drawing.Color.Black;
            this.button49.Location = new System.Drawing.Point(137, 215);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(75, 25);
            this.button49.TabIndex = 31;
            this.button49.Text = "缓存1工位";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button50
            // 
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button50.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button50.ForeColor = System.Drawing.Color.Black;
            this.button50.Location = new System.Drawing.Point(31, 401);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(181, 25);
            this.button50.TabIndex = 31;
            this.button50.Text = "通道位";
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button58
            // 
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button58.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button58.ForeColor = System.Drawing.Color.Black;
            this.button58.Location = new System.Drawing.Point(31, 339);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(75, 25);
            this.button58.TabIndex = 31;
            this.button58.Text = "炉管5工位";
            this.button58.UseVisualStyleBackColor = true;
            // 
            // button59
            // 
            this.button59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button59.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button59.ForeColor = System.Drawing.Color.Black;
            this.button59.Location = new System.Drawing.Point(31, 277);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(75, 25);
            this.button59.TabIndex = 31;
            this.button59.Text = "炉管3工位";
            this.button59.UseVisualStyleBackColor = true;
            // 
            // button60
            // 
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button60.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button60.ForeColor = System.Drawing.Color.Black;
            this.button60.Location = new System.Drawing.Point(31, 215);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(75, 25);
            this.button60.TabIndex = 31;
            this.button60.Text = "炉管1工位";
            this.button60.UseVisualStyleBackColor = true;
            // 
            // button61
            // 
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button61.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button61.ForeColor = System.Drawing.Color.Black;
            this.button61.Location = new System.Drawing.Point(31, 179);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(75, 25);
            this.button61.TabIndex = 31;
            this.button61.Text = "前  进";
            this.button61.UseVisualStyleBackColor = true;
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox16.Location = new System.Drawing.Point(141, 147);
            this.textBox16.Margin = new System.Windows.Forms.Padding(2);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(44, 35);
            this.textBox16.TabIndex = 29;
            this.textBox16.Text = "000.0";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label94.ForeColor = System.Drawing.Color.Black;
            this.label94.Location = new System.Drawing.Point(22, 150);
            this.label94.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(190, 28);
            this.label94.TabIndex = 28;
            this.label94.Text = "点动速度(mm/s)：";
            // 
            // button62
            // 
            this.button62.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button62.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button62.ForeColor = System.Drawing.Color.Black;
            this.button62.Location = new System.Drawing.Point(137, 119);
            this.button62.Margin = new System.Windows.Forms.Padding(4);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(75, 25);
            this.button62.TabIndex = 26;
            this.button62.Text = "解除联锁";
            this.button62.UseVisualStyleBackColor = true;
            // 
            // button63
            // 
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button63.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button63.ForeColor = System.Drawing.Color.Black;
            this.button63.Location = new System.Drawing.Point(31, 119);
            this.button63.Margin = new System.Windows.Forms.Padding(4);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(75, 25);
            this.button63.TabIndex = 27;
            this.button63.Text = "使  能";
            this.button63.UseVisualStyleBackColor = true;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.BackColor = System.Drawing.Color.Gray;
            this.label95.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label95.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label95.Location = new System.Drawing.Point(173, 92);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(66, 26);
            this.label95.TabIndex = 23;
            this.label95.Text = "正极限";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.BackColor = System.Drawing.Color.Gray;
            this.label96.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label96.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label96.Location = new System.Drawing.Point(105, 92);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(58, 26);
            this.label96.TabIndex = 24;
            this.label96.Text = " 原点 ";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.BackColor = System.Drawing.Color.Gray;
            this.label97.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label97.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label97.Location = new System.Drawing.Point(29, 92);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(66, 26);
            this.label97.TabIndex = 25;
            this.label97.Text = "负极限";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label98.ForeColor = System.Drawing.Color.Black;
            this.label98.Location = new System.Drawing.Point(212, 64);
            this.label98.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(54, 24);
            this.label98.TabIndex = 0;
            this.label98.Text = "0000";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label99.ForeColor = System.Drawing.Color.Black;
            this.label99.Location = new System.Drawing.Point(212, 40);
            this.label99.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(54, 24);
            this.label99.TabIndex = 0;
            this.label99.Text = "0000";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label100.ForeColor = System.Drawing.Color.Black;
            this.label100.Location = new System.Drawing.Point(78, 64);
            this.label100.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(54, 24);
            this.label100.TabIndex = 0;
            this.label100.Text = "0000";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label101.ForeColor = System.Drawing.Color.Black;
            this.label101.Location = new System.Drawing.Point(78, 40);
            this.label101.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(54, 24);
            this.label101.TabIndex = 0;
            this.label101.Text = "0000";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label102.ForeColor = System.Drawing.Color.Black;
            this.label102.Location = new System.Drawing.Point(126, 64);
            this.label102.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(102, 24);
            this.label102.TabIndex = 0;
            this.label102.Text = "磁尺( mm )";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label103.ForeColor = System.Drawing.Color.Black;
            this.label103.Location = new System.Drawing.Point(126, 40);
            this.label103.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(108, 24);
            this.label103.TabIndex = 0;
            this.label103.Text = "速度(mm/s)";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label104.ForeColor = System.Drawing.Color.Black;
            this.label104.Location = new System.Drawing.Point(4, 64);
            this.label104.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(94, 24);
            this.label104.TabIndex = 0;
            this.label104.Text = "扭矩(N·m)";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label105.ForeColor = System.Drawing.Color.Black;
            this.label105.Location = new System.Drawing.Point(4, 40);
            this.label105.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(92, 24);
            this.label105.TabIndex = 0;
            this.label105.Text = "位置(mm)";
            // 
            // groupBox13
            // 
            this.groupBox13.BackgroundImage = global::Test.Properties.Resources.机械手;
            this.groupBox13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox13.Controls.Add(this.comboBox13);
            this.groupBox13.Controls.Add(this.label50);
            this.groupBox13.Controls.Add(this.label51);
            this.groupBox13.Controls.Add(this.label52);
            this.groupBox13.Controls.Add(this.label53);
            this.groupBox13.Controls.Add(this.textBox13);
            this.groupBox13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox13.Location = new System.Drawing.Point(348, 555);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(333, 128);
            this.groupBox13.TabIndex = 7;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "机械手";
            // 
            // comboBox13
            // 
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Items.AddRange(new object[] {
            " - - ",
            "无舟",
            "空舟",
            "未工艺舟",
            "已工艺舟",
            "异常舟",
            "实验舟",
            "空桨饱和",
            "饱和完成",
            "正在工艺",
            "待清洗舟"});
            this.comboBox13.Location = new System.Drawing.Point(17, 74);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(121, 33);
            this.comboBox13.TabIndex = 3;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label50.Location = new System.Drawing.Point(143, 77);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(82, 24);
            this.label50.TabIndex = 2;
            this.label50.Text = "舟装卸片";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label51.Location = new System.Drawing.Point(231, 77);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(102, 24);
            this.label51.TabIndex = 2;
            this.label51.Text = "存放:9999s";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label52.Location = new System.Drawing.Point(231, 37);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(102, 24);
            this.label52.TabIndex = 2;
            this.label52.Text = "冷却:9999s";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label53.Location = new System.Drawing.Point(143, 37);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(82, 24);
            this.label53.TabIndex = 2;
            this.label53.Text = "来自炉管";
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox13.Location = new System.Drawing.Point(17, 34);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(120, 31);
            this.textBox13.TabIndex = 0;
            // 
            // groupBox12
            // 
            this.groupBox12.BackgroundImage = global::Test.Properties.Resources.缓存;
            this.groupBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox12.Controls.Add(this.comboBox12);
            this.groupBox12.Controls.Add(this.label46);
            this.groupBox12.Controls.Add(this.label47);
            this.groupBox12.Controls.Add(this.label48);
            this.groupBox12.Controls.Add(this.label49);
            this.groupBox12.Controls.Add(this.textBox12);
            this.groupBox12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox12.Location = new System.Drawing.Point(691, 689);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(332, 128);
            this.groupBox12.TabIndex = 7;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "缓存六";
            // 
            // comboBox12
            // 
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Items.AddRange(new object[] {
            " - - ",
            "无舟",
            "空舟",
            "未工艺舟",
            "已工艺舟",
            "异常舟",
            "实验舟",
            "空桨饱和",
            "饱和完成",
            "正在工艺",
            "待清洗舟"});
            this.comboBox12.Location = new System.Drawing.Point(17, 74);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(121, 33);
            this.comboBox12.TabIndex = 3;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label46.Location = new System.Drawing.Point(143, 77);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(82, 24);
            this.label46.TabIndex = 2;
            this.label46.Text = "舟装卸片";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label47.Location = new System.Drawing.Point(231, 77);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(102, 24);
            this.label47.TabIndex = 2;
            this.label47.Text = "存放:9999s";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label48.Location = new System.Drawing.Point(231, 37);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(102, 24);
            this.label48.TabIndex = 2;
            this.label48.Text = "冷却:9999s";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label49.Location = new System.Drawing.Point(143, 37);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(82, 24);
            this.label49.TabIndex = 2;
            this.label49.Text = "来自炉管";
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox12.Location = new System.Drawing.Point(17, 34);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(120, 31);
            this.textBox12.TabIndex = 0;
            // 
            // groupBox11
            // 
            this.groupBox11.BackgroundImage = global::Test.Properties.Resources.缓存;
            this.groupBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox11.Controls.Add(this.comboBox11);
            this.groupBox11.Controls.Add(this.label42);
            this.groupBox11.Controls.Add(this.label43);
            this.groupBox11.Controls.Add(this.label44);
            this.groupBox11.Controls.Add(this.label45);
            this.groupBox11.Controls.Add(this.textBox11);
            this.groupBox11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox11.Location = new System.Drawing.Point(691, 555);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(332, 128);
            this.groupBox11.TabIndex = 7;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "缓存五";
            // 
            // comboBox11
            // 
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            " - - ",
            "无舟",
            "空舟",
            "未工艺舟",
            "已工艺舟",
            "异常舟",
            "实验舟",
            "空桨饱和",
            "饱和完成",
            "正在工艺",
            "待清洗舟"});
            this.comboBox11.Location = new System.Drawing.Point(17, 74);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(121, 33);
            this.comboBox11.TabIndex = 3;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label42.Location = new System.Drawing.Point(143, 77);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(82, 24);
            this.label42.TabIndex = 2;
            this.label42.Text = "舟装卸片";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label43.Location = new System.Drawing.Point(231, 77);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(102, 24);
            this.label43.TabIndex = 2;
            this.label43.Text = "存放:9999s";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label44.Location = new System.Drawing.Point(231, 37);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(102, 24);
            this.label44.TabIndex = 2;
            this.label44.Text = "冷却:9999s";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label45.Location = new System.Drawing.Point(143, 37);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(82, 24);
            this.label45.TabIndex = 2;
            this.label45.Text = "来自炉管";
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox11.Location = new System.Drawing.Point(17, 34);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(120, 31);
            this.textBox11.TabIndex = 0;
            // 
            // groupBox10
            // 
            this.groupBox10.BackgroundImage = global::Test.Properties.Resources.缓存;
            this.groupBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox10.Controls.Add(this.comboBox10);
            this.groupBox10.Controls.Add(this.label38);
            this.groupBox10.Controls.Add(this.label39);
            this.groupBox10.Controls.Add(this.label40);
            this.groupBox10.Controls.Add(this.label41);
            this.groupBox10.Controls.Add(this.textBox10);
            this.groupBox10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox10.Location = new System.Drawing.Point(691, 421);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(332, 128);
            this.groupBox10.TabIndex = 7;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "缓存四";
            // 
            // comboBox10
            // 
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Items.AddRange(new object[] {
            " - - ",
            "无舟",
            "空舟",
            "未工艺舟",
            "已工艺舟",
            "异常舟",
            "实验舟",
            "空桨饱和",
            "饱和完成",
            "正在工艺",
            "待清洗舟"});
            this.comboBox10.Location = new System.Drawing.Point(17, 74);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(121, 33);
            this.comboBox10.TabIndex = 3;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label38.Location = new System.Drawing.Point(143, 77);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(82, 24);
            this.label38.TabIndex = 2;
            this.label38.Text = "舟装卸片";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label39.Location = new System.Drawing.Point(231, 77);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(102, 24);
            this.label39.TabIndex = 2;
            this.label39.Text = "存放:9999s";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label40.Location = new System.Drawing.Point(231, 37);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(102, 24);
            this.label40.TabIndex = 2;
            this.label40.Text = "冷却:9999s";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label41.Location = new System.Drawing.Point(143, 37);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(82, 24);
            this.label41.TabIndex = 2;
            this.label41.Text = "来自炉管";
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox10.Location = new System.Drawing.Point(17, 34);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(120, 31);
            this.textBox10.TabIndex = 0;
            // 
            // groupBox9
            // 
            this.groupBox9.BackgroundImage = global::Test.Properties.Resources.缓存;
            this.groupBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox9.Controls.Add(this.comboBox9);
            this.groupBox9.Controls.Add(this.label34);
            this.groupBox9.Controls.Add(this.label35);
            this.groupBox9.Controls.Add(this.label36);
            this.groupBox9.Controls.Add(this.label37);
            this.groupBox9.Controls.Add(this.textBox9);
            this.groupBox9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox9.Location = new System.Drawing.Point(691, 287);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(332, 128);
            this.groupBox9.TabIndex = 7;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "缓存三";
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            " - - ",
            "无舟",
            "空舟",
            "未工艺舟",
            "已工艺舟",
            "异常舟",
            "实验舟",
            "空桨饱和",
            "饱和完成",
            "正在工艺",
            "待清洗舟"});
            this.comboBox9.Location = new System.Drawing.Point(17, 74);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(121, 33);
            this.comboBox9.TabIndex = 3;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.Location = new System.Drawing.Point(143, 77);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(82, 24);
            this.label34.TabIndex = 2;
            this.label34.Text = "舟装卸片";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label35.Location = new System.Drawing.Point(231, 77);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(102, 24);
            this.label35.TabIndex = 2;
            this.label35.Text = "存放:9999s";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.Location = new System.Drawing.Point(231, 37);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(102, 24);
            this.label36.TabIndex = 2;
            this.label36.Text = "冷却:9999s";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label37.Location = new System.Drawing.Point(143, 37);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(82, 24);
            this.label37.TabIndex = 2;
            this.label37.Text = "来自炉管";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox9.Location = new System.Drawing.Point(17, 34);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(120, 31);
            this.textBox9.TabIndex = 0;
            // 
            // groupBox8
            // 
            this.groupBox8.BackgroundImage = global::Test.Properties.Resources.缓存;
            this.groupBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox8.Controls.Add(this.comboBox8);
            this.groupBox8.Controls.Add(this.label30);
            this.groupBox8.Controls.Add(this.label31);
            this.groupBox8.Controls.Add(this.label32);
            this.groupBox8.Controls.Add(this.label33);
            this.groupBox8.Controls.Add(this.textBox8);
            this.groupBox8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox8.Location = new System.Drawing.Point(691, 153);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(332, 128);
            this.groupBox8.TabIndex = 7;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "缓存二";
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            " - - ",
            "无舟",
            "空舟",
            "未工艺舟",
            "已工艺舟",
            "异常舟",
            "实验舟",
            "空桨饱和",
            "饱和完成",
            "正在工艺",
            "待清洗舟"});
            this.comboBox8.Location = new System.Drawing.Point(17, 74);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(121, 33);
            this.comboBox8.TabIndex = 3;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label30.Location = new System.Drawing.Point(143, 77);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(82, 24);
            this.label30.TabIndex = 2;
            this.label30.Text = "舟装卸片";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(231, 77);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(102, 24);
            this.label31.TabIndex = 2;
            this.label31.Text = "存放:9999s";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.Location = new System.Drawing.Point(231, 37);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(102, 24);
            this.label32.TabIndex = 2;
            this.label32.Text = "冷却:9999s";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.Location = new System.Drawing.Point(143, 37);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(82, 24);
            this.label33.TabIndex = 2;
            this.label33.Text = "来自炉管";
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox8.Location = new System.Drawing.Point(17, 34);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(120, 31);
            this.textBox8.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.BackgroundImage = global::Test.Properties.Resources.缓存;
            this.groupBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox7.Controls.Add(this.comboBox7);
            this.groupBox7.Controls.Add(this.label25);
            this.groupBox7.Controls.Add(this.label26);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.textBox7);
            this.groupBox7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox7.Location = new System.Drawing.Point(691, 19);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(332, 128);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "缓存一";
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            " - - ",
            "无舟",
            "空舟",
            "未工艺舟",
            "已工艺舟",
            "异常舟",
            "实验舟",
            "空桨饱和",
            "饱和完成",
            "正在工艺",
            "待清洗舟"});
            this.comboBox7.Location = new System.Drawing.Point(17, 74);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(121, 33);
            this.comboBox7.TabIndex = 3;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.Location = new System.Drawing.Point(143, 77);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(82, 24);
            this.label25.TabIndex = 2;
            this.label25.Text = "舟装卸片";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.Location = new System.Drawing.Point(231, 77);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(102, 24);
            this.label26.TabIndex = 2;
            this.label26.Text = "存放:9999s";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label28.Location = new System.Drawing.Point(231, 37);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(102, 24);
            this.label28.TabIndex = 2;
            this.label28.Text = "冷却:9999s";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label29.Location = new System.Drawing.Point(143, 37);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(82, 24);
            this.label29.TabIndex = 2;
            this.label29.Text = "来自炉管";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox7.Location = new System.Drawing.Point(17, 34);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(120, 31);
            this.textBox7.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.BackgroundImage = global::Test.Properties.Resources.缓存;
            this.groupBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox6.Controls.Add(this.comboBox6);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.textBox6);
            this.groupBox6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox6.Location = new System.Drawing.Point(11, 689);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(332, 128);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "输送位";
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            " - - ",
            "无舟",
            "空舟",
            "未工艺舟",
            "已工艺舟",
            "异常舟",
            "实验舟",
            "空桨饱和",
            "饱和完成",
            "正在工艺",
            "待清洗舟"});
            this.comboBox6.Location = new System.Drawing.Point(17, 74);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(121, 33);
            this.comboBox6.TabIndex = 3;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(143, 77);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(82, 24);
            this.label21.TabIndex = 2;
            this.label21.Text = "舟装卸片";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(231, 77);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(102, 24);
            this.label22.TabIndex = 2;
            this.label22.Text = "存放:9999s";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(231, 37);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(102, 24);
            this.label23.TabIndex = 2;
            this.label23.Text = "冷却:9999s";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.Location = new System.Drawing.Point(143, 37);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(82, 24);
            this.label24.TabIndex = 2;
            this.label24.Text = "来自炉管";
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox6.Location = new System.Drawing.Point(17, 34);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(120, 31);
            this.textBox6.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.BackgroundImage = global::Test.Properties.Resources.炉管;
            this.groupBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox5.Controls.Add(this.comboBox5);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.textBox5);
            this.groupBox5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox5.Location = new System.Drawing.Point(18, 555);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(318, 128);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "炉管五";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            " - - ",
            "无舟",
            "空舟",
            "未工艺舟",
            "已工艺舟",
            "异常舟",
            "实验舟",
            "空桨饱和",
            "饱和完成",
            "正在工艺",
            "待清洗舟"});
            this.comboBox5.Location = new System.Drawing.Point(9, 74);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(121, 33);
            this.comboBox5.TabIndex = 3;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(135, 77);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(82, 24);
            this.label17.TabIndex = 2;
            this.label17.Text = "舟装卸片";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(223, 77);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(102, 24);
            this.label18.TabIndex = 2;
            this.label18.Text = "存放:9999s";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(223, 37);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(102, 24);
            this.label19.TabIndex = 2;
            this.label19.Text = "冷却:9999s";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(135, 37);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(82, 24);
            this.label20.TabIndex = 2;
            this.label20.Text = "来自炉管";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox5.Location = new System.Drawing.Point(9, 34);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(120, 31);
            this.textBox5.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.BackgroundImage = global::Test.Properties.Resources.炉管;
            this.groupBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox4.Controls.Add(this.comboBox4);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.textBox4);
            this.groupBox4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox4.Location = new System.Drawing.Point(18, 421);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(318, 128);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "炉管四";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            " - - ",
            "无舟",
            "空舟",
            "未工艺舟",
            "已工艺舟",
            "异常舟",
            "实验舟",
            "空桨饱和",
            "饱和完成",
            "正在工艺",
            "待清洗舟"});
            this.comboBox4.Location = new System.Drawing.Point(9, 74);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 33);
            this.comboBox4.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(135, 77);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 24);
            this.label13.TabIndex = 2;
            this.label13.Text = "舟装卸片";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(223, 77);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(102, 24);
            this.label14.TabIndex = 2;
            this.label14.Text = "存放:9999s";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(223, 37);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(102, 24);
            this.label15.TabIndex = 2;
            this.label15.Text = "冷却:9999s";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(135, 37);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(82, 24);
            this.label16.TabIndex = 2;
            this.label16.Text = "来自炉管";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox4.Location = new System.Drawing.Point(9, 34);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(120, 31);
            this.textBox4.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.BackgroundImage = global::Test.Properties.Resources.炉管;
            this.groupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox3.Controls.Add(this.comboBox3);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.textBox3);
            this.groupBox3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox3.Location = new System.Drawing.Point(18, 287);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(318, 128);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "炉管三";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            " - - ",
            "无舟",
            "空舟",
            "未工艺舟",
            "已工艺舟",
            "异常舟",
            "实验舟",
            "空桨饱和",
            "饱和完成",
            "正在工艺",
            "待清洗舟"});
            this.comboBox3.Location = new System.Drawing.Point(9, 74);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 33);
            this.comboBox3.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(135, 77);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 24);
            this.label9.TabIndex = 2;
            this.label9.Text = "舟装卸片";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(223, 77);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 24);
            this.label10.TabIndex = 2;
            this.label10.Text = "存放:9999s";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(223, 37);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 24);
            this.label11.TabIndex = 2;
            this.label11.Text = "冷却:9999s";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(135, 37);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 24);
            this.label12.TabIndex = 2;
            this.label12.Text = "来自炉管";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox3.Location = new System.Drawing.Point(9, 34);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(120, 31);
            this.textBox3.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundImage = global::Test.Properties.Resources.炉管;
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox2.Controls.Add(this.comboBox2);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.Location = new System.Drawing.Point(18, 153);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(318, 128);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "炉管二";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            " - - ",
            "无舟",
            "空舟",
            "未工艺舟",
            "已工艺舟",
            "异常舟",
            "实验舟",
            "空桨饱和",
            "饱和完成",
            "正在工艺",
            "待清洗舟"});
            this.comboBox2.Location = new System.Drawing.Point(9, 74);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 33);
            this.comboBox2.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(135, 77);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 24);
            this.label5.TabIndex = 2;
            this.label5.Text = "舟装卸片";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(223, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 24);
            this.label6.TabIndex = 2;
            this.label6.Text = "存放:9999s";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(223, 37);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 24);
            this.label7.TabIndex = 2;
            this.label7.Text = "冷却:9999s";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(135, 37);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 24);
            this.label8.TabIndex = 2;
            this.label8.Text = "来自炉管";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox2.Location = new System.Drawing.Point(9, 34);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(120, 31);
            this.textBox2.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImage = global::Test.Properties.Resources.炉管;
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(18, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(318, 128);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "炉管一";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            " - - ",
            "无舟",
            "空舟",
            "未工艺舟",
            "已工艺舟",
            "异常舟",
            "实验舟",
            "空桨饱和",
            "饱和完成",
            "正在工艺",
            "待清洗舟"});
            this.comboBox1.Location = new System.Drawing.Point(9, 74);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 33);
            this.comboBox1.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(135, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "舟装卸片";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(223, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 24);
            this.label4.TabIndex = 2;
            this.label4.Text = "存放:9999s";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(223, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "冷却:9999s";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(135, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "来自炉管";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox1.Location = new System.Drawing.Point(9, 34);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(120, 31);
            this.textBox1.TabIndex = 0;
            // 
            // UCMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ucPanelTitle5);
            this.Controls.Add(this.ucPanelTitle1);
            this.Controls.Add(this.ucPanelTitle2);
            this.Controls.Add(this.ucSwitch1);
            this.Controls.Add(this.ucSwitch5);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.label57);
            this.Controls.Add(this.groupBox14);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox12);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label27);
            this.Name = "UCMain";
            this.Size = new System.Drawing.Size(1394, 981);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.ucPanelTitle5.ResumeLayout(false);
            this.ucPanelTitle5.PerformLayout();
            this.ucPanelTitle1.ResumeLayout(false);
            this.ucPanelTitle1.PerformLayout();
            this.ucPanelTitle2.ResumeLayout(false);
            this.ucPanelTitle2.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private HZH_Controls.Controls.UCSwitch ucSwitch5;
        private HZH_Controls.Controls.UCSwitch ucSwitch1;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private HZH_Controls.Controls.UCPanelTitle ucPanelTitle5;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button10;
        private HZH_Controls.Controls.UCPanelTitle ucPanelTitle1;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private HZH_Controls.Controls.UCPanelTitle ucPanelTitle2;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
    }
}

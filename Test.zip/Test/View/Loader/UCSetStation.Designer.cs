﻿namespace Test.View.Loader
{
    partial class UCSetStation
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.ucSwitch5 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch1 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch2 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch3 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch4 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch6 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch7 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch8 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch9 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch10 = new HZH_Controls.Controls.UCSwitch();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.ucSwitch11 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch12 = new HZH_Controls.Controls.UCSwitch();
            this.button6 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(22, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "炉管";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(74, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "设置冷却(s)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(204, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "缓存";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(256, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 24);
            this.label4.TabIndex = 0;
            this.label4.Text = "设置冷却(s)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(383, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 24);
            this.label5.TabIndex = 0;
            this.label5.Text = "禁用";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(475, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 24);
            this.label6.TabIndex = 0;
            this.label6.Text = "类型";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(569, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 24);
            this.label7.TabIndex = 0;
            this.label7.Text = "卸片";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(35, 52);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(21, 24);
            this.label8.TabIndex = 0;
            this.label8.Text = "1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(35, 86);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(21, 24);
            this.label9.TabIndex = 0;
            this.label9.Text = "2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(35, 120);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(21, 24);
            this.label10.TabIndex = 0;
            this.label10.Text = "3";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(35, 154);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(21, 24);
            this.label11.TabIndex = 0;
            this.label11.Text = "4";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(35, 188);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(21, 24);
            this.label12.TabIndex = 0;
            this.label12.Text = "5";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(76, 53);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 28);
            this.textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(76, 87);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 28);
            this.textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(76, 121);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 28);
            this.textBox3.TabIndex = 1;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(76, 155);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 28);
            this.textBox4.TabIndex = 1;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(76, 189);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 28);
            this.textBox5.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(217, 52);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(21, 24);
            this.label13.TabIndex = 0;
            this.label13.Text = "1";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(217, 86);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(21, 24);
            this.label14.TabIndex = 0;
            this.label14.Text = "2";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(217, 120);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(21, 24);
            this.label15.TabIndex = 0;
            this.label15.Text = "3";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(217, 154);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(21, 24);
            this.label16.TabIndex = 0;
            this.label16.Text = "4";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(217, 188);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(21, 24);
            this.label17.TabIndex = 0;
            this.label17.Text = "5";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(258, 53);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 28);
            this.textBox6.TabIndex = 1;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(258, 87);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 28);
            this.textBox7.TabIndex = 1;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(258, 121);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 28);
            this.textBox8.TabIndex = 1;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(258, 155);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 28);
            this.textBox9.TabIndex = 1;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(258, 189);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 28);
            this.textBox10.TabIndex = 1;
            // 
            // ucSwitch5
            // 
            this.ucSwitch5.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch5.Checked = false;
            this.ucSwitch5.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch5.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch5.Location = new System.Drawing.Point(364, 49);
            this.ucSwitch5.Name = "ucSwitch5";
            this.ucSwitch5.Size = new System.Drawing.Size(86, 32);
            this.ucSwitch5.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch5.TabIndex = 16;
            this.ucSwitch5.Texts = new string[0];
            this.ucSwitch5.TrueColor = System.Drawing.Color.LimeGreen;
            this.ucSwitch5.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch1
            // 
            this.ucSwitch1.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch1.Checked = false;
            this.ucSwitch1.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch1.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch1.Location = new System.Drawing.Point(364, 83);
            this.ucSwitch1.Name = "ucSwitch1";
            this.ucSwitch1.Size = new System.Drawing.Size(86, 32);
            this.ucSwitch1.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch1.TabIndex = 16;
            this.ucSwitch1.Texts = new string[0];
            this.ucSwitch1.TrueColor = System.Drawing.Color.LimeGreen;
            this.ucSwitch1.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch2
            // 
            this.ucSwitch2.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch2.Checked = false;
            this.ucSwitch2.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch2.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch2.Location = new System.Drawing.Point(364, 117);
            this.ucSwitch2.Name = "ucSwitch2";
            this.ucSwitch2.Size = new System.Drawing.Size(86, 32);
            this.ucSwitch2.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch2.TabIndex = 16;
            this.ucSwitch2.Texts = new string[0];
            this.ucSwitch2.TrueColor = System.Drawing.Color.LimeGreen;
            this.ucSwitch2.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch3
            // 
            this.ucSwitch3.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch3.Checked = false;
            this.ucSwitch3.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch3.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch3.Location = new System.Drawing.Point(364, 151);
            this.ucSwitch3.Name = "ucSwitch3";
            this.ucSwitch3.Size = new System.Drawing.Size(86, 32);
            this.ucSwitch3.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch3.TabIndex = 16;
            this.ucSwitch3.Texts = new string[0];
            this.ucSwitch3.TrueColor = System.Drawing.Color.LimeGreen;
            this.ucSwitch3.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch4
            // 
            this.ucSwitch4.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch4.Checked = false;
            this.ucSwitch4.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch4.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch4.Location = new System.Drawing.Point(364, 185);
            this.ucSwitch4.Name = "ucSwitch4";
            this.ucSwitch4.Size = new System.Drawing.Size(86, 32);
            this.ucSwitch4.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch4.TabIndex = 16;
            this.ucSwitch4.Texts = new string[0];
            this.ucSwitch4.TrueColor = System.Drawing.Color.LimeGreen;
            this.ucSwitch4.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch6
            // 
            this.ucSwitch6.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch6.Checked = false;
            this.ucSwitch6.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch6.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch6.Location = new System.Drawing.Point(456, 49);
            this.ucSwitch6.Name = "ucSwitch6";
            this.ucSwitch6.Size = new System.Drawing.Size(86, 32);
            this.ucSwitch6.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch6.TabIndex = 16;
            this.ucSwitch6.Texts = new string[0];
            this.ucSwitch6.TrueColor = System.Drawing.Color.LimeGreen;
            this.ucSwitch6.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch7
            // 
            this.ucSwitch7.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch7.Checked = false;
            this.ucSwitch7.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch7.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch7.Location = new System.Drawing.Point(456, 83);
            this.ucSwitch7.Name = "ucSwitch7";
            this.ucSwitch7.Size = new System.Drawing.Size(86, 32);
            this.ucSwitch7.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch7.TabIndex = 16;
            this.ucSwitch7.Texts = new string[0];
            this.ucSwitch7.TrueColor = System.Drawing.Color.LimeGreen;
            this.ucSwitch7.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch8
            // 
            this.ucSwitch8.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch8.Checked = false;
            this.ucSwitch8.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch8.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch8.Location = new System.Drawing.Point(456, 117);
            this.ucSwitch8.Name = "ucSwitch8";
            this.ucSwitch8.Size = new System.Drawing.Size(86, 32);
            this.ucSwitch8.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch8.TabIndex = 16;
            this.ucSwitch8.Texts = new string[0];
            this.ucSwitch8.TrueColor = System.Drawing.Color.LimeGreen;
            this.ucSwitch8.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch9
            // 
            this.ucSwitch9.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch9.Checked = false;
            this.ucSwitch9.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch9.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch9.Location = new System.Drawing.Point(456, 151);
            this.ucSwitch9.Name = "ucSwitch9";
            this.ucSwitch9.Size = new System.Drawing.Size(86, 32);
            this.ucSwitch9.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch9.TabIndex = 16;
            this.ucSwitch9.Texts = new string[0];
            this.ucSwitch9.TrueColor = System.Drawing.Color.LimeGreen;
            this.ucSwitch9.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch10
            // 
            this.ucSwitch10.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch10.Checked = false;
            this.ucSwitch10.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch10.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch10.Location = new System.Drawing.Point(456, 185);
            this.ucSwitch10.Name = "ucSwitch10";
            this.ucSwitch10.Size = new System.Drawing.Size(86, 32);
            this.ucSwitch10.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch10.TabIndex = 16;
            this.ucSwitch10.Texts = new string[0];
            this.ucSwitch10.TrueColor = System.Drawing.Color.LimeGreen;
            this.ucSwitch10.TrueTextColr = System.Drawing.Color.White;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(548, 49);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 32);
            this.button1.TabIndex = 17;
            this.button1.Text = "卸片-清洗";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(548, 84);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 32);
            this.button2.TabIndex = 17;
            this.button2.Text = "卸片-清洗";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(548, 117);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(88, 32);
            this.button3.TabIndex = 17;
            this.button3.Text = "卸片-清洗";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button4.Location = new System.Drawing.Point(548, 151);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(88, 32);
            this.button4.TabIndex = 17;
            this.button4.Text = "卸片-清洗";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button5.Location = new System.Drawing.Point(548, 185);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(88, 32);
            this.button5.TabIndex = 17;
            this.button5.Text = "卸片-清洗";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(217, 222);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(21, 24);
            this.label18.TabIndex = 0;
            this.label18.Text = "6";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(258, 223);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 28);
            this.textBox11.TabIndex = 1;
            // 
            // ucSwitch11
            // 
            this.ucSwitch11.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch11.Checked = false;
            this.ucSwitch11.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch11.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch11.Location = new System.Drawing.Point(364, 219);
            this.ucSwitch11.Name = "ucSwitch11";
            this.ucSwitch11.Size = new System.Drawing.Size(86, 32);
            this.ucSwitch11.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch11.TabIndex = 16;
            this.ucSwitch11.Texts = new string[0];
            this.ucSwitch11.TrueColor = System.Drawing.Color.LimeGreen;
            this.ucSwitch11.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch12
            // 
            this.ucSwitch12.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch12.Checked = false;
            this.ucSwitch12.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch12.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch12.Location = new System.Drawing.Point(456, 219);
            this.ucSwitch12.Name = "ucSwitch12";
            this.ucSwitch12.Size = new System.Drawing.Size(86, 32);
            this.ucSwitch12.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch12.TabIndex = 16;
            this.ucSwitch12.Texts = new string[0];
            this.ucSwitch12.TrueColor = System.Drawing.Color.LimeGreen;
            this.ucSwitch12.TrueTextColr = System.Drawing.Color.White;
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button6.Location = new System.Drawing.Point(548, 219);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(88, 32);
            this.button6.TabIndex = 17;
            this.button6.Text = "卸片-清洗";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label27.Dock = System.Windows.Forms.DockStyle.Top;
            this.label27.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(0, 0);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(1168, 2);
            this.label27.TabIndex = 31;
            // 
            // UCSetStation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label27);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ucSwitch12);
            this.Controls.Add(this.ucSwitch10);
            this.Controls.Add(this.ucSwitch11);
            this.Controls.Add(this.ucSwitch4);
            this.Controls.Add(this.ucSwitch9);
            this.Controls.Add(this.ucSwitch3);
            this.Controls.Add(this.ucSwitch8);
            this.Controls.Add(this.ucSwitch2);
            this.Controls.Add(this.ucSwitch7);
            this.Controls.Add(this.ucSwitch1);
            this.Controls.Add(this.ucSwitch6);
            this.Controls.Add(this.ucSwitch5);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label1);
            this.Name = "UCSetStation";
            this.Size = new System.Drawing.Size(1168, 994);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private HZH_Controls.Controls.UCSwitch ucSwitch5;
        private HZH_Controls.Controls.UCSwitch ucSwitch1;
        private HZH_Controls.Controls.UCSwitch ucSwitch2;
        private HZH_Controls.Controls.UCSwitch ucSwitch3;
        private HZH_Controls.Controls.UCSwitch ucSwitch4;
        private HZH_Controls.Controls.UCSwitch ucSwitch6;
        private HZH_Controls.Controls.UCSwitch ucSwitch7;
        private HZH_Controls.Controls.UCSwitch ucSwitch8;
        private HZH_Controls.Controls.UCSwitch ucSwitch9;
        private HZH_Controls.Controls.UCSwitch ucSwitch10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox11;
        private HZH_Controls.Controls.UCSwitch ucSwitch11;
        private HZH_Controls.Controls.UCSwitch ucSwitch12;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label27;
    }
}

﻿namespace Test.View.Loader
{
    partial class UCCommIO
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label97);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label96);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label95);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label94);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label93);
            this.groupBox1.Controls.Add(this.label49);
            this.groupBox1.Controls.Add(this.label92);
            this.groupBox1.Controls.Add(this.label44);
            this.groupBox1.Controls.Add(this.label91);
            this.groupBox1.Controls.Add(this.label39);
            this.groupBox1.Controls.Add(this.label90);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.label89);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label88);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label87);
            this.groupBox1.Controls.Add(this.label48);
            this.groupBox1.Controls.Add(this.label86);
            this.groupBox1.Controls.Add(this.label43);
            this.groupBox1.Controls.Add(this.label85);
            this.groupBox1.Controls.Add(this.label38);
            this.groupBox1.Controls.Add(this.label84);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.label83);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.label82);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label81);
            this.groupBox1.Controls.Add(this.label47);
            this.groupBox1.Controls.Add(this.label80);
            this.groupBox1.Controls.Add(this.label42);
            this.groupBox1.Controls.Add(this.label79);
            this.groupBox1.Controls.Add(this.label37);
            this.groupBox1.Controls.Add(this.label78);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.label77);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label76);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label75);
            this.groupBox1.Controls.Add(this.label46);
            this.groupBox1.Controls.Add(this.label74);
            this.groupBox1.Controls.Add(this.label41);
            this.groupBox1.Controls.Add(this.label73);
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.label72);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label71);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label70);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label69);
            this.groupBox1.Controls.Add(this.label45);
            this.groupBox1.Controls.Add(this.label68);
            this.groupBox1.Controls.Add(this.label40);
            this.groupBox1.Controls.Add(this.label67);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.label66);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.label65);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label64);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label63);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label62);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label61);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label60);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label59);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label58);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label57);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label56);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label55);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label54);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label53);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label52);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label51);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label50);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(13, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1122, 278);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " 机械手 <--> 炉管 ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label7.Location = new System.Drawing.Point(472, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 24);
            this.label7.TabIndex = 0;
            this.label7.Text = "管5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label6.Location = new System.Drawing.Point(426, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 24);
            this.label6.TabIndex = 0;
            this.label6.Text = "管4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label5.Location = new System.Drawing.Point(380, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 24);
            this.label5.TabIndex = 0;
            this.label5.Text = "管3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label4.Location = new System.Drawing.Point(334, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 24);
            this.label4.TabIndex = 0;
            this.label4.Text = "管2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label3.Location = new System.Drawing.Point(288, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 24);
            this.label3.TabIndex = 0;
            this.label3.Text = "管1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label2.Location = new System.Drawing.Point(154, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "机械手   --->";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label141);
            this.groupBox2.Controls.Add(this.label140);
            this.groupBox2.Controls.Add(this.label98);
            this.groupBox2.Controls.Add(this.label139);
            this.groupBox2.Controls.Add(this.label99);
            this.groupBox2.Controls.Add(this.label138);
            this.groupBox2.Controls.Add(this.label109);
            this.groupBox2.Controls.Add(this.label137);
            this.groupBox2.Controls.Add(this.label108);
            this.groupBox2.Controls.Add(this.label136);
            this.groupBox2.Controls.Add(this.label107);
            this.groupBox2.Controls.Add(this.label135);
            this.groupBox2.Controls.Add(this.label106);
            this.groupBox2.Controls.Add(this.label134);
            this.groupBox2.Controls.Add(this.label105);
            this.groupBox2.Controls.Add(this.label133);
            this.groupBox2.Controls.Add(this.label104);
            this.groupBox2.Controls.Add(this.label132);
            this.groupBox2.Controls.Add(this.label103);
            this.groupBox2.Controls.Add(this.label131);
            this.groupBox2.Controls.Add(this.label102);
            this.groupBox2.Controls.Add(this.label130);
            this.groupBox2.Controls.Add(this.label101);
            this.groupBox2.Controls.Add(this.label129);
            this.groupBox2.Controls.Add(this.label100);
            this.groupBox2.Controls.Add(this.label128);
            this.groupBox2.Controls.Add(this.label114);
            this.groupBox2.Controls.Add(this.label127);
            this.groupBox2.Controls.Add(this.label113);
            this.groupBox2.Controls.Add(this.label126);
            this.groupBox2.Controls.Add(this.label112);
            this.groupBox2.Controls.Add(this.label125);
            this.groupBox2.Controls.Add(this.label111);
            this.groupBox2.Controls.Add(this.label124);
            this.groupBox2.Controls.Add(this.label110);
            this.groupBox2.Controls.Add(this.label123);
            this.groupBox2.Controls.Add(this.label119);
            this.groupBox2.Controls.Add(this.label122);
            this.groupBox2.Controls.Add(this.label118);
            this.groupBox2.Controls.Add(this.label121);
            this.groupBox2.Controls.Add(this.label117);
            this.groupBox2.Controls.Add(this.label120);
            this.groupBox2.Controls.Add(this.label116);
            this.groupBox2.Controls.Add(this.label115);
            this.groupBox2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(13, 294);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1122, 352);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = " 机械手 <--> 插片机(EWH) ";
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1149, 2);
            this.label1.TabIndex = 30;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label8.Location = new System.Drawing.Point(206, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 24);
            this.label8.TabIndex = 0;
            this.label8.Text = "心跳位";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label9.Location = new System.Drawing.Point(116, 89);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(154, 24);
            this.label9.TabIndex = 0;
            this.label9.Text = "机械手在安全位置";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label10.Location = new System.Drawing.Point(80, 118);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(190, 24);
            this.label10.TabIndex = 0;
            this.label10.Text = "炉管正在执行搬舟任务";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label11.Location = new System.Drawing.Point(8, 147);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(262, 24);
            this.label11.TabIndex = 0;
            this.label11.Text = "机械手收到炉管请求取舟的信号";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label12.Location = new System.Drawing.Point(8, 176);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(262, 24);
            this.label12.TabIndex = 0;
            this.label12.Text = "机械手收到炉管请求放舟的信号";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label13.Location = new System.Drawing.Point(80, 205);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(190, 24);
            this.label13.TabIndex = 0;
            this.label13.Text = "机械手向炉管取舟完成";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label14.Location = new System.Drawing.Point(80, 234);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(190, 24);
            this.label14.TabIndex = 0;
            this.label14.Text = "机械手向炉管放舟完成";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(284, 60);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 24);
            this.label15.TabIndex = 1;
            this.label15.Text = "000";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(331, 60);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 24);
            this.label16.TabIndex = 1;
            this.label16.Text = "000";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(378, 60);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 24);
            this.label17.TabIndex = 1;
            this.label17.Text = "000";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(425, 60);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 24);
            this.label18.TabIndex = 1;
            this.label18.Text = "000";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(472, 60);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(43, 24);
            this.label19.TabIndex = 1;
            this.label19.Text = "000";
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.LightGray;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label20.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label20.Location = new System.Drawing.Point(292, 88);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(30, 25);
            this.label20.TabIndex = 1;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.LightGray;
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label21.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label21.Location = new System.Drawing.Point(338, 88);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(30, 25);
            this.label21.TabIndex = 1;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.LightGray;
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label22.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label22.Location = new System.Drawing.Point(384, 88);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(30, 25);
            this.label22.TabIndex = 1;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.LightGray;
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label23.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label23.Location = new System.Drawing.Point(430, 88);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(30, 25);
            this.label23.TabIndex = 1;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.LightGray;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label24.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label24.Location = new System.Drawing.Point(476, 88);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(30, 25);
            this.label24.TabIndex = 1;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.LightGray;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label25.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label25.Location = new System.Drawing.Point(292, 117);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(30, 25);
            this.label25.TabIndex = 1;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.LightGray;
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label26.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label26.Location = new System.Drawing.Point(338, 117);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(30, 25);
            this.label26.TabIndex = 1;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.LightGray;
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label27.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label27.Location = new System.Drawing.Point(384, 117);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(30, 25);
            this.label27.TabIndex = 1;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.LightGray;
            this.label28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label28.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label28.Location = new System.Drawing.Point(430, 117);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(30, 25);
            this.label28.TabIndex = 1;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.LightGray;
            this.label29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label29.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label29.Location = new System.Drawing.Point(476, 117);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(30, 25);
            this.label29.TabIndex = 1;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.LightGray;
            this.label30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label30.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label30.Location = new System.Drawing.Point(292, 146);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(30, 25);
            this.label30.TabIndex = 1;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.LightGray;
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label31.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label31.Location = new System.Drawing.Point(338, 146);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(30, 25);
            this.label31.TabIndex = 1;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.LightGray;
            this.label32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label32.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label32.Location = new System.Drawing.Point(384, 146);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(30, 25);
            this.label32.TabIndex = 1;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.LightGray;
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label33.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label33.Location = new System.Drawing.Point(430, 146);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(30, 25);
            this.label33.TabIndex = 1;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.LightGray;
            this.label34.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label34.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label34.Location = new System.Drawing.Point(476, 146);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(30, 25);
            this.label34.TabIndex = 1;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.LightGray;
            this.label35.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label35.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label35.Location = new System.Drawing.Point(292, 175);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(30, 25);
            this.label35.TabIndex = 1;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.LightGray;
            this.label36.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label36.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label36.Location = new System.Drawing.Point(338, 175);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(30, 25);
            this.label36.TabIndex = 1;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.LightGray;
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label37.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label37.Location = new System.Drawing.Point(384, 175);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(30, 25);
            this.label37.TabIndex = 1;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.LightGray;
            this.label38.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label38.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label38.Location = new System.Drawing.Point(430, 175);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(30, 25);
            this.label38.TabIndex = 1;
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.LightGray;
            this.label39.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label39.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label39.Location = new System.Drawing.Point(476, 175);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(30, 25);
            this.label39.TabIndex = 1;
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.LightGray;
            this.label40.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label40.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label40.Location = new System.Drawing.Point(292, 204);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(30, 25);
            this.label40.TabIndex = 1;
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.LightGray;
            this.label41.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label41.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label41.Location = new System.Drawing.Point(338, 204);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(30, 25);
            this.label41.TabIndex = 1;
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.LightGray;
            this.label42.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label42.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label42.Location = new System.Drawing.Point(384, 204);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(30, 25);
            this.label42.TabIndex = 1;
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.Color.LightGray;
            this.label43.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label43.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label43.Location = new System.Drawing.Point(430, 204);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(30, 25);
            this.label43.TabIndex = 1;
            // 
            // label44
            // 
            this.label44.BackColor = System.Drawing.Color.LightGray;
            this.label44.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label44.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label44.Location = new System.Drawing.Point(476, 204);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(30, 25);
            this.label44.TabIndex = 1;
            // 
            // label45
            // 
            this.label45.BackColor = System.Drawing.Color.LightGray;
            this.label45.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label45.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label45.Location = new System.Drawing.Point(292, 233);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(30, 25);
            this.label45.TabIndex = 1;
            // 
            // label46
            // 
            this.label46.BackColor = System.Drawing.Color.LightGray;
            this.label46.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label46.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label46.Location = new System.Drawing.Point(338, 233);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(30, 25);
            this.label46.TabIndex = 1;
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.Color.LightGray;
            this.label47.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label47.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label47.Location = new System.Drawing.Point(384, 233);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(30, 25);
            this.label47.TabIndex = 1;
            // 
            // label48
            // 
            this.label48.BackColor = System.Drawing.Color.LightGray;
            this.label48.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label48.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label48.Location = new System.Drawing.Point(430, 233);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(30, 25);
            this.label48.TabIndex = 1;
            // 
            // label49
            // 
            this.label49.BackColor = System.Drawing.Color.LightGray;
            this.label49.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label49.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label49.Location = new System.Drawing.Point(476, 233);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(30, 25);
            this.label49.TabIndex = 1;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label50.Location = new System.Drawing.Point(733, 31);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(116, 24);
            this.label50.TabIndex = 0;
            this.label50.Text = "机械手   <---";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label51.Location = new System.Drawing.Point(785, 60);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(64, 24);
            this.label51.TabIndex = 0;
            this.label51.Text = "心跳位";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label52.Location = new System.Drawing.Point(731, 89);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(118, 24);
            this.label52.TabIndex = 0;
            this.label52.Text = "桨在取放位置";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label53.Location = new System.Drawing.Point(731, 118);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(118, 24);
            this.label53.TabIndex = 0;
            this.label53.Text = "炉管请求取舟";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label54.Location = new System.Drawing.Point(731, 147);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(118, 24);
            this.label54.TabIndex = 0;
            this.label54.Text = "炉管请求放舟";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label55.Location = new System.Drawing.Point(587, 176);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(262, 24);
            this.label55.TabIndex = 0;
            this.label55.Text = "炉管接收到机械手取舟完成信号";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label56.Location = new System.Drawing.Point(587, 205);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(262, 24);
            this.label56.TabIndex = 0;
            this.label56.Text = "炉管接收到机械手放舟完成信号";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label57.Location = new System.Drawing.Point(713, 234);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(136, 24);
            this.label57.TabIndex = 0;
            this.label57.Text = "炉管的桨有报警";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label58.Location = new System.Drawing.Point(867, 31);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(39, 24);
            this.label58.TabIndex = 0;
            this.label58.Text = "管1";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label59.Location = new System.Drawing.Point(913, 31);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(39, 24);
            this.label59.TabIndex = 0;
            this.label59.Text = "管2";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label60.Location = new System.Drawing.Point(959, 31);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(39, 24);
            this.label60.TabIndex = 0;
            this.label60.Text = "管3";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label61.Location = new System.Drawing.Point(1005, 31);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(39, 24);
            this.label61.TabIndex = 0;
            this.label61.Text = "管4";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label62.Location = new System.Drawing.Point(1051, 31);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(39, 24);
            this.label62.TabIndex = 0;
            this.label62.Text = "管5";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label63.Location = new System.Drawing.Point(863, 60);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(43, 24);
            this.label63.TabIndex = 1;
            this.label63.Text = "000";
            // 
            // label64
            // 
            this.label64.BackColor = System.Drawing.Color.LightGray;
            this.label64.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label64.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label64.Location = new System.Drawing.Point(871, 88);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(30, 25);
            this.label64.TabIndex = 1;
            // 
            // label65
            // 
            this.label65.BackColor = System.Drawing.Color.LightGray;
            this.label65.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label65.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label65.Location = new System.Drawing.Point(871, 117);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(30, 25);
            this.label65.TabIndex = 1;
            // 
            // label66
            // 
            this.label66.BackColor = System.Drawing.Color.LightGray;
            this.label66.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label66.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label66.Location = new System.Drawing.Point(871, 146);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(30, 25);
            this.label66.TabIndex = 1;
            // 
            // label67
            // 
            this.label67.BackColor = System.Drawing.Color.LightGray;
            this.label67.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label67.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label67.Location = new System.Drawing.Point(871, 175);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(30, 25);
            this.label67.TabIndex = 1;
            // 
            // label68
            // 
            this.label68.BackColor = System.Drawing.Color.LightGray;
            this.label68.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label68.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label68.Location = new System.Drawing.Point(871, 204);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(30, 25);
            this.label68.TabIndex = 1;
            // 
            // label69
            // 
            this.label69.BackColor = System.Drawing.Color.LightGray;
            this.label69.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label69.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label69.Location = new System.Drawing.Point(871, 233);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(30, 25);
            this.label69.TabIndex = 1;
            // 
            // label70
            // 
            this.label70.BackColor = System.Drawing.Color.LightGray;
            this.label70.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label70.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label70.Location = new System.Drawing.Point(917, 88);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(30, 25);
            this.label70.TabIndex = 1;
            // 
            // label71
            // 
            this.label71.BackColor = System.Drawing.Color.LightGray;
            this.label71.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label71.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label71.Location = new System.Drawing.Point(917, 117);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(30, 25);
            this.label71.TabIndex = 1;
            // 
            // label72
            // 
            this.label72.BackColor = System.Drawing.Color.LightGray;
            this.label72.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label72.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label72.Location = new System.Drawing.Point(917, 146);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(30, 25);
            this.label72.TabIndex = 1;
            // 
            // label73
            // 
            this.label73.BackColor = System.Drawing.Color.LightGray;
            this.label73.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label73.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label73.Location = new System.Drawing.Point(917, 175);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(30, 25);
            this.label73.TabIndex = 1;
            // 
            // label74
            // 
            this.label74.BackColor = System.Drawing.Color.LightGray;
            this.label74.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label74.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label74.Location = new System.Drawing.Point(917, 204);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(30, 25);
            this.label74.TabIndex = 1;
            // 
            // label75
            // 
            this.label75.BackColor = System.Drawing.Color.LightGray;
            this.label75.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label75.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label75.Location = new System.Drawing.Point(917, 233);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(30, 25);
            this.label75.TabIndex = 1;
            // 
            // label76
            // 
            this.label76.BackColor = System.Drawing.Color.LightGray;
            this.label76.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label76.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label76.Location = new System.Drawing.Point(963, 88);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(30, 25);
            this.label76.TabIndex = 1;
            // 
            // label77
            // 
            this.label77.BackColor = System.Drawing.Color.LightGray;
            this.label77.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label77.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label77.Location = new System.Drawing.Point(963, 117);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(30, 25);
            this.label77.TabIndex = 1;
            // 
            // label78
            // 
            this.label78.BackColor = System.Drawing.Color.LightGray;
            this.label78.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label78.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label78.Location = new System.Drawing.Point(963, 146);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(30, 25);
            this.label78.TabIndex = 1;
            // 
            // label79
            // 
            this.label79.BackColor = System.Drawing.Color.LightGray;
            this.label79.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label79.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label79.Location = new System.Drawing.Point(963, 175);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(30, 25);
            this.label79.TabIndex = 1;
            // 
            // label80
            // 
            this.label80.BackColor = System.Drawing.Color.LightGray;
            this.label80.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label80.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label80.Location = new System.Drawing.Point(963, 204);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(30, 25);
            this.label80.TabIndex = 1;
            // 
            // label81
            // 
            this.label81.BackColor = System.Drawing.Color.LightGray;
            this.label81.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label81.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label81.Location = new System.Drawing.Point(963, 233);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(30, 25);
            this.label81.TabIndex = 1;
            // 
            // label82
            // 
            this.label82.BackColor = System.Drawing.Color.LightGray;
            this.label82.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label82.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label82.Location = new System.Drawing.Point(1009, 88);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(30, 25);
            this.label82.TabIndex = 1;
            // 
            // label83
            // 
            this.label83.BackColor = System.Drawing.Color.LightGray;
            this.label83.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label83.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label83.Location = new System.Drawing.Point(1009, 117);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(30, 25);
            this.label83.TabIndex = 1;
            // 
            // label84
            // 
            this.label84.BackColor = System.Drawing.Color.LightGray;
            this.label84.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label84.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label84.Location = new System.Drawing.Point(1009, 146);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(30, 25);
            this.label84.TabIndex = 1;
            // 
            // label85
            // 
            this.label85.BackColor = System.Drawing.Color.LightGray;
            this.label85.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label85.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label85.Location = new System.Drawing.Point(1009, 175);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(30, 25);
            this.label85.TabIndex = 1;
            // 
            // label86
            // 
            this.label86.BackColor = System.Drawing.Color.LightGray;
            this.label86.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label86.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label86.Location = new System.Drawing.Point(1009, 204);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(30, 25);
            this.label86.TabIndex = 1;
            // 
            // label87
            // 
            this.label87.BackColor = System.Drawing.Color.LightGray;
            this.label87.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label87.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label87.Location = new System.Drawing.Point(1009, 233);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(30, 25);
            this.label87.TabIndex = 1;
            // 
            // label88
            // 
            this.label88.BackColor = System.Drawing.Color.LightGray;
            this.label88.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label88.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label88.Location = new System.Drawing.Point(1055, 88);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(30, 25);
            this.label88.TabIndex = 1;
            // 
            // label89
            // 
            this.label89.BackColor = System.Drawing.Color.LightGray;
            this.label89.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label89.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label89.Location = new System.Drawing.Point(1055, 117);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(30, 25);
            this.label89.TabIndex = 1;
            // 
            // label90
            // 
            this.label90.BackColor = System.Drawing.Color.LightGray;
            this.label90.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label90.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label90.Location = new System.Drawing.Point(1055, 146);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(30, 25);
            this.label90.TabIndex = 1;
            // 
            // label91
            // 
            this.label91.BackColor = System.Drawing.Color.LightGray;
            this.label91.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label91.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label91.Location = new System.Drawing.Point(1055, 175);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(30, 25);
            this.label91.TabIndex = 1;
            // 
            // label92
            // 
            this.label92.BackColor = System.Drawing.Color.LightGray;
            this.label92.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label92.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label92.Location = new System.Drawing.Point(1055, 204);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(30, 25);
            this.label92.TabIndex = 1;
            // 
            // label93
            // 
            this.label93.BackColor = System.Drawing.Color.LightGray;
            this.label93.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label93.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label93.Location = new System.Drawing.Point(1055, 233);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(30, 25);
            this.label93.TabIndex = 1;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label94.Location = new System.Drawing.Point(910, 60);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(43, 24);
            this.label94.TabIndex = 1;
            this.label94.Text = "000";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label95.Location = new System.Drawing.Point(957, 60);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(43, 24);
            this.label95.TabIndex = 1;
            this.label95.Text = "000";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label96.Location = new System.Drawing.Point(1004, 60);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(43, 24);
            this.label96.TabIndex = 1;
            this.label96.Text = "000";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label97.Location = new System.Drawing.Point(1051, 60);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(43, 24);
            this.label97.TabIndex = 1;
            this.label97.Text = "000";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label98.Location = new System.Drawing.Point(154, 39);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(116, 24);
            this.label98.TabIndex = 0;
            this.label98.Text = "机械手   --->";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label99.Location = new System.Drawing.Point(285, 39);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(118, 24);
            this.label99.TabIndex = 0;
            this.label99.Text = "插片机(EWH)";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label100.Location = new System.Drawing.Point(224, 67);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(46, 24);
            this.label100.TabIndex = 0;
            this.label100.Text = "心跳";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label101.Location = new System.Drawing.Point(224, 95);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(46, 24);
            this.label101.TabIndex = 0;
            this.label101.Text = "舟号";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label102.Location = new System.Drawing.Point(152, 123);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(118, 24);
            this.label102.TabIndex = 0;
            this.label102.Text = "来自那个炉管";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label103.Location = new System.Drawing.Point(170, 151);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(100, 24);
            this.label103.TabIndex = 0;
            this.label103.Text = "上下料模式";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label104.Location = new System.Drawing.Point(206, 179);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(64, 24);
            this.label104.TabIndex = 0;
            this.label104.Text = "舟状态";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label105.Location = new System.Drawing.Point(170, 207);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(100, 24);
            this.label105.TabIndex = 0;
            this.label105.Text = "请求发送舟";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label106.Location = new System.Drawing.Point(170, 235);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(100, 24);
            this.label106.TabIndex = 0;
            this.label106.Text = "请求接收舟";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label107.Location = new System.Drawing.Point(170, 263);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(100, 24);
            this.label107.TabIndex = 0;
            this.label107.Text = "任务执行中";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label108.Location = new System.Drawing.Point(188, 291);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(82, 24);
            this.label108.TabIndex = 0;
            this.label108.Text = "任务暂停";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label109.Location = new System.Drawing.Point(170, 319);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(100, 24);
            this.label109.TabIndex = 0;
            this.label109.Text = "接收舟完成";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label110.Location = new System.Drawing.Point(317, 66);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(43, 24);
            this.label110.TabIndex = 1;
            this.label110.Text = "000";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label111.Location = new System.Drawing.Point(317, 93);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(43, 24);
            this.label111.TabIndex = 1;
            this.label111.Text = "000";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label112.Location = new System.Drawing.Point(317, 120);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(43, 24);
            this.label112.TabIndex = 1;
            this.label112.Text = "000";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label113.Location = new System.Drawing.Point(317, 147);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(43, 24);
            this.label113.TabIndex = 1;
            this.label113.Text = "000";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label114.Location = new System.Drawing.Point(317, 174);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(43, 24);
            this.label114.TabIndex = 1;
            this.label114.Text = "000";
            // 
            // label115
            // 
            this.label115.BackColor = System.Drawing.Color.LightGray;
            this.label115.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label115.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label115.Location = new System.Drawing.Point(321, 201);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(30, 25);
            this.label115.TabIndex = 1;
            // 
            // label116
            // 
            this.label116.BackColor = System.Drawing.Color.LightGray;
            this.label116.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label116.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label116.Location = new System.Drawing.Point(321, 229);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(30, 25);
            this.label116.TabIndex = 1;
            // 
            // label117
            // 
            this.label117.BackColor = System.Drawing.Color.LightGray;
            this.label117.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label117.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label117.Location = new System.Drawing.Point(321, 257);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(30, 25);
            this.label117.TabIndex = 1;
            // 
            // label118
            // 
            this.label118.BackColor = System.Drawing.Color.LightGray;
            this.label118.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label118.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label118.Location = new System.Drawing.Point(321, 285);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(30, 25);
            this.label118.TabIndex = 1;
            // 
            // label119
            // 
            this.label119.BackColor = System.Drawing.Color.LightGray;
            this.label119.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label119.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label119.Location = new System.Drawing.Point(321, 313);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(30, 25);
            this.label119.TabIndex = 1;
            // 
            // label120
            // 
            this.label120.BackColor = System.Drawing.Color.LightGray;
            this.label120.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label120.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label120.Location = new System.Drawing.Point(900, 201);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(30, 25);
            this.label120.TabIndex = 1;
            // 
            // label121
            // 
            this.label121.BackColor = System.Drawing.Color.LightGray;
            this.label121.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label121.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label121.Location = new System.Drawing.Point(900, 229);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(30, 25);
            this.label121.TabIndex = 1;
            // 
            // label122
            // 
            this.label122.BackColor = System.Drawing.Color.LightGray;
            this.label122.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label122.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label122.Location = new System.Drawing.Point(900, 257);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(30, 25);
            this.label122.TabIndex = 1;
            // 
            // label123
            // 
            this.label123.BackColor = System.Drawing.Color.LightGray;
            this.label123.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label123.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label123.Location = new System.Drawing.Point(900, 285);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(30, 25);
            this.label123.TabIndex = 1;
            // 
            // label124
            // 
            this.label124.BackColor = System.Drawing.Color.LightGray;
            this.label124.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label124.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label124.Location = new System.Drawing.Point(900, 313);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(30, 25);
            this.label124.TabIndex = 1;
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label125.Location = new System.Drawing.Point(896, 66);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(43, 24);
            this.label125.TabIndex = 1;
            this.label125.Text = "000";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label126.Location = new System.Drawing.Point(896, 93);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(43, 24);
            this.label126.TabIndex = 1;
            this.label126.Text = "000";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label127.Location = new System.Drawing.Point(896, 120);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(43, 24);
            this.label127.TabIndex = 1;
            this.label127.Text = "000";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label128.Location = new System.Drawing.Point(896, 147);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(43, 24);
            this.label128.TabIndex = 1;
            this.label128.Text = "000";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label129.Location = new System.Drawing.Point(896, 174);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(43, 24);
            this.label129.TabIndex = 1;
            this.label129.Text = "000";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label130.Location = new System.Drawing.Point(803, 66);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(46, 24);
            this.label130.TabIndex = 0;
            this.label130.Text = "心跳";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label131.Location = new System.Drawing.Point(803, 93);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(46, 24);
            this.label131.TabIndex = 0;
            this.label131.Text = "舟号";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label132.Location = new System.Drawing.Point(731, 120);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(118, 24);
            this.label132.TabIndex = 0;
            this.label132.Text = "来自那个炉管";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label133.Location = new System.Drawing.Point(749, 147);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(100, 24);
            this.label133.TabIndex = 0;
            this.label133.Text = "上下料模式";
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label134.Location = new System.Drawing.Point(785, 174);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(64, 24);
            this.label134.TabIndex = 0;
            this.label134.Text = "舟状态";
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label135.Location = new System.Drawing.Point(749, 201);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(100, 24);
            this.label135.TabIndex = 0;
            this.label135.Text = "请求发送舟";
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label136.Location = new System.Drawing.Point(749, 228);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(100, 24);
            this.label136.TabIndex = 0;
            this.label136.Text = "请求接收舟";
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label137.Location = new System.Drawing.Point(749, 255);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(100, 24);
            this.label137.TabIndex = 0;
            this.label137.Text = "任务执行中";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label138.Location = new System.Drawing.Point(767, 282);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(82, 24);
            this.label138.TabIndex = 0;
            this.label138.Text = "任务暂停";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label139.Location = new System.Drawing.Point(749, 309);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(100, 24);
            this.label139.TabIndex = 0;
            this.label139.Text = "接收舟完成";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label140.Location = new System.Drawing.Point(864, 39);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(118, 24);
            this.label140.TabIndex = 0;
            this.label140.Text = "插片机(EWH)";
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label141.Location = new System.Drawing.Point(733, 39);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(116, 24);
            this.label141.TabIndex = 0;
            this.label141.Text = "机械手   <---";
            // 
            // UCCommIO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "UCCommIO";
            this.Size = new System.Drawing.Size(1149, 991);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label120;
    }
}

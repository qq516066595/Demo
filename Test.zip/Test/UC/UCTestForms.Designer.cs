﻿namespace Test.UC
{
    partial class UCTestForms
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ucTextBoxEx4 = new HZH_Controls.Controls.UCTextBoxEx();
            this.ucTextBoxEx3 = new HZH_Controls.Controls.UCTextBoxEx();
            this.ucTextBoxEx2 = new HZH_Controls.Controls.UCTextBoxEx();
            this.ucTextBoxEx1 = new HZH_Controls.Controls.UCTextBoxEx();
            this.textBoxTransparent1 = new HZH_Controls.Controls.TextBoxTransparent();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ucCheckBox4 = new HZH_Controls.Controls.UCCheckBox();
            this.ucCheckBox3 = new HZH_Controls.Controls.UCCheckBox();
            this.ucCheckBox2 = new HZH_Controls.Controls.UCCheckBox();
            this.ucCheckBox1 = new HZH_Controls.Controls.UCCheckBox();
            this.ucRadioButton4 = new HZH_Controls.Controls.UCRadioButton();
            this.ucRadioButton3 = new HZH_Controls.Controls.UCRadioButton();
            this.ucRadioButton2 = new HZH_Controls.Controls.UCRadioButton();
            this.ucRadioButton1 = new HZH_Controls.Controls.UCRadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.ucComboxGrid1 = new HZH_Controls.Controls.UCComboxGrid();
            this.ucComboBox2 = new HZH_Controls.Controls.UCCombox();
            this.ucComboBox1 = new HZH_Controls.Controls.UCCombox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.ucDatePickerExt3 = new HZH_Controls.Controls.UCDatePickerExt();
            this.ucDatePickerExt2 = new HZH_Controls.Controls.UCDatePickerExt();
            this.ucDatePickerExt1 = new HZH_Controls.Controls.UCDatePickerExt();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ucSwitch10 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch5 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch9 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch1 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch6 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch2 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch8 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch3 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch4 = new HZH_Controls.Controls.UCSwitch();
            this.ucSwitch7 = new HZH_Controls.Controls.UCSwitch();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ucNumTextBox2 = new HZH_Controls.Controls.UCNumTextBox();
            this.ucNumTextBox1 = new HZH_Controls.Controls.UCNumTextBox();
            this.ucDatePickerExt21 = new HZH_Controls.Controls.UCDatePickerExt2();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.ucTextBoxEx4);
            this.groupBox4.Controls.Add(this.ucTextBoxEx3);
            this.groupBox4.Controls.Add(this.ucTextBoxEx2);
            this.groupBox4.Controls.Add(this.ucTextBoxEx1);
            this.groupBox4.Controls.Add(this.textBoxTransparent1);
            this.groupBox4.Location = new System.Drawing.Point(168, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(209, 327);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "文本框";
            // 
            // ucTextBoxEx4
            // 
            this.ucTextBoxEx4.BackColor = System.Drawing.Color.Transparent;
            this.ucTextBoxEx4.ConerRadius = 5;
            this.ucTextBoxEx4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ucTextBoxEx4.DecLength = 2;
            this.ucTextBoxEx4.FillColor = System.Drawing.Color.Empty;
            this.ucTextBoxEx4.FocusBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucTextBoxEx4.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucTextBoxEx4.InputText = "";
            this.ucTextBoxEx4.InputType = HZH_Controls.TextInputType.NotControl;
            this.ucTextBoxEx4.IsFocusColor = true;
            this.ucTextBoxEx4.IsRadius = true;
            this.ucTextBoxEx4.IsShowClearBtn = true;
            this.ucTextBoxEx4.IsShowKeyboard = true;
            this.ucTextBoxEx4.IsShowRect = true;
            this.ucTextBoxEx4.IsShowSearchBtn = false;
            this.ucTextBoxEx4.KeyBoardType = HZH_Controls.Controls.KeyBoardType.UCKeyBorderAll_EN;
            this.ucTextBoxEx4.Location = new System.Drawing.Point(6, 273);
            this.ucTextBoxEx4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucTextBoxEx4.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.ucTextBoxEx4.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.ucTextBoxEx4.Name = "ucTextBoxEx4";
            this.ucTextBoxEx4.Padding = new System.Windows.Forms.Padding(5);
            this.ucTextBoxEx4.PasswordChar = '\0';
            this.ucTextBoxEx4.PromptColor = System.Drawing.Color.Gray;
            this.ucTextBoxEx4.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucTextBoxEx4.PromptText = "水印文字";
            this.ucTextBoxEx4.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucTextBoxEx4.RectWidth = 1;
            this.ucTextBoxEx4.RegexPattern = "";
            this.ucTextBoxEx4.Size = new System.Drawing.Size(195, 42);
            this.ucTextBoxEx4.TabIndex = 2;
            // 
            // ucTextBoxEx3
            // 
            this.ucTextBoxEx3.BackColor = System.Drawing.Color.Transparent;
            this.ucTextBoxEx3.ConerRadius = 5;
            this.ucTextBoxEx3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ucTextBoxEx3.DecLength = 2;
            this.ucTextBoxEx3.FillColor = System.Drawing.Color.Empty;
            this.ucTextBoxEx3.FocusBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucTextBoxEx3.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucTextBoxEx3.InputText = "手写键盘";
            this.ucTextBoxEx3.InputType = HZH_Controls.TextInputType.NotControl;
            this.ucTextBoxEx3.IsFocusColor = true;
            this.ucTextBoxEx3.IsRadius = true;
            this.ucTextBoxEx3.IsShowClearBtn = true;
            this.ucTextBoxEx3.IsShowKeyboard = true;
            this.ucTextBoxEx3.IsShowRect = true;
            this.ucTextBoxEx3.IsShowSearchBtn = false;
            this.ucTextBoxEx3.KeyBoardType = HZH_Controls.Controls.KeyBoardType.UCKeyBorderHand;
            this.ucTextBoxEx3.Location = new System.Drawing.Point(6, 206);
            this.ucTextBoxEx3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucTextBoxEx3.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.ucTextBoxEx3.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.ucTextBoxEx3.Name = "ucTextBoxEx3";
            this.ucTextBoxEx3.Padding = new System.Windows.Forms.Padding(5);
            this.ucTextBoxEx3.PasswordChar = '\0';
            this.ucTextBoxEx3.PromptColor = System.Drawing.Color.Gray;
            this.ucTextBoxEx3.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucTextBoxEx3.PromptText = "";
            this.ucTextBoxEx3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucTextBoxEx3.RectWidth = 1;
            this.ucTextBoxEx3.RegexPattern = "";
            this.ucTextBoxEx3.Size = new System.Drawing.Size(195, 42);
            this.ucTextBoxEx3.TabIndex = 2;
            // 
            // ucTextBoxEx2
            // 
            this.ucTextBoxEx2.BackColor = System.Drawing.Color.Transparent;
            this.ucTextBoxEx2.ConerRadius = 5;
            this.ucTextBoxEx2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ucTextBoxEx2.DecLength = 2;
            this.ucTextBoxEx2.FillColor = System.Drawing.Color.Empty;
            this.ucTextBoxEx2.FocusBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucTextBoxEx2.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucTextBoxEx2.InputText = "英文键盘";
            this.ucTextBoxEx2.InputType = HZH_Controls.TextInputType.NotControl;
            this.ucTextBoxEx2.IsFocusColor = true;
            this.ucTextBoxEx2.IsRadius = true;
            this.ucTextBoxEx2.IsShowClearBtn = true;
            this.ucTextBoxEx2.IsShowKeyboard = true;
            this.ucTextBoxEx2.IsShowRect = true;
            this.ucTextBoxEx2.IsShowSearchBtn = false;
            this.ucTextBoxEx2.KeyBoardType = HZH_Controls.Controls.KeyBoardType.UCKeyBorderAll_EN;
            this.ucTextBoxEx2.Location = new System.Drawing.Point(6, 139);
            this.ucTextBoxEx2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucTextBoxEx2.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.ucTextBoxEx2.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.ucTextBoxEx2.Name = "ucTextBoxEx2";
            this.ucTextBoxEx2.Padding = new System.Windows.Forms.Padding(5);
            this.ucTextBoxEx2.PasswordChar = '\0';
            this.ucTextBoxEx2.PromptColor = System.Drawing.Color.Gray;
            this.ucTextBoxEx2.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucTextBoxEx2.PromptText = "";
            this.ucTextBoxEx2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucTextBoxEx2.RectWidth = 1;
            this.ucTextBoxEx2.RegexPattern = "";
            this.ucTextBoxEx2.Size = new System.Drawing.Size(195, 42);
            this.ucTextBoxEx2.TabIndex = 2;
            // 
            // ucTextBoxEx1
            // 
            this.ucTextBoxEx1.BackColor = System.Drawing.Color.Transparent;
            this.ucTextBoxEx1.ConerRadius = 5;
            this.ucTextBoxEx1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ucTextBoxEx1.DecLength = 2;
            this.ucTextBoxEx1.FillColor = System.Drawing.Color.Empty;
            this.ucTextBoxEx1.FocusBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucTextBoxEx1.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucTextBoxEx1.InputText = "数字键盘";
            this.ucTextBoxEx1.InputType = HZH_Controls.TextInputType.NotControl;
            this.ucTextBoxEx1.IsFocusColor = true;
            this.ucTextBoxEx1.IsRadius = true;
            this.ucTextBoxEx1.IsShowClearBtn = true;
            this.ucTextBoxEx1.IsShowKeyboard = true;
            this.ucTextBoxEx1.IsShowRect = true;
            this.ucTextBoxEx1.IsShowSearchBtn = false;
            this.ucTextBoxEx1.KeyBoardType = HZH_Controls.Controls.KeyBoardType.UCKeyBorderNum;
            this.ucTextBoxEx1.Location = new System.Drawing.Point(7, 72);
            this.ucTextBoxEx1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucTextBoxEx1.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.ucTextBoxEx1.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.ucTextBoxEx1.Name = "ucTextBoxEx1";
            this.ucTextBoxEx1.Padding = new System.Windows.Forms.Padding(5);
            this.ucTextBoxEx1.PasswordChar = '\0';
            this.ucTextBoxEx1.PromptColor = System.Drawing.Color.Gray;
            this.ucTextBoxEx1.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucTextBoxEx1.PromptText = "";
            this.ucTextBoxEx1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucTextBoxEx1.RectWidth = 1;
            this.ucTextBoxEx1.RegexPattern = "";
            this.ucTextBoxEx1.Size = new System.Drawing.Size(195, 42);
            this.ucTextBoxEx1.TabIndex = 2;
            // 
            // textBoxTransparent1
            // 
            this.textBoxTransparent1.BackAlpha = 10;
            this.textBoxTransparent1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.textBoxTransparent1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTransparent1.DecLength = 2;
            this.textBoxTransparent1.Font = new System.Drawing.Font("宋体", 13F);
            this.textBoxTransparent1.InputType = HZH_Controls.TextInputType.NotControl;
            this.textBoxTransparent1.Location = new System.Drawing.Point(6, 30);
            this.textBoxTransparent1.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.textBoxTransparent1.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.textBoxTransparent1.MyRectangle = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.textBoxTransparent1.Name = "textBoxTransparent1";
            this.textBoxTransparent1.OldText = null;
            this.textBoxTransparent1.PromptColor = System.Drawing.Color.Gray;
            this.textBoxTransparent1.PromptFont = new System.Drawing.Font("微软雅黑", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.textBoxTransparent1.PromptText = "";
            this.textBoxTransparent1.RegexPattern = "";
            this.textBoxTransparent1.Size = new System.Drawing.Size(164, 20);
            this.textBoxTransparent1.TabIndex = 0;
            this.textBoxTransparent1.Text = "这是一个透明文本框";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ucCheckBox4);
            this.groupBox3.Controls.Add(this.ucCheckBox3);
            this.groupBox3.Controls.Add(this.ucCheckBox2);
            this.groupBox3.Controls.Add(this.ucCheckBox1);
            this.groupBox3.Controls.Add(this.ucRadioButton4);
            this.groupBox3.Controls.Add(this.ucRadioButton3);
            this.groupBox3.Controls.Add(this.ucRadioButton2);
            this.groupBox3.Controls.Add(this.ucRadioButton1);
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(149, 327);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "单选/复选";
            // 
            // ucCheckBox4
            // 
            this.ucCheckBox4.BackColor = System.Drawing.Color.Transparent;
            this.ucCheckBox4.Checked = false;
            this.ucCheckBox4.Location = new System.Drawing.Point(17, 279);
            this.ucCheckBox4.Name = "ucCheckBox4";
            this.ucCheckBox4.Padding = new System.Windows.Forms.Padding(1);
            this.ucCheckBox4.Size = new System.Drawing.Size(126, 30);
            this.ucCheckBox4.TabIndex = 1;
            this.ucCheckBox4.TextValue = "复选框4";
            // 
            // ucCheckBox3
            // 
            this.ucCheckBox3.BackColor = System.Drawing.Color.Transparent;
            this.ucCheckBox3.Checked = false;
            this.ucCheckBox3.Location = new System.Drawing.Point(17, 242);
            this.ucCheckBox3.Name = "ucCheckBox3";
            this.ucCheckBox3.Padding = new System.Windows.Forms.Padding(1);
            this.ucCheckBox3.Size = new System.Drawing.Size(126, 30);
            this.ucCheckBox3.TabIndex = 1;
            this.ucCheckBox3.TextValue = "复选框3";
            // 
            // ucCheckBox2
            // 
            this.ucCheckBox2.BackColor = System.Drawing.Color.Transparent;
            this.ucCheckBox2.Checked = true;
            this.ucCheckBox2.Location = new System.Drawing.Point(17, 205);
            this.ucCheckBox2.Name = "ucCheckBox2";
            this.ucCheckBox2.Padding = new System.Windows.Forms.Padding(1);
            this.ucCheckBox2.Size = new System.Drawing.Size(126, 30);
            this.ucCheckBox2.TabIndex = 1;
            this.ucCheckBox2.TextValue = "复选框2";
            // 
            // ucCheckBox1
            // 
            this.ucCheckBox1.BackColor = System.Drawing.Color.Transparent;
            this.ucCheckBox1.Checked = true;
            this.ucCheckBox1.Location = new System.Drawing.Point(17, 168);
            this.ucCheckBox1.Name = "ucCheckBox1";
            this.ucCheckBox1.Padding = new System.Windows.Forms.Padding(1);
            this.ucCheckBox1.Size = new System.Drawing.Size(126, 30);
            this.ucCheckBox1.TabIndex = 1;
            this.ucCheckBox1.TextValue = "复选框1";
            // 
            // ucRadioButton4
            // 
            this.ucRadioButton4.Checked = false;
            this.ucRadioButton4.GroupName = null;
            this.ucRadioButton4.Location = new System.Drawing.Point(17, 131);
            this.ucRadioButton4.Name = "ucRadioButton4";
            this.ucRadioButton4.Size = new System.Drawing.Size(126, 30);
            this.ucRadioButton4.TabIndex = 0;
            this.ucRadioButton4.TextValue = "单选按钮4";
            // 
            // ucRadioButton3
            // 
            this.ucRadioButton3.Checked = false;
            this.ucRadioButton3.GroupName = null;
            this.ucRadioButton3.Location = new System.Drawing.Point(17, 94);
            this.ucRadioButton3.Name = "ucRadioButton3";
            this.ucRadioButton3.Size = new System.Drawing.Size(126, 30);
            this.ucRadioButton3.TabIndex = 0;
            this.ucRadioButton3.TextValue = "单选按钮3";
            // 
            // ucRadioButton2
            // 
            this.ucRadioButton2.Checked = false;
            this.ucRadioButton2.GroupName = null;
            this.ucRadioButton2.Location = new System.Drawing.Point(17, 57);
            this.ucRadioButton2.Name = "ucRadioButton2";
            this.ucRadioButton2.Size = new System.Drawing.Size(126, 30);
            this.ucRadioButton2.TabIndex = 0;
            this.ucRadioButton2.TextValue = "单选按钮2";
            // 
            // ucRadioButton1
            // 
            this.ucRadioButton1.Checked = true;
            this.ucRadioButton1.GroupName = null;
            this.ucRadioButton1.Location = new System.Drawing.Point(17, 20);
            this.ucRadioButton1.Name = "ucRadioButton1";
            this.ucRadioButton1.Size = new System.Drawing.Size(126, 30);
            this.ucRadioButton1.TabIndex = 0;
            this.ucRadioButton1.TextValue = "单选按钮1";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.ucComboxGrid1);
            this.groupBox6.Controls.Add(this.ucComboBox2);
            this.groupBox6.Controls.Add(this.ucComboBox1);
            this.groupBox6.Location = new System.Drawing.Point(3, 530);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(618, 81);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "下拉列表";
            // 
            // ucComboxGrid1
            // 
            this.ucComboxGrid1.BackColor = System.Drawing.Color.Transparent;
            this.ucComboxGrid1.BackColorExt = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboxGrid1.BoxStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ucComboxGrid1.ConerRadius = 5;
            this.ucComboxGrid1.DropPanelHeight = -1;
            this.ucComboxGrid1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboxGrid1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.ucComboxGrid1.GridColumns = null;
            this.ucComboxGrid1.GridDataSource = null;
            this.ucComboxGrid1.GridRowType = typeof(HZH_Controls.Controls.UCDataGridViewRow);
            this.ucComboxGrid1.IsRadius = false;
            this.ucComboxGrid1.IsShowRect = true;
            this.ucComboxGrid1.ItemWidth = 70;
            this.ucComboxGrid1.Location = new System.Drawing.Point(429, 26);
            this.ucComboxGrid1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucComboxGrid1.Name = "ucComboxGrid1";
            this.ucComboxGrid1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboxGrid1.RectWidth = 1;
            this.ucComboxGrid1.SelectedIndex = -1;
            this.ucComboxGrid1.SelectedValue = "";
            this.ucComboxGrid1.SelectSource = null;
            this.ucComboxGrid1.Size = new System.Drawing.Size(173, 32);
            this.ucComboxGrid1.Source = null;
            this.ucComboxGrid1.TabIndex = 10;
            this.ucComboxGrid1.TextField = "Name";
            this.ucComboxGrid1.TextValue = null;
            this.ucComboxGrid1.TriangleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            // 
            // ucComboBox2
            // 
            this.ucComboBox2.BackColor = System.Drawing.Color.Transparent;
            this.ucComboBox2.BackColorExt = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboBox2.BoxStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ucComboBox2.ConerRadius = 5;
            this.ucComboBox2.DropPanelHeight = -1;
            this.ucComboBox2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboBox2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.ucComboBox2.IsRadius = false;
            this.ucComboBox2.IsShowRect = true;
            this.ucComboBox2.ItemWidth = 70;
            this.ucComboBox2.Location = new System.Drawing.Point(224, 26);
            this.ucComboBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucComboBox2.Name = "ucComboBox2";
            this.ucComboBox2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboBox2.RectWidth = 1;
            this.ucComboBox2.SelectedIndex = -1;
            this.ucComboBox2.SelectedValue = "";
            this.ucComboBox2.Size = new System.Drawing.Size(173, 32);
            this.ucComboBox2.Source = null;
            this.ucComboBox2.TabIndex = 5;
            this.ucComboBox2.TextValue = null;
            this.ucComboBox2.TriangleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            // 
            // ucComboBox1
            // 
            this.ucComboBox1.BackColor = System.Drawing.Color.Transparent;
            this.ucComboBox1.BackColorExt = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboBox1.BoxStyle = System.Windows.Forms.ComboBoxStyle.DropDown;
            this.ucComboBox1.ConerRadius = 5;
            this.ucComboBox1.DropPanelHeight = -1;
            this.ucComboBox1.FillColor = System.Drawing.Color.White;
            this.ucComboBox1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.ucComboBox1.IsRadius = true;
            this.ucComboBox1.IsShowRect = true;
            this.ucComboBox1.ItemWidth = 70;
            this.ucComboBox1.Location = new System.Drawing.Point(7, 26);
            this.ucComboBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucComboBox1.Name = "ucComboBox1";
            this.ucComboBox1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucComboBox1.RectWidth = 1;
            this.ucComboBox1.SelectedIndex = -1;
            this.ucComboBox1.SelectedValue = "";
            this.ucComboBox1.Size = new System.Drawing.Size(173, 32);
            this.ucComboBox1.Source = null;
            this.ucComboBox1.TabIndex = 5;
            this.ucComboBox1.TextValue = null;
            this.ucComboBox1.TriangleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.ucDatePickerExt21);
            this.groupBox7.Controls.Add(this.ucDatePickerExt3);
            this.groupBox7.Controls.Add(this.ucDatePickerExt2);
            this.groupBox7.Controls.Add(this.ucDatePickerExt1);
            this.groupBox7.Location = new System.Drawing.Point(3, 336);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(374, 188);
            this.groupBox7.TabIndex = 8;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "日历";
            // 
            // ucDatePickerExt3
            // 
            this.ucDatePickerExt3.BackColor = System.Drawing.Color.Transparent;
            this.ucDatePickerExt3.ConerRadius = 5;
            this.ucDatePickerExt3.CurrentTime = new System.DateTime(2019, 8, 8, 15, 17, 11, 0);
            this.ucDatePickerExt3.FillColor = System.Drawing.Color.Transparent;
            this.ucDatePickerExt3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucDatePickerExt3.IsRadius = true;
            this.ucDatePickerExt3.IsShowRect = true;
            this.ucDatePickerExt3.Location = new System.Drawing.Point(224, 62);
            this.ucDatePickerExt3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucDatePickerExt3.Name = "ucDatePickerExt3";
            this.ucDatePickerExt3.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.ucDatePickerExt3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucDatePickerExt3.RectWidth = 1;
            this.ucDatePickerExt3.Size = new System.Drawing.Size(128, 39);
            this.ucDatePickerExt3.TabIndex = 0;
            this.ucDatePickerExt3.TimeFontSize = 20;
            this.ucDatePickerExt3.TimeType = HZH_Controls.Controls.DateTimePickerType.Time;
            // 
            // ucDatePickerExt2
            // 
            this.ucDatePickerExt2.BackColor = System.Drawing.Color.Transparent;
            this.ucDatePickerExt2.ConerRadius = 5;
            this.ucDatePickerExt2.CurrentTime = new System.DateTime(2019, 8, 8, 15, 17, 11, 0);
            this.ucDatePickerExt2.FillColor = System.Drawing.Color.Transparent;
            this.ucDatePickerExt2.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucDatePickerExt2.IsRadius = true;
            this.ucDatePickerExt2.IsShowRect = true;
            this.ucDatePickerExt2.Location = new System.Drawing.Point(7, 62);
            this.ucDatePickerExt2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucDatePickerExt2.Name = "ucDatePickerExt2";
            this.ucDatePickerExt2.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.ucDatePickerExt2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucDatePickerExt2.RectWidth = 1;
            this.ucDatePickerExt2.Size = new System.Drawing.Size(210, 39);
            this.ucDatePickerExt2.TabIndex = 0;
            this.ucDatePickerExt2.TimeFontSize = 20;
            this.ucDatePickerExt2.TimeType = HZH_Controls.Controls.DateTimePickerType.Date;
            // 
            // ucDatePickerExt1
            // 
            this.ucDatePickerExt1.BackColor = System.Drawing.Color.Transparent;
            this.ucDatePickerExt1.ConerRadius = 5;
            this.ucDatePickerExt1.CurrentTime = new System.DateTime(2019, 8, 8, 15, 17, 11, 0);
            this.ucDatePickerExt1.FillColor = System.Drawing.Color.Transparent;
            this.ucDatePickerExt1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucDatePickerExt1.IsRadius = true;
            this.ucDatePickerExt1.IsShowRect = true;
            this.ucDatePickerExt1.Location = new System.Drawing.Point(7, 17);
            this.ucDatePickerExt1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucDatePickerExt1.Name = "ucDatePickerExt1";
            this.ucDatePickerExt1.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.ucDatePickerExt1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucDatePickerExt1.RectWidth = 1;
            this.ucDatePickerExt1.Size = new System.Drawing.Size(335, 39);
            this.ucDatePickerExt1.TabIndex = 0;
            this.ucDatePickerExt1.TimeFontSize = 20;
            this.ucDatePickerExt1.TimeType = HZH_Controls.Controls.DateTimePickerType.DateTime;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ucSwitch10);
            this.groupBox1.Controls.Add(this.ucSwitch5);
            this.groupBox1.Controls.Add(this.ucSwitch9);
            this.groupBox1.Controls.Add(this.ucSwitch1);
            this.groupBox1.Controls.Add(this.ucSwitch6);
            this.groupBox1.Controls.Add(this.ucSwitch2);
            this.groupBox1.Controls.Add(this.ucSwitch8);
            this.groupBox1.Controls.Add(this.ucSwitch3);
            this.groupBox1.Controls.Add(this.ucSwitch4);
            this.groupBox1.Controls.Add(this.ucSwitch7);
            this.groupBox1.Location = new System.Drawing.Point(383, 174);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(238, 281);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "下拉列表";
            // 
            // ucSwitch10
            // 
            this.ucSwitch10.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch10.Checked = false;
            this.ucSwitch10.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch10.FalseTextColr = System.Drawing.Color.Green;
            this.ucSwitch10.Location = new System.Drawing.Point(136, 173);
            this.ucSwitch10.Name = "ucSwitch10";
            this.ucSwitch10.Size = new System.Drawing.Size(86, 34);
            this.ucSwitch10.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch10.TabIndex = 9;
            this.ucSwitch10.Texts = new string[] {
        "确定",
        "取消"};
            this.ucSwitch10.TrueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucSwitch10.TrueTextColr = System.Drawing.Color.Black;
            // 
            // ucSwitch5
            // 
            this.ucSwitch5.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch5.Checked = true;
            this.ucSwitch5.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch5.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch5.Location = new System.Drawing.Point(136, 20);
            this.ucSwitch5.Name = "ucSwitch5";
            this.ucSwitch5.Size = new System.Drawing.Size(86, 34);
            this.ucSwitch5.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch5.TabIndex = 13;
            this.ucSwitch5.Texts = new string[0];
            this.ucSwitch5.TrueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucSwitch5.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch9
            // 
            this.ucSwitch9.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch9.Checked = true;
            this.ucSwitch9.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch9.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch9.Location = new System.Drawing.Point(136, 122);
            this.ucSwitch9.Name = "ucSwitch9";
            this.ucSwitch9.Size = new System.Drawing.Size(86, 34);
            this.ucSwitch9.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch9.TabIndex = 10;
            this.ucSwitch9.Texts = new string[] {
        "确定",
        "取消"};
            this.ucSwitch9.TrueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucSwitch9.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch1
            // 
            this.ucSwitch1.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch1.Checked = true;
            this.ucSwitch1.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch1.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch1.Location = new System.Drawing.Point(22, 224);
            this.ucSwitch1.Name = "ucSwitch1";
            this.ucSwitch1.Size = new System.Drawing.Size(86, 34);
            this.ucSwitch1.SwitchType = HZH_Controls.Controls.SwitchType.Line;
            this.ucSwitch1.TabIndex = 18;
            this.ucSwitch1.Texts = new string[0];
            this.ucSwitch1.TrueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucSwitch1.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch6
            // 
            this.ucSwitch6.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch6.Checked = false;
            this.ucSwitch6.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch6.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch6.Location = new System.Drawing.Point(136, 71);
            this.ucSwitch6.Name = "ucSwitch6";
            this.ucSwitch6.Size = new System.Drawing.Size(86, 34);
            this.ucSwitch6.SwitchType = HZH_Controls.Controls.SwitchType.Quadrilateral;
            this.ucSwitch6.TabIndex = 11;
            this.ucSwitch6.Texts = new string[0];
            this.ucSwitch6.TrueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucSwitch6.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch2
            // 
            this.ucSwitch2.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch2.Checked = false;
            this.ucSwitch2.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch2.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch2.Location = new System.Drawing.Point(136, 224);
            this.ucSwitch2.Name = "ucSwitch2";
            this.ucSwitch2.Size = new System.Drawing.Size(86, 34);
            this.ucSwitch2.SwitchType = HZH_Controls.Controls.SwitchType.Line;
            this.ucSwitch2.TabIndex = 17;
            this.ucSwitch2.Texts = new string[0];
            this.ucSwitch2.TrueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucSwitch2.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch8
            // 
            this.ucSwitch8.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch8.Checked = false;
            this.ucSwitch8.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch8.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch8.Location = new System.Drawing.Point(22, 173);
            this.ucSwitch8.Name = "ucSwitch8";
            this.ucSwitch8.Size = new System.Drawing.Size(86, 34);
            this.ucSwitch8.SwitchType = HZH_Controls.Controls.SwitchType.Ellipse;
            this.ucSwitch8.TabIndex = 12;
            this.ucSwitch8.Texts = new string[] {
        "确定",
        "取消"};
            this.ucSwitch8.TrueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucSwitch8.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch3
            // 
            this.ucSwitch3.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch3.Checked = true;
            this.ucSwitch3.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch3.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch3.Location = new System.Drawing.Point(22, 20);
            this.ucSwitch3.Name = "ucSwitch3";
            this.ucSwitch3.Size = new System.Drawing.Size(86, 34);
            this.ucSwitch3.SwitchType = HZH_Controls.Controls.SwitchType.Ellipse;
            this.ucSwitch3.TabIndex = 16;
            this.ucSwitch3.Texts = new string[0];
            this.ucSwitch3.TrueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucSwitch3.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch4
            // 
            this.ucSwitch4.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch4.Checked = false;
            this.ucSwitch4.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch4.FalseTextColr = System.Drawing.Color.White;
            this.ucSwitch4.Location = new System.Drawing.Point(22, 71);
            this.ucSwitch4.Name = "ucSwitch4";
            this.ucSwitch4.Size = new System.Drawing.Size(86, 34);
            this.ucSwitch4.SwitchType = HZH_Controls.Controls.SwitchType.Ellipse;
            this.ucSwitch4.TabIndex = 15;
            this.ucSwitch4.Texts = new string[0];
            this.ucSwitch4.TrueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucSwitch4.TrueTextColr = System.Drawing.Color.White;
            // 
            // ucSwitch7
            // 
            this.ucSwitch7.BackColor = System.Drawing.Color.Transparent;
            this.ucSwitch7.Checked = true;
            this.ucSwitch7.FalseColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
            this.ucSwitch7.FalseTextColr = System.Drawing.Color.Green;
            this.ucSwitch7.Location = new System.Drawing.Point(22, 122);
            this.ucSwitch7.Name = "ucSwitch7";
            this.ucSwitch7.Size = new System.Drawing.Size(86, 34);
            this.ucSwitch7.SwitchType = HZH_Controls.Controls.SwitchType.Ellipse;
            this.ucSwitch7.TabIndex = 14;
            this.ucSwitch7.Texts = new string[] {
        "确定",
        "取消"};
            this.ucSwitch7.TrueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucSwitch7.TrueTextColr = System.Drawing.Color.Black;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ucNumTextBox2);
            this.groupBox2.Controls.Add(this.ucNumTextBox1);
            this.groupBox2.Location = new System.Drawing.Point(383, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(238, 165);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "下拉列表";
            // 
            // ucNumTextBox2
            // 
            this.ucNumTextBox2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.ucNumTextBox2.InputType = HZH_Controls.TextInputType.Number;
            this.ucNumTextBox2.IsNumCanInput = true;
            this.ucNumTextBox2.KeyBoardType = HZH_Controls.Controls.KeyBoardType.UCKeyBorderNum;
            this.ucNumTextBox2.Location = new System.Drawing.Point(40, 90);
            this.ucNumTextBox2.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.ucNumTextBox2.MinValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.ucNumTextBox2.Name = "ucNumTextBox2";
            this.ucNumTextBox2.Num = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.ucNumTextBox2.Padding = new System.Windows.Forms.Padding(2);
            this.ucNumTextBox2.Size = new System.Drawing.Size(152, 44);
            this.ucNumTextBox2.TabIndex = 1;
            // 
            // ucNumTextBox1
            // 
            this.ucNumTextBox1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ucNumTextBox1.InputType = HZH_Controls.TextInputType.Number;
            this.ucNumTextBox1.IsNumCanInput = true;
            this.ucNumTextBox1.KeyBoardType = HZH_Controls.Controls.KeyBoardType.UCKeyBorderNum;
            this.ucNumTextBox1.Location = new System.Drawing.Point(40, 30);
            this.ucNumTextBox1.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.ucNumTextBox1.MinValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.ucNumTextBox1.Name = "ucNumTextBox1";
            this.ucNumTextBox1.Num = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ucNumTextBox1.Padding = new System.Windows.Forms.Padding(2);
            this.ucNumTextBox1.Size = new System.Drawing.Size(152, 44);
            this.ucNumTextBox1.TabIndex = 1;
            // 
            // ucDatePickerExt21
            // 
            this.ucDatePickerExt21.BackColor = System.Drawing.Color.Transparent;
            this.ucDatePickerExt21.ConerRadius = 5;
            this.ucDatePickerExt21.CurrentTime = new System.DateTime(2020, 7, 11, 11, 46, 51, 0);
            this.ucDatePickerExt21.FillColor = System.Drawing.Color.White;
            this.ucDatePickerExt21.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucDatePickerExt21.IsRadius = true;
            this.ucDatePickerExt21.IsShowRect = true;
            this.ucDatePickerExt21.Location = new System.Drawing.Point(6, 111);
            this.ucDatePickerExt21.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucDatePickerExt21.Name = "ucDatePickerExt21";
            this.ucDatePickerExt21.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucDatePickerExt21.RectWidth = 1;
            this.ucDatePickerExt21.SelectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucDatePickerExt21.Size = new System.Drawing.Size(336, 39);
            this.ucDatePickerExt21.TabIndex = 1;
            this.ucDatePickerExt21.TimeFontSize = 20;
            this.ucDatePickerExt21.TimeType = HZH_Controls.Controls.DateTimePickerType.DateTime;
            // 
            // UCTestForms
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Name = "UCTestForms";
            this.Size = new System.Drawing.Size(645, 711);
            this.Load += new System.EventHandler(this.UCForms_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private HZH_Controls.Controls.UCTextBoxEx ucTextBoxEx4;
        private HZH_Controls.Controls.UCTextBoxEx ucTextBoxEx3;
        private HZH_Controls.Controls.UCTextBoxEx ucTextBoxEx2;
        private HZH_Controls.Controls.UCTextBoxEx ucTextBoxEx1;
        private HZH_Controls.Controls.UCNumTextBox ucNumTextBox1;
        private HZH_Controls.Controls.TextBoxTransparent textBoxTransparent1;
        private System.Windows.Forms.GroupBox groupBox3;
        private HZH_Controls.Controls.UCCheckBox ucCheckBox4;
        private HZH_Controls.Controls.UCCheckBox ucCheckBox3;
        private HZH_Controls.Controls.UCCheckBox ucCheckBox2;
        private HZH_Controls.Controls.UCCheckBox ucCheckBox1;
        private HZH_Controls.Controls.UCRadioButton ucRadioButton4;
        private HZH_Controls.Controls.UCRadioButton ucRadioButton3;
        private HZH_Controls.Controls.UCRadioButton ucRadioButton2;
        private HZH_Controls.Controls.UCRadioButton ucRadioButton1;
        private System.Windows.Forms.GroupBox groupBox6;
        private HZH_Controls.Controls.UCCombox ucComboBox2;
        private HZH_Controls.Controls.UCCombox ucComboBox1;
        private HZH_Controls.Controls.UCComboxGrid ucComboxGrid1;
        private System.Windows.Forms.GroupBox groupBox7;
        private HZH_Controls.Controls.UCDatePickerExt ucDatePickerExt3;
        private HZH_Controls.Controls.UCDatePickerExt ucDatePickerExt2;
        private HZH_Controls.Controls.UCDatePickerExt ucDatePickerExt1;
        private HZH_Controls.Controls.UCSwitch ucSwitch10;
        private HZH_Controls.Controls.UCSwitch ucSwitch9;
        private HZH_Controls.Controls.UCSwitch ucSwitch6;
        private HZH_Controls.Controls.UCSwitch ucSwitch8;
        private HZH_Controls.Controls.UCSwitch ucSwitch5;
        private HZH_Controls.Controls.UCSwitch ucSwitch7;
        private HZH_Controls.Controls.UCSwitch ucSwitch4;
        private HZH_Controls.Controls.UCSwitch ucSwitch3;
        private HZH_Controls.Controls.UCSwitch ucSwitch2;
        private HZH_Controls.Controls.UCSwitch ucSwitch1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private HZH_Controls.Controls.UCNumTextBox ucNumTextBox2;
        private HZH_Controls.Controls.UCDatePickerExt2 ucDatePickerExt21;
    }
}

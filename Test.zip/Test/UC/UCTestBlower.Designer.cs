﻿namespace Test.UC
{
    partial class UCTestBlower
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucBlower30 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower15 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower29 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower10 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower28 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower14 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower27 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower6 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower26 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower9 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower25 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower13 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower24 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower5 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower23 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower12 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower22 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower8 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower21 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower7 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower20 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower11 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower19 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower3 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower18 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower4 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower17 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower2 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower16 = new HZH_Controls.Controls.UCBlower();
            this.ucBlower1 = new HZH_Controls.Controls.UCBlower();
            this.SuspendLayout();
            // 
            // ucBlower30
            // 
            this.ucBlower30.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower30.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower30.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Up;
            this.ucBlower30.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower30.Location = new System.Drawing.Point(684, 689);
            this.ucBlower30.Name = "ucBlower30";
            this.ucBlower30.Size = new System.Drawing.Size(164, 162);
            this.ucBlower30.TabIndex = 25;
            this.ucBlower30.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower30.TurnSpeed = 100;
            // 
            // ucBlower15
            // 
            this.ucBlower15.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower15.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Up;
            this.ucBlower15.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Up;
            this.ucBlower15.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower15.Location = new System.Drawing.Point(684, 264);
            this.ucBlower15.Name = "ucBlower15";
            this.ucBlower15.Size = new System.Drawing.Size(164, 162);
            this.ucBlower15.TabIndex = 25;
            this.ucBlower15.TurnAround = HZH_Controls.Controls.TurnAround.Counterclockwise;
            this.ucBlower15.TurnSpeed = 100;
            // 
            // ucBlower29
            // 
            this.ucBlower29.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower29.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower29.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Up;
            this.ucBlower29.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower29.Location = new System.Drawing.Point(495, 550);
            this.ucBlower29.Name = "ucBlower29";
            this.ucBlower29.Size = new System.Drawing.Size(116, 119);
            this.ucBlower29.TabIndex = 25;
            this.ucBlower29.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower29.TurnSpeed = 100;
            // 
            // ucBlower10
            // 
            this.ucBlower10.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower10.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Up;
            this.ucBlower10.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Up;
            this.ucBlower10.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower10.Location = new System.Drawing.Point(495, 125);
            this.ucBlower10.Name = "ucBlower10";
            this.ucBlower10.Size = new System.Drawing.Size(116, 119);
            this.ucBlower10.TabIndex = 25;
            this.ucBlower10.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower10.TurnSpeed = 100;
            // 
            // ucBlower28
            // 
            this.ucBlower28.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower28.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower28.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Right;
            this.ucBlower28.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower28.Location = new System.Drawing.Point(520, 689);
            this.ucBlower28.Name = "ucBlower28";
            this.ucBlower28.Size = new System.Drawing.Size(164, 162);
            this.ucBlower28.TabIndex = 26;
            this.ucBlower28.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower28.TurnSpeed = 100;
            // 
            // ucBlower14
            // 
            this.ucBlower14.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower14.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Right;
            this.ucBlower14.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Right;
            this.ucBlower14.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower14.Location = new System.Drawing.Point(520, 264);
            this.ucBlower14.Name = "ucBlower14";
            this.ucBlower14.Size = new System.Drawing.Size(164, 162);
            this.ucBlower14.TabIndex = 26;
            this.ucBlower14.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower14.TurnSpeed = 100;
            // 
            // ucBlower27
            // 
            this.ucBlower27.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower27.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower27.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Up;
            this.ucBlower27.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower27.Location = new System.Drawing.Point(367, 443);
            this.ucBlower27.Name = "ucBlower27";
            this.ucBlower27.Size = new System.Drawing.Size(78, 89);
            this.ucBlower27.TabIndex = 25;
            this.ucBlower27.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower27.TurnSpeed = 100;
            // 
            // ucBlower6
            // 
            this.ucBlower6.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower6.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Up;
            this.ucBlower6.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Up;
            this.ucBlower6.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower6.Location = new System.Drawing.Point(367, 18);
            this.ucBlower6.Name = "ucBlower6";
            this.ucBlower6.Size = new System.Drawing.Size(78, 89);
            this.ucBlower6.TabIndex = 25;
            this.ucBlower6.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower6.TurnSpeed = 100;
            // 
            // ucBlower26
            // 
            this.ucBlower26.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower26.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower26.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Right;
            this.ucBlower26.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower26.Location = new System.Drawing.Point(379, 550);
            this.ucBlower26.Name = "ucBlower26";
            this.ucBlower26.Size = new System.Drawing.Size(116, 119);
            this.ucBlower26.TabIndex = 26;
            this.ucBlower26.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower26.TurnSpeed = 100;
            // 
            // ucBlower9
            // 
            this.ucBlower9.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower9.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Right;
            this.ucBlower9.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Right;
            this.ucBlower9.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower9.Location = new System.Drawing.Point(379, 125);
            this.ucBlower9.Name = "ucBlower9";
            this.ucBlower9.Size = new System.Drawing.Size(116, 119);
            this.ucBlower9.TabIndex = 26;
            this.ucBlower9.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower9.TurnSpeed = 100;
            // 
            // ucBlower25
            // 
            this.ucBlower25.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower25.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower25.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Up;
            this.ucBlower25.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower25.Location = new System.Drawing.Point(357, 688);
            this.ucBlower25.Name = "ucBlower25";
            this.ucBlower25.Size = new System.Drawing.Size(164, 162);
            this.ucBlower25.TabIndex = 27;
            this.ucBlower25.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower25.TurnSpeed = 100;
            // 
            // ucBlower13
            // 
            this.ucBlower13.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower13.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Left;
            this.ucBlower13.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Up;
            this.ucBlower13.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower13.Location = new System.Drawing.Point(357, 263);
            this.ucBlower13.Name = "ucBlower13";
            this.ucBlower13.Size = new System.Drawing.Size(164, 162);
            this.ucBlower13.TabIndex = 27;
            this.ucBlower13.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower13.TurnSpeed = 100;
            // 
            // ucBlower24
            // 
            this.ucBlower24.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower24.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower24.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Right;
            this.ucBlower24.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower24.Location = new System.Drawing.Point(283, 443);
            this.ucBlower24.Name = "ucBlower24";
            this.ucBlower24.Size = new System.Drawing.Size(78, 89);
            this.ucBlower24.TabIndex = 26;
            this.ucBlower24.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower24.TurnSpeed = 100;
            // 
            // ucBlower5
            // 
            this.ucBlower5.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower5.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Right;
            this.ucBlower5.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Right;
            this.ucBlower5.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower5.Location = new System.Drawing.Point(283, 18);
            this.ucBlower5.Name = "ucBlower5";
            this.ucBlower5.Size = new System.Drawing.Size(78, 89);
            this.ucBlower5.TabIndex = 26;
            this.ucBlower5.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower5.TurnSpeed = 100;
            // 
            // ucBlower23
            // 
            this.ucBlower23.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower23.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower23.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Right;
            this.ucBlower23.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower23.Location = new System.Drawing.Point(184, 689);
            this.ucBlower23.Name = "ucBlower23";
            this.ucBlower23.Size = new System.Drawing.Size(164, 162);
            this.ucBlower23.TabIndex = 28;
            this.ucBlower23.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower23.TurnSpeed = 100;
            // 
            // ucBlower12
            // 
            this.ucBlower12.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower12.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Left;
            this.ucBlower12.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Right;
            this.ucBlower12.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower12.Location = new System.Drawing.Point(184, 264);
            this.ucBlower12.Name = "ucBlower12";
            this.ucBlower12.Size = new System.Drawing.Size(164, 162);
            this.ucBlower12.TabIndex = 28;
            this.ucBlower12.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower12.TurnSpeed = 100;
            // 
            // ucBlower22
            // 
            this.ucBlower22.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower22.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower22.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Up;
            this.ucBlower22.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower22.Location = new System.Drawing.Point(264, 549);
            this.ucBlower22.Name = "ucBlower22";
            this.ucBlower22.Size = new System.Drawing.Size(116, 119);
            this.ucBlower22.TabIndex = 27;
            this.ucBlower22.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower22.TurnSpeed = 100;
            // 
            // ucBlower8
            // 
            this.ucBlower8.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower8.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Left;
            this.ucBlower8.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Up;
            this.ucBlower8.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower8.Location = new System.Drawing.Point(264, 124);
            this.ucBlower8.Name = "ucBlower8";
            this.ucBlower8.Size = new System.Drawing.Size(116, 119);
            this.ucBlower8.TabIndex = 27;
            this.ucBlower8.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower8.TurnSpeed = 100;
            // 
            // ucBlower21
            // 
            this.ucBlower21.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower21.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower21.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Right;
            this.ucBlower21.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower21.Location = new System.Drawing.Point(139, 550);
            this.ucBlower21.Name = "ucBlower21";
            this.ucBlower21.Size = new System.Drawing.Size(116, 119);
            this.ucBlower21.TabIndex = 28;
            this.ucBlower21.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower21.TurnSpeed = 100;
            // 
            // ucBlower7
            // 
            this.ucBlower7.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower7.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Left;
            this.ucBlower7.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Right;
            this.ucBlower7.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower7.Location = new System.Drawing.Point(139, 125);
            this.ucBlower7.Name = "ucBlower7";
            this.ucBlower7.Size = new System.Drawing.Size(116, 119);
            this.ucBlower7.TabIndex = 28;
            this.ucBlower7.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower7.TurnSpeed = 100;
            // 
            // ucBlower20
            // 
            this.ucBlower20.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower20.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower20.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Left;
            this.ucBlower20.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower20.Location = new System.Drawing.Point(20, 688);
            this.ucBlower20.Name = "ucBlower20";
            this.ucBlower20.Size = new System.Drawing.Size(164, 162);
            this.ucBlower20.TabIndex = 29;
            this.ucBlower20.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower20.TurnSpeed = 100;
            // 
            // ucBlower11
            // 
            this.ucBlower11.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower11.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Left;
            this.ucBlower11.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Left;
            this.ucBlower11.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower11.Location = new System.Drawing.Point(20, 263);
            this.ucBlower11.Name = "ucBlower11";
            this.ucBlower11.Size = new System.Drawing.Size(164, 162);
            this.ucBlower11.TabIndex = 29;
            this.ucBlower11.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower11.TurnSpeed = 100;
            // 
            // ucBlower19
            // 
            this.ucBlower19.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower19.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower19.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Up;
            this.ucBlower19.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower19.Location = new System.Drawing.Point(200, 442);
            this.ucBlower19.Name = "ucBlower19";
            this.ucBlower19.Size = new System.Drawing.Size(78, 89);
            this.ucBlower19.TabIndex = 27;
            this.ucBlower19.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower19.TurnSpeed = 100;
            // 
            // ucBlower3
            // 
            this.ucBlower3.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower3.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Left;
            this.ucBlower3.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Up;
            this.ucBlower3.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower3.Location = new System.Drawing.Point(200, 17);
            this.ucBlower3.Name = "ucBlower3";
            this.ucBlower3.Size = new System.Drawing.Size(78, 89);
            this.ucBlower3.TabIndex = 27;
            this.ucBlower3.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower3.TurnSpeed = 100;
            // 
            // ucBlower18
            // 
            this.ucBlower18.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower18.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower18.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Left;
            this.ucBlower18.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower18.Location = new System.Drawing.Point(23, 549);
            this.ucBlower18.Name = "ucBlower18";
            this.ucBlower18.Size = new System.Drawing.Size(116, 119);
            this.ucBlower18.TabIndex = 29;
            this.ucBlower18.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower18.TurnSpeed = 100;
            // 
            // ucBlower4
            // 
            this.ucBlower4.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower4.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Left;
            this.ucBlower4.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Left;
            this.ucBlower4.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower4.Location = new System.Drawing.Point(23, 124);
            this.ucBlower4.Name = "ucBlower4";
            this.ucBlower4.Size = new System.Drawing.Size(116, 119);
            this.ucBlower4.TabIndex = 29;
            this.ucBlower4.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower4.TurnSpeed = 100;
            // 
            // ucBlower17
            // 
            this.ucBlower17.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower17.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower17.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Right;
            this.ucBlower17.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower17.Location = new System.Drawing.Point(107, 443);
            this.ucBlower17.Name = "ucBlower17";
            this.ucBlower17.Size = new System.Drawing.Size(78, 89);
            this.ucBlower17.TabIndex = 28;
            this.ucBlower17.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower17.TurnSpeed = 100;
            // 
            // ucBlower2
            // 
            this.ucBlower2.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower2.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Left;
            this.ucBlower2.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Right;
            this.ucBlower2.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower2.Location = new System.Drawing.Point(107, 18);
            this.ucBlower2.Name = "ucBlower2";
            this.ucBlower2.Size = new System.Drawing.Size(78, 89);
            this.ucBlower2.TabIndex = 28;
            this.ucBlower2.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower2.TurnSpeed = 100;
            // 
            // ucBlower16
            // 
            this.ucBlower16.BlowerColor = System.Drawing.Color.DarkGray;
            this.ucBlower16.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.None;
            this.ucBlower16.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Left;
            this.ucBlower16.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucBlower16.Location = new System.Drawing.Point(23, 442);
            this.ucBlower16.Name = "ucBlower16";
            this.ucBlower16.Size = new System.Drawing.Size(78, 89);
            this.ucBlower16.TabIndex = 29;
            this.ucBlower16.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower16.TurnSpeed = 100;
            // 
            // ucBlower1
            // 
            this.ucBlower1.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower1.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Left;
            this.ucBlower1.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Left;
            this.ucBlower1.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower1.Location = new System.Drawing.Point(23, 17);
            this.ucBlower1.Name = "ucBlower1";
            this.ucBlower1.Size = new System.Drawing.Size(78, 89);
            this.ucBlower1.TabIndex = 29;
            this.ucBlower1.TurnAround = HZH_Controls.Controls.TurnAround.None;
            this.ucBlower1.TurnSpeed = 100;
            // 
            // UCTestBlower
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucBlower30);
            this.Controls.Add(this.ucBlower15);
            this.Controls.Add(this.ucBlower29);
            this.Controls.Add(this.ucBlower10);
            this.Controls.Add(this.ucBlower28);
            this.Controls.Add(this.ucBlower14);
            this.Controls.Add(this.ucBlower27);
            this.Controls.Add(this.ucBlower6);
            this.Controls.Add(this.ucBlower26);
            this.Controls.Add(this.ucBlower9);
            this.Controls.Add(this.ucBlower25);
            this.Controls.Add(this.ucBlower13);
            this.Controls.Add(this.ucBlower24);
            this.Controls.Add(this.ucBlower5);
            this.Controls.Add(this.ucBlower23);
            this.Controls.Add(this.ucBlower12);
            this.Controls.Add(this.ucBlower22);
            this.Controls.Add(this.ucBlower8);
            this.Controls.Add(this.ucBlower21);
            this.Controls.Add(this.ucBlower7);
            this.Controls.Add(this.ucBlower20);
            this.Controls.Add(this.ucBlower11);
            this.Controls.Add(this.ucBlower19);
            this.Controls.Add(this.ucBlower3);
            this.Controls.Add(this.ucBlower18);
            this.Controls.Add(this.ucBlower4);
            this.Controls.Add(this.ucBlower17);
            this.Controls.Add(this.ucBlower2);
            this.Controls.Add(this.ucBlower16);
            this.Controls.Add(this.ucBlower1);
            this.Name = "UCTestBlower";
            this.Size = new System.Drawing.Size(938, 870);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCBlower ucBlower6;
        private HZH_Controls.Controls.UCBlower ucBlower5;
        private HZH_Controls.Controls.UCBlower ucBlower3;
        private HZH_Controls.Controls.UCBlower ucBlower2;
        private HZH_Controls.Controls.UCBlower ucBlower1;
        private HZH_Controls.Controls.UCBlower ucBlower4;
        private HZH_Controls.Controls.UCBlower ucBlower7;
        private HZH_Controls.Controls.UCBlower ucBlower8;
        private HZH_Controls.Controls.UCBlower ucBlower9;
        private HZH_Controls.Controls.UCBlower ucBlower10;
        private HZH_Controls.Controls.UCBlower ucBlower11;
        private HZH_Controls.Controls.UCBlower ucBlower12;
        private HZH_Controls.Controls.UCBlower ucBlower13;
        private HZH_Controls.Controls.UCBlower ucBlower14;
        private HZH_Controls.Controls.UCBlower ucBlower15;
        private HZH_Controls.Controls.UCBlower ucBlower16;
        private HZH_Controls.Controls.UCBlower ucBlower17;
        private HZH_Controls.Controls.UCBlower ucBlower18;
        private HZH_Controls.Controls.UCBlower ucBlower19;
        private HZH_Controls.Controls.UCBlower ucBlower20;
        private HZH_Controls.Controls.UCBlower ucBlower21;
        private HZH_Controls.Controls.UCBlower ucBlower22;
        private HZH_Controls.Controls.UCBlower ucBlower23;
        private HZH_Controls.Controls.UCBlower ucBlower24;
        private HZH_Controls.Controls.UCBlower ucBlower25;
        private HZH_Controls.Controls.UCBlower ucBlower26;
        private HZH_Controls.Controls.UCBlower ucBlower27;
        private HZH_Controls.Controls.UCBlower ucBlower28;
        private HZH_Controls.Controls.UCBlower ucBlower29;
        private HZH_Controls.Controls.UCBlower ucBlower30;
    }
}

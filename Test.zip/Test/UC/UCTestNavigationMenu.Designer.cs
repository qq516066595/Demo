﻿namespace Test.UC
{
    partial class UCTestNavigationMenu
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem1 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem2 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem3 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem4 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem5 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem6 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem7 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem8 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem9 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem10 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem11 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem12 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem13 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem14 = new HZH_Controls.Controls.NavigationMenuItem();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCTestNavigationMenu));
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem15 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem16 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem17 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem18 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem19 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem20 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem21 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem22 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem23 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem24 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem25 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem26 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem27 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem28 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem29 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem30 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem31 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem32 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem33 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem34 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem35 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem36 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem37 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem38 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem39 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem40 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem41 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem42 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem43 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem44 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem45 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem46 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem47 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem48 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem49 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem50 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem51 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem52 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem53 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem54 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem55 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem56 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem57 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem58 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem59 = new HZH_Controls.Controls.NavigationMenuItem();
            HZH_Controls.Controls.NavigationMenuItem navigationMenuItem60 = new HZH_Controls.Controls.NavigationMenuItem();
            this.ucNavigationMenu3 = new HZH_Controls.Controls.UCNavigationMenu();
            this.ucNavigationMenu2 = new HZH_Controls.Controls.UCNavigationMenu();
            this.ucNavigationMenu1 = new HZH_Controls.Controls.UCNavigationMenu();
            this.ucNavigationMenu4 = new HZH_Controls.Controls.UCNavigationMenu();
            this.SuspendLayout();
            // 
            // ucNavigationMenu3
            // 
            this.ucNavigationMenu3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucNavigationMenu3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucNavigationMenu3.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucNavigationMenu3.ForeColor = System.Drawing.Color.White;
            navigationMenuItem1.AnchorRight = false;
            navigationMenuItem1.DataSource = null;
            navigationMenuItem1.HasSplitLintAtTop = false;
            navigationMenuItem1.Icon = null;
            navigationMenuItem2.AnchorRight = false;
            navigationMenuItem2.DataSource = null;
            navigationMenuItem2.HasSplitLintAtTop = false;
            navigationMenuItem2.Icon = null;
            navigationMenuItem3.AnchorRight = false;
            navigationMenuItem3.DataSource = null;
            navigationMenuItem3.HasSplitLintAtTop = false;
            navigationMenuItem3.Icon = null;
            navigationMenuItem3.Items = null;
            navigationMenuItem3.ItemWidth = 100;
            navigationMenuItem3.ShowTip = false;
            navigationMenuItem3.Text = "1";
            navigationMenuItem3.TipText = null;
            navigationMenuItem4.AnchorRight = false;
            navigationMenuItem4.DataSource = null;
            navigationMenuItem4.HasSplitLintAtTop = false;
            navigationMenuItem4.Icon = null;
            navigationMenuItem5.AnchorRight = false;
            navigationMenuItem5.DataSource = null;
            navigationMenuItem5.HasSplitLintAtTop = false;
            navigationMenuItem5.Icon = null;
            navigationMenuItem5.Items = null;
            navigationMenuItem5.ItemWidth = 100;
            navigationMenuItem5.ShowTip = false;
            navigationMenuItem5.Text = "1";
            navigationMenuItem5.TipText = null;
            navigationMenuItem6.AnchorRight = false;
            navigationMenuItem6.DataSource = null;
            navigationMenuItem6.HasSplitLintAtTop = false;
            navigationMenuItem6.Icon = null;
            navigationMenuItem6.Items = null;
            navigationMenuItem6.ItemWidth = 100;
            navigationMenuItem6.ShowTip = false;
            navigationMenuItem6.Text = "2";
            navigationMenuItem6.TipText = null;
            navigationMenuItem7.AnchorRight = false;
            navigationMenuItem7.DataSource = null;
            navigationMenuItem7.HasSplitLintAtTop = false;
            navigationMenuItem7.Icon = null;
            navigationMenuItem7.Items = null;
            navigationMenuItem7.ItemWidth = 100;
            navigationMenuItem7.ShowTip = false;
            navigationMenuItem7.Text = "3";
            navigationMenuItem7.TipText = null;
            navigationMenuItem4.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem5,
        navigationMenuItem6,
        navigationMenuItem7};
            navigationMenuItem4.ItemWidth = 100;
            navigationMenuItem4.ShowTip = false;
            navigationMenuItem4.Text = "2";
            navigationMenuItem4.TipText = null;
            navigationMenuItem8.AnchorRight = false;
            navigationMenuItem8.DataSource = null;
            navigationMenuItem8.HasSplitLintAtTop = false;
            navigationMenuItem8.Icon = null;
            navigationMenuItem8.Items = null;
            navigationMenuItem8.ItemWidth = 100;
            navigationMenuItem8.ShowTip = false;
            navigationMenuItem8.Text = "3";
            navigationMenuItem8.TipText = null;
            navigationMenuItem2.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem3,
        navigationMenuItem4,
        navigationMenuItem8};
            navigationMenuItem2.ItemWidth = 100;
            navigationMenuItem2.ShowTip = false;
            navigationMenuItem2.Text = "子菜单1";
            navigationMenuItem2.TipText = null;
            navigationMenuItem9.AnchorRight = false;
            navigationMenuItem9.DataSource = null;
            navigationMenuItem9.HasSplitLintAtTop = false;
            navigationMenuItem9.Icon = null;
            navigationMenuItem9.Items = null;
            navigationMenuItem9.ItemWidth = 100;
            navigationMenuItem9.ShowTip = false;
            navigationMenuItem9.Text = "子菜单2";
            navigationMenuItem9.TipText = null;
            navigationMenuItem10.AnchorRight = false;
            navigationMenuItem10.DataSource = null;
            navigationMenuItem10.HasSplitLintAtTop = true;
            navigationMenuItem10.Icon = null;
            navigationMenuItem10.Items = null;
            navigationMenuItem10.ItemWidth = 100;
            navigationMenuItem10.ShowTip = false;
            navigationMenuItem10.Text = "子菜单3";
            navigationMenuItem10.TipText = null;
            navigationMenuItem1.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem2,
        navigationMenuItem9,
        navigationMenuItem10};
            navigationMenuItem1.ItemWidth = 100;
            navigationMenuItem1.ShowTip = true;
            navigationMenuItem1.Text = "菜单1";
            navigationMenuItem1.TipText = null;
            navigationMenuItem11.AnchorRight = false;
            navigationMenuItem11.DataSource = null;
            navigationMenuItem11.HasSplitLintAtTop = false;
            navigationMenuItem11.Icon = null;
            navigationMenuItem12.AnchorRight = false;
            navigationMenuItem12.DataSource = null;
            navigationMenuItem12.HasSplitLintAtTop = false;
            navigationMenuItem12.Icon = null;
            navigationMenuItem12.Items = null;
            navigationMenuItem12.ItemWidth = 100;
            navigationMenuItem12.ShowTip = false;
            navigationMenuItem12.Text = "1";
            navigationMenuItem12.TipText = null;
            navigationMenuItem13.AnchorRight = false;
            navigationMenuItem13.DataSource = null;
            navigationMenuItem13.HasSplitLintAtTop = false;
            navigationMenuItem13.Icon = null;
            navigationMenuItem13.Items = null;
            navigationMenuItem13.ItemWidth = 100;
            navigationMenuItem13.ShowTip = false;
            navigationMenuItem13.Text = "2";
            navigationMenuItem13.TipText = null;
            navigationMenuItem11.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem12,
        navigationMenuItem13};
            navigationMenuItem11.ItemWidth = 100;
            navigationMenuItem11.ShowTip = true;
            navigationMenuItem11.Text = "菜单2";
            navigationMenuItem11.TipText = "4";
            navigationMenuItem14.AnchorRight = true;
            navigationMenuItem14.DataSource = null;
            navigationMenuItem14.HasSplitLintAtTop = false;
            navigationMenuItem14.Icon = ((System.Drawing.Image)(resources.GetObject("navigationMenuItem14.Icon")));
            navigationMenuItem14.Items = null;
            navigationMenuItem14.ItemWidth = 100;
            navigationMenuItem14.ShowTip = false;
            navigationMenuItem14.Text = "菜单3";
            navigationMenuItem14.TipText = null;
            navigationMenuItem15.AnchorRight = true;
            navigationMenuItem15.DataSource = null;
            navigationMenuItem15.HasSplitLintAtTop = false;
            navigationMenuItem15.Icon = null;
            navigationMenuItem15.Items = null;
            navigationMenuItem15.ItemWidth = 100;
            navigationMenuItem15.ShowTip = false;
            navigationMenuItem15.Text = "菜单4";
            navigationMenuItem15.TipText = null;
            this.ucNavigationMenu3.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem1,
        navigationMenuItem11,
        navigationMenuItem14,
        navigationMenuItem15};
            this.ucNavigationMenu3.Location = new System.Drawing.Point(0, 231);
            this.ucNavigationMenu3.Name = "ucNavigationMenu3";
            this.ucNavigationMenu3.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.ucNavigationMenu3.Size = new System.Drawing.Size(893, 60);
            this.ucNavigationMenu3.TabIndex = 0;
            this.ucNavigationMenu3.TipColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucNavigationMenu3.ClickItemed += new System.EventHandler(this.ucNavigationMenu1_ClickItemed);
            // 
            // ucNavigationMenu2
            // 
            this.ucNavigationMenu2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucNavigationMenu2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucNavigationMenu2.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucNavigationMenu2.ForeColor = System.Drawing.Color.White;
            navigationMenuItem16.AnchorRight = false;
            navigationMenuItem16.DataSource = null;
            navigationMenuItem16.HasSplitLintAtTop = false;
            navigationMenuItem16.Icon = null;
            navigationMenuItem17.AnchorRight = false;
            navigationMenuItem17.DataSource = null;
            navigationMenuItem17.HasSplitLintAtTop = false;
            navigationMenuItem17.Icon = null;
            navigationMenuItem18.AnchorRight = false;
            navigationMenuItem18.DataSource = null;
            navigationMenuItem18.HasSplitLintAtTop = false;
            navigationMenuItem18.Icon = null;
            navigationMenuItem18.Items = null;
            navigationMenuItem18.ItemWidth = 100;
            navigationMenuItem18.ShowTip = false;
            navigationMenuItem18.Text = "1";
            navigationMenuItem18.TipText = null;
            navigationMenuItem19.AnchorRight = false;
            navigationMenuItem19.DataSource = null;
            navigationMenuItem19.HasSplitLintAtTop = false;
            navigationMenuItem19.Icon = null;
            navigationMenuItem20.AnchorRight = false;
            navigationMenuItem20.DataSource = null;
            navigationMenuItem20.HasSplitLintAtTop = false;
            navigationMenuItem20.Icon = null;
            navigationMenuItem20.Items = null;
            navigationMenuItem20.ItemWidth = 100;
            navigationMenuItem20.ShowTip = false;
            navigationMenuItem20.Text = "1";
            navigationMenuItem20.TipText = null;
            navigationMenuItem21.AnchorRight = false;
            navigationMenuItem21.DataSource = null;
            navigationMenuItem21.HasSplitLintAtTop = false;
            navigationMenuItem21.Icon = null;
            navigationMenuItem21.Items = null;
            navigationMenuItem21.ItemWidth = 100;
            navigationMenuItem21.ShowTip = false;
            navigationMenuItem21.Text = "2";
            navigationMenuItem21.TipText = null;
            navigationMenuItem22.AnchorRight = false;
            navigationMenuItem22.DataSource = null;
            navigationMenuItem22.HasSplitLintAtTop = false;
            navigationMenuItem22.Icon = null;
            navigationMenuItem22.Items = null;
            navigationMenuItem22.ItemWidth = 100;
            navigationMenuItem22.ShowTip = false;
            navigationMenuItem22.Text = "3";
            navigationMenuItem22.TipText = null;
            navigationMenuItem19.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem20,
        navigationMenuItem21,
        navigationMenuItem22};
            navigationMenuItem19.ItemWidth = 100;
            navigationMenuItem19.ShowTip = false;
            navigationMenuItem19.Text = "2";
            navigationMenuItem19.TipText = null;
            navigationMenuItem23.AnchorRight = false;
            navigationMenuItem23.DataSource = null;
            navigationMenuItem23.HasSplitLintAtTop = false;
            navigationMenuItem23.Icon = null;
            navigationMenuItem23.Items = null;
            navigationMenuItem23.ItemWidth = 100;
            navigationMenuItem23.ShowTip = false;
            navigationMenuItem23.Text = "3";
            navigationMenuItem23.TipText = null;
            navigationMenuItem17.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem18,
        navigationMenuItem19,
        navigationMenuItem23};
            navigationMenuItem17.ItemWidth = 100;
            navigationMenuItem17.ShowTip = false;
            navigationMenuItem17.Text = "子菜单1";
            navigationMenuItem17.TipText = null;
            navigationMenuItem24.AnchorRight = false;
            navigationMenuItem24.DataSource = null;
            navigationMenuItem24.HasSplitLintAtTop = false;
            navigationMenuItem24.Icon = null;
            navigationMenuItem24.Items = null;
            navigationMenuItem24.ItemWidth = 100;
            navigationMenuItem24.ShowTip = false;
            navigationMenuItem24.Text = "子菜单2";
            navigationMenuItem24.TipText = null;
            navigationMenuItem25.AnchorRight = false;
            navigationMenuItem25.DataSource = null;
            navigationMenuItem25.HasSplitLintAtTop = true;
            navigationMenuItem25.Icon = null;
            navigationMenuItem25.Items = null;
            navigationMenuItem25.ItemWidth = 100;
            navigationMenuItem25.ShowTip = false;
            navigationMenuItem25.Text = "子菜单3";
            navigationMenuItem25.TipText = null;
            navigationMenuItem16.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem17,
        navigationMenuItem24,
        navigationMenuItem25};
            navigationMenuItem16.ItemWidth = 100;
            navigationMenuItem16.ShowTip = true;
            navigationMenuItem16.Text = "菜单1";
            navigationMenuItem16.TipText = null;
            navigationMenuItem26.AnchorRight = false;
            navigationMenuItem26.DataSource = null;
            navigationMenuItem26.HasSplitLintAtTop = false;
            navigationMenuItem26.Icon = null;
            navigationMenuItem27.AnchorRight = false;
            navigationMenuItem27.DataSource = null;
            navigationMenuItem27.HasSplitLintAtTop = false;
            navigationMenuItem27.Icon = null;
            navigationMenuItem27.Items = null;
            navigationMenuItem27.ItemWidth = 100;
            navigationMenuItem27.ShowTip = false;
            navigationMenuItem27.Text = "1";
            navigationMenuItem27.TipText = null;
            navigationMenuItem28.AnchorRight = false;
            navigationMenuItem28.DataSource = null;
            navigationMenuItem28.HasSplitLintAtTop = false;
            navigationMenuItem28.Icon = null;
            navigationMenuItem28.Items = null;
            navigationMenuItem28.ItemWidth = 100;
            navigationMenuItem28.ShowTip = false;
            navigationMenuItem28.Text = "2";
            navigationMenuItem28.TipText = null;
            navigationMenuItem26.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem27,
        navigationMenuItem28};
            navigationMenuItem26.ItemWidth = 100;
            navigationMenuItem26.ShowTip = true;
            navigationMenuItem26.Text = "菜单2";
            navigationMenuItem26.TipText = "4";
            navigationMenuItem29.AnchorRight = true;
            navigationMenuItem29.DataSource = null;
            navigationMenuItem29.HasSplitLintAtTop = false;
            navigationMenuItem29.Icon = ((System.Drawing.Image)(resources.GetObject("navigationMenuItem29.Icon")));
            navigationMenuItem29.Items = null;
            navigationMenuItem29.ItemWidth = 100;
            navigationMenuItem29.ShowTip = false;
            navigationMenuItem29.Text = "菜单3";
            navigationMenuItem29.TipText = null;
            navigationMenuItem30.AnchorRight = true;
            navigationMenuItem30.DataSource = null;
            navigationMenuItem30.HasSplitLintAtTop = false;
            navigationMenuItem30.Icon = null;
            navigationMenuItem30.Items = null;
            navigationMenuItem30.ItemWidth = 100;
            navigationMenuItem30.ShowTip = false;
            navigationMenuItem30.Text = "菜单4";
            navigationMenuItem30.TipText = null;
            this.ucNavigationMenu2.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem16,
        navigationMenuItem26,
        navigationMenuItem29,
        navigationMenuItem30};
            this.ucNavigationMenu2.Location = new System.Drawing.Point(0, 111);
            this.ucNavigationMenu2.Name = "ucNavigationMenu2";
            this.ucNavigationMenu2.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.ucNavigationMenu2.Size = new System.Drawing.Size(893, 60);
            this.ucNavigationMenu2.TabIndex = 0;
            this.ucNavigationMenu2.TipColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucNavigationMenu2.ClickItemed += new System.EventHandler(this.ucNavigationMenu1_ClickItemed);
            // 
            // ucNavigationMenu1
            // 
            this.ucNavigationMenu1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucNavigationMenu1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(73)))));
            this.ucNavigationMenu1.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucNavigationMenu1.ForeColor = System.Drawing.Color.White;
            navigationMenuItem31.AnchorRight = false;
            navigationMenuItem31.DataSource = null;
            navigationMenuItem31.HasSplitLintAtTop = false;
            navigationMenuItem31.Icon = null;
            navigationMenuItem32.AnchorRight = false;
            navigationMenuItem32.DataSource = null;
            navigationMenuItem32.HasSplitLintAtTop = false;
            navigationMenuItem32.Icon = null;
            navigationMenuItem33.AnchorRight = false;
            navigationMenuItem33.DataSource = null;
            navigationMenuItem33.HasSplitLintAtTop = false;
            navigationMenuItem33.Icon = null;
            navigationMenuItem33.Items = null;
            navigationMenuItem33.ItemWidth = 100;
            navigationMenuItem33.ShowTip = false;
            navigationMenuItem33.Text = "1";
            navigationMenuItem33.TipText = null;
            navigationMenuItem34.AnchorRight = false;
            navigationMenuItem34.DataSource = null;
            navigationMenuItem34.HasSplitLintAtTop = false;
            navigationMenuItem34.Icon = null;
            navigationMenuItem35.AnchorRight = false;
            navigationMenuItem35.DataSource = null;
            navigationMenuItem35.HasSplitLintAtTop = false;
            navigationMenuItem35.Icon = null;
            navigationMenuItem35.Items = null;
            navigationMenuItem35.ItemWidth = 100;
            navigationMenuItem35.ShowTip = false;
            navigationMenuItem35.Text = "1";
            navigationMenuItem35.TipText = null;
            navigationMenuItem36.AnchorRight = false;
            navigationMenuItem36.DataSource = null;
            navigationMenuItem36.HasSplitLintAtTop = false;
            navigationMenuItem36.Icon = null;
            navigationMenuItem36.Items = null;
            navigationMenuItem36.ItemWidth = 100;
            navigationMenuItem36.ShowTip = false;
            navigationMenuItem36.Text = "2";
            navigationMenuItem36.TipText = null;
            navigationMenuItem37.AnchorRight = false;
            navigationMenuItem37.DataSource = null;
            navigationMenuItem37.HasSplitLintAtTop = false;
            navigationMenuItem37.Icon = null;
            navigationMenuItem37.Items = null;
            navigationMenuItem37.ItemWidth = 100;
            navigationMenuItem37.ShowTip = false;
            navigationMenuItem37.Text = "3";
            navigationMenuItem37.TipText = null;
            navigationMenuItem34.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem35,
        navigationMenuItem36,
        navigationMenuItem37};
            navigationMenuItem34.ItemWidth = 100;
            navigationMenuItem34.ShowTip = false;
            navigationMenuItem34.Text = "2";
            navigationMenuItem34.TipText = null;
            navigationMenuItem38.AnchorRight = false;
            navigationMenuItem38.DataSource = null;
            navigationMenuItem38.HasSplitLintAtTop = false;
            navigationMenuItem38.Icon = null;
            navigationMenuItem38.Items = null;
            navigationMenuItem38.ItemWidth = 100;
            navigationMenuItem38.ShowTip = false;
            navigationMenuItem38.Text = "3";
            navigationMenuItem38.TipText = null;
            navigationMenuItem32.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem33,
        navigationMenuItem34,
        navigationMenuItem38};
            navigationMenuItem32.ItemWidth = 100;
            navigationMenuItem32.ShowTip = false;
            navigationMenuItem32.Text = "子菜单1";
            navigationMenuItem32.TipText = null;
            navigationMenuItem39.AnchorRight = false;
            navigationMenuItem39.DataSource = null;
            navigationMenuItem39.HasSplitLintAtTop = false;
            navigationMenuItem39.Icon = null;
            navigationMenuItem39.Items = null;
            navigationMenuItem39.ItemWidth = 100;
            navigationMenuItem39.ShowTip = false;
            navigationMenuItem39.Text = "子菜单2";
            navigationMenuItem39.TipText = null;
            navigationMenuItem40.AnchorRight = false;
            navigationMenuItem40.DataSource = null;
            navigationMenuItem40.HasSplitLintAtTop = true;
            navigationMenuItem40.Icon = null;
            navigationMenuItem40.Items = null;
            navigationMenuItem40.ItemWidth = 100;
            navigationMenuItem40.ShowTip = false;
            navigationMenuItem40.Text = "子菜单3";
            navigationMenuItem40.TipText = null;
            navigationMenuItem31.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem32,
        navigationMenuItem39,
        navigationMenuItem40};
            navigationMenuItem31.ItemWidth = 100;
            navigationMenuItem31.ShowTip = true;
            navigationMenuItem31.Text = "菜单1";
            navigationMenuItem31.TipText = null;
            navigationMenuItem41.AnchorRight = false;
            navigationMenuItem41.DataSource = null;
            navigationMenuItem41.HasSplitLintAtTop = false;
            navigationMenuItem41.Icon = null;
            navigationMenuItem42.AnchorRight = false;
            navigationMenuItem42.DataSource = null;
            navigationMenuItem42.HasSplitLintAtTop = false;
            navigationMenuItem42.Icon = null;
            navigationMenuItem42.Items = null;
            navigationMenuItem42.ItemWidth = 100;
            navigationMenuItem42.ShowTip = false;
            navigationMenuItem42.Text = "1";
            navigationMenuItem42.TipText = null;
            navigationMenuItem43.AnchorRight = false;
            navigationMenuItem43.DataSource = null;
            navigationMenuItem43.HasSplitLintAtTop = false;
            navigationMenuItem43.Icon = null;
            navigationMenuItem43.Items = null;
            navigationMenuItem43.ItemWidth = 100;
            navigationMenuItem43.ShowTip = false;
            navigationMenuItem43.Text = "2";
            navigationMenuItem43.TipText = null;
            navigationMenuItem41.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem42,
        navigationMenuItem43};
            navigationMenuItem41.ItemWidth = 100;
            navigationMenuItem41.ShowTip = true;
            navigationMenuItem41.Text = "菜单2";
            navigationMenuItem41.TipText = "4";
            navigationMenuItem44.AnchorRight = true;
            navigationMenuItem44.DataSource = null;
            navigationMenuItem44.HasSplitLintAtTop = false;
            navigationMenuItem44.Icon = ((System.Drawing.Image)(resources.GetObject("navigationMenuItem44.Icon")));
            navigationMenuItem44.Items = null;
            navigationMenuItem44.ItemWidth = 100;
            navigationMenuItem44.ShowTip = false;
            navigationMenuItem44.Text = "菜单3";
            navigationMenuItem44.TipText = null;
            navigationMenuItem45.AnchorRight = true;
            navigationMenuItem45.DataSource = null;
            navigationMenuItem45.HasSplitLintAtTop = false;
            navigationMenuItem45.Icon = null;
            navigationMenuItem45.Items = null;
            navigationMenuItem45.ItemWidth = 100;
            navigationMenuItem45.ShowTip = false;
            navigationMenuItem45.Text = "菜单4";
            navigationMenuItem45.TipText = null;
            this.ucNavigationMenu1.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem31,
        navigationMenuItem41,
        navigationMenuItem44,
        navigationMenuItem45};
            this.ucNavigationMenu1.Location = new System.Drawing.Point(0, 0);
            this.ucNavigationMenu1.Name = "ucNavigationMenu1";
            this.ucNavigationMenu1.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.ucNavigationMenu1.Size = new System.Drawing.Size(893, 60);
            this.ucNavigationMenu1.TabIndex = 0;
            this.ucNavigationMenu1.TipColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucNavigationMenu1.ClickItemed += new System.EventHandler(this.ucNavigationMenu1_ClickItemed);
            // 
            // ucNavigationMenu4
            // 
            this.ucNavigationMenu4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucNavigationMenu4.BackColor = System.Drawing.Color.Gray;
            this.ucNavigationMenu4.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucNavigationMenu4.ForeColor = System.Drawing.Color.White;
            navigationMenuItem46.AnchorRight = false;
            navigationMenuItem46.DataSource = null;
            navigationMenuItem46.HasSplitLintAtTop = false;
            navigationMenuItem46.Icon = null;
            navigationMenuItem47.AnchorRight = false;
            navigationMenuItem47.DataSource = null;
            navigationMenuItem47.HasSplitLintAtTop = false;
            navigationMenuItem47.Icon = null;
            navigationMenuItem48.AnchorRight = false;
            navigationMenuItem48.DataSource = null;
            navigationMenuItem48.HasSplitLintAtTop = false;
            navigationMenuItem48.Icon = null;
            navigationMenuItem48.Items = null;
            navigationMenuItem48.ItemWidth = 100;
            navigationMenuItem48.ShowTip = false;
            navigationMenuItem48.Text = "1";
            navigationMenuItem48.TipText = null;
            navigationMenuItem49.AnchorRight = false;
            navigationMenuItem49.DataSource = null;
            navigationMenuItem49.HasSplitLintAtTop = false;
            navigationMenuItem49.Icon = null;
            navigationMenuItem50.AnchorRight = false;
            navigationMenuItem50.DataSource = null;
            navigationMenuItem50.HasSplitLintAtTop = false;
            navigationMenuItem50.Icon = null;
            navigationMenuItem50.Items = null;
            navigationMenuItem50.ItemWidth = 100;
            navigationMenuItem50.ShowTip = false;
            navigationMenuItem50.Text = "1";
            navigationMenuItem50.TipText = null;
            navigationMenuItem51.AnchorRight = false;
            navigationMenuItem51.DataSource = null;
            navigationMenuItem51.HasSplitLintAtTop = false;
            navigationMenuItem51.Icon = null;
            navigationMenuItem51.Items = null;
            navigationMenuItem51.ItemWidth = 100;
            navigationMenuItem51.ShowTip = false;
            navigationMenuItem51.Text = "2";
            navigationMenuItem51.TipText = null;
            navigationMenuItem52.AnchorRight = false;
            navigationMenuItem52.DataSource = null;
            navigationMenuItem52.HasSplitLintAtTop = false;
            navigationMenuItem52.Icon = null;
            navigationMenuItem52.Items = null;
            navigationMenuItem52.ItemWidth = 100;
            navigationMenuItem52.ShowTip = false;
            navigationMenuItem52.Text = "3";
            navigationMenuItem52.TipText = null;
            navigationMenuItem49.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem50,
        navigationMenuItem51,
        navigationMenuItem52};
            navigationMenuItem49.ItemWidth = 100;
            navigationMenuItem49.ShowTip = false;
            navigationMenuItem49.Text = "2";
            navigationMenuItem49.TipText = null;
            navigationMenuItem53.AnchorRight = false;
            navigationMenuItem53.DataSource = null;
            navigationMenuItem53.HasSplitLintAtTop = false;
            navigationMenuItem53.Icon = null;
            navigationMenuItem53.Items = null;
            navigationMenuItem53.ItemWidth = 100;
            navigationMenuItem53.ShowTip = false;
            navigationMenuItem53.Text = "3";
            navigationMenuItem53.TipText = null;
            navigationMenuItem47.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem48,
        navigationMenuItem49,
        navigationMenuItem53};
            navigationMenuItem47.ItemWidth = 100;
            navigationMenuItem47.ShowTip = false;
            navigationMenuItem47.Text = "子菜单1";
            navigationMenuItem47.TipText = null;
            navigationMenuItem54.AnchorRight = false;
            navigationMenuItem54.DataSource = null;
            navigationMenuItem54.HasSplitLintAtTop = false;
            navigationMenuItem54.Icon = null;
            navigationMenuItem54.Items = null;
            navigationMenuItem54.ItemWidth = 100;
            navigationMenuItem54.ShowTip = false;
            navigationMenuItem54.Text = "子菜单2";
            navigationMenuItem54.TipText = null;
            navigationMenuItem55.AnchorRight = false;
            navigationMenuItem55.DataSource = null;
            navigationMenuItem55.HasSplitLintAtTop = true;
            navigationMenuItem55.Icon = null;
            navigationMenuItem55.Items = null;
            navigationMenuItem55.ItemWidth = 100;
            navigationMenuItem55.ShowTip = false;
            navigationMenuItem55.Text = "子菜单3";
            navigationMenuItem55.TipText = null;
            navigationMenuItem46.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem47,
        navigationMenuItem54,
        navigationMenuItem55};
            navigationMenuItem46.ItemWidth = 100;
            navigationMenuItem46.ShowTip = true;
            navigationMenuItem46.Text = "菜单1";
            navigationMenuItem46.TipText = null;
            navigationMenuItem56.AnchorRight = false;
            navigationMenuItem56.DataSource = null;
            navigationMenuItem56.HasSplitLintAtTop = false;
            navigationMenuItem56.Icon = null;
            navigationMenuItem57.AnchorRight = false;
            navigationMenuItem57.DataSource = null;
            navigationMenuItem57.HasSplitLintAtTop = false;
            navigationMenuItem57.Icon = null;
            navigationMenuItem57.Items = null;
            navigationMenuItem57.ItemWidth = 100;
            navigationMenuItem57.ShowTip = false;
            navigationMenuItem57.Text = "1";
            navigationMenuItem57.TipText = null;
            navigationMenuItem58.AnchorRight = false;
            navigationMenuItem58.DataSource = null;
            navigationMenuItem58.HasSplitLintAtTop = false;
            navigationMenuItem58.Icon = null;
            navigationMenuItem58.Items = null;
            navigationMenuItem58.ItemWidth = 100;
            navigationMenuItem58.ShowTip = false;
            navigationMenuItem58.Text = "2";
            navigationMenuItem58.TipText = null;
            navigationMenuItem56.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem57,
        navigationMenuItem58};
            navigationMenuItem56.ItemWidth = 100;
            navigationMenuItem56.ShowTip = true;
            navigationMenuItem56.Text = "菜单2";
            navigationMenuItem56.TipText = "4";
            navigationMenuItem59.AnchorRight = true;
            navigationMenuItem59.DataSource = null;
            navigationMenuItem59.HasSplitLintAtTop = false;
            navigationMenuItem59.Icon = ((System.Drawing.Image)(resources.GetObject("navigationMenuItem59.Icon")));
            navigationMenuItem59.Items = null;
            navigationMenuItem59.ItemWidth = 100;
            navigationMenuItem59.ShowTip = false;
            navigationMenuItem59.Text = "菜单3";
            navigationMenuItem59.TipText = null;
            navigationMenuItem60.AnchorRight = true;
            navigationMenuItem60.DataSource = null;
            navigationMenuItem60.HasSplitLintAtTop = false;
            navigationMenuItem60.Icon = null;
            navigationMenuItem60.Items = null;
            navigationMenuItem60.ItemWidth = 100;
            navigationMenuItem60.ShowTip = false;
            navigationMenuItem60.Text = "菜单4";
            navigationMenuItem60.TipText = null;
            this.ucNavigationMenu4.Items = new HZH_Controls.Controls.NavigationMenuItem[] {
        navigationMenuItem46,
        navigationMenuItem56,
        navigationMenuItem59,
        navigationMenuItem60};
            this.ucNavigationMenu4.Location = new System.Drawing.Point(0, 349);
            this.ucNavigationMenu4.Name = "ucNavigationMenu4";
            this.ucNavigationMenu4.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.ucNavigationMenu4.Size = new System.Drawing.Size(893, 60);
            this.ucNavigationMenu4.TabIndex = 0;
            this.ucNavigationMenu4.TipColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucNavigationMenu4.ClickItemed += new System.EventHandler(this.ucNavigationMenu1_ClickItemed);
            // 
            // UCTestNavigationMenu
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucNavigationMenu4);
            this.Controls.Add(this.ucNavigationMenu3);
            this.Controls.Add(this.ucNavigationMenu2);
            this.Controls.Add(this.ucNavigationMenu1);
            this.Name = "UCTestNavigationMenu";
            this.Size = new System.Drawing.Size(893, 598);
            this.Load += new System.EventHandler(this.UCTestNavigationMenu_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCNavigationMenu ucNavigationMenu1;
        private HZH_Controls.Controls.UCNavigationMenu ucNavigationMenu2;
        private HZH_Controls.Controls.UCNavigationMenu ucNavigationMenu3;
        private HZH_Controls.Controls.UCNavigationMenu ucNavigationMenu4;
    }
}

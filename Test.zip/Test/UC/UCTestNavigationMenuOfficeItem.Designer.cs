﻿namespace Test.UC
{
    partial class UCTestNavigationMenuOfficeItem
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCTestNavigationMenuOfficeItem));
            this.ucBtnImg1 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg2 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg3 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg4 = new HZH_Controls.Controls.UCBtnImg();
            this.ucSplitLine_V1 = new HZH_Controls.Controls.UCSplitLine_V();
            this.ucBtnImg5 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg6 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg7 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg8 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg9 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg10 = new HZH_Controls.Controls.UCBtnImg();
            this.ucSplitLine_V2 = new HZH_Controls.Controls.UCSplitLine_V();
            this.ucBtnImg11 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg12 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg13 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg14 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg15 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg16 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg17 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg18 = new HZH_Controls.Controls.UCBtnImg();
            this.ucSplitLine_V3 = new HZH_Controls.Controls.UCSplitLine_V();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ucBtnImg1
            // 
            this.ucBtnImg1.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg1.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg1.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg1.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg1.BtnText = "";
            this.ucBtnImg1.ConerRadius = 5;
            this.ucBtnImg1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg1.FillColor = System.Drawing.Color.White;
            this.ucBtnImg1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg1.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg1.Image")));
            this.ucBtnImg1.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg1.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg1.ImageFontIcons")));
            this.ucBtnImg1.IsRadius = true;
            this.ucBtnImg1.IsShowRect = true;
            this.ucBtnImg1.IsShowTips = false;
            this.ucBtnImg1.Location = new System.Drawing.Point(13, 11);
            this.ucBtnImg1.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg1.Name = "ucBtnImg1";
            this.ucBtnImg1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnImg1.RectWidth = 1;
            this.ucBtnImg1.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg1.TabIndex = 0;
            this.ucBtnImg1.TabStop = false;
            this.ucBtnImg1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg1.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg1.TipsText = "";
            // 
            // ucBtnImg2
            // 
            this.ucBtnImg2.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg2.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg2.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg2.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg2.BtnText = "";
            this.ucBtnImg2.ConerRadius = 5;
            this.ucBtnImg2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg2.FillColor = System.Drawing.Color.White;
            this.ucBtnImg2.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg2.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg2.Image")));
            this.ucBtnImg2.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg2.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg2.ImageFontIcons")));
            this.ucBtnImg2.IsRadius = true;
            this.ucBtnImg2.IsShowRect = true;
            this.ucBtnImg2.IsShowTips = false;
            this.ucBtnImg2.Location = new System.Drawing.Point(13, 54);
            this.ucBtnImg2.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg2.Name = "ucBtnImg2";
            this.ucBtnImg2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnImg2.RectWidth = 1;
            this.ucBtnImg2.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg2.TabIndex = 0;
            this.ucBtnImg2.TabStop = false;
            this.ucBtnImg2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg2.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg2.TipsText = "";
            // 
            // ucBtnImg3
            // 
            this.ucBtnImg3.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg3.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg3.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg3.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg3.BtnText = "";
            this.ucBtnImg3.ConerRadius = 5;
            this.ucBtnImg3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg3.FillColor = System.Drawing.Color.White;
            this.ucBtnImg3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg3.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg3.Image")));
            this.ucBtnImg3.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg3.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg3.ImageFontIcons")));
            this.ucBtnImg3.IsRadius = true;
            this.ucBtnImg3.IsShowRect = true;
            this.ucBtnImg3.IsShowTips = false;
            this.ucBtnImg3.Location = new System.Drawing.Point(71, 11);
            this.ucBtnImg3.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg3.Name = "ucBtnImg3";
            this.ucBtnImg3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnImg3.RectWidth = 1;
            this.ucBtnImg3.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg3.TabIndex = 0;
            this.ucBtnImg3.TabStop = false;
            this.ucBtnImg3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg3.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg3.TipsText = "";
            // 
            // ucBtnImg4
            // 
            this.ucBtnImg4.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg4.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg4.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg4.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg4.BtnText = "";
            this.ucBtnImg4.ConerRadius = 5;
            this.ucBtnImg4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg4.FillColor = System.Drawing.Color.White;
            this.ucBtnImg4.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg4.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg4.Image")));
            this.ucBtnImg4.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg4.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg4.ImageFontIcons")));
            this.ucBtnImg4.IsRadius = true;
            this.ucBtnImg4.IsShowRect = true;
            this.ucBtnImg4.IsShowTips = false;
            this.ucBtnImg4.Location = new System.Drawing.Point(71, 54);
            this.ucBtnImg4.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg4.Name = "ucBtnImg4";
            this.ucBtnImg4.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnImg4.RectWidth = 1;
            this.ucBtnImg4.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg4.TabIndex = 0;
            this.ucBtnImg4.TabStop = false;
            this.ucBtnImg4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg4.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg4.TipsText = "";
            // 
            // ucSplitLine_V1
            // 
            this.ucSplitLine_V1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucSplitLine_V1.Location = new System.Drawing.Point(128, 11);
            this.ucSplitLine_V1.Name = "ucSplitLine_V1";
            this.ucSplitLine_V1.Size = new System.Drawing.Size(1, 76);
            this.ucSplitLine_V1.TabIndex = 1;
            this.ucSplitLine_V1.TabStop = false;
            // 
            // ucBtnImg5
            // 
            this.ucBtnImg5.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg5.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg5.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg5.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg5.BtnText = "";
            this.ucBtnImg5.ConerRadius = 5;
            this.ucBtnImg5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg5.FillColor = System.Drawing.Color.White;
            this.ucBtnImg5.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg5.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg5.Image")));
            this.ucBtnImg5.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg5.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg5.ImageFontIcons")));
            this.ucBtnImg5.IsRadius = true;
            this.ucBtnImg5.IsShowRect = true;
            this.ucBtnImg5.IsShowTips = false;
            this.ucBtnImg5.Location = new System.Drawing.Point(143, 11);
            this.ucBtnImg5.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg5.Name = "ucBtnImg5";
            this.ucBtnImg5.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnImg5.RectWidth = 1;
            this.ucBtnImg5.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg5.TabIndex = 0;
            this.ucBtnImg5.TabStop = false;
            this.ucBtnImg5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg5.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg5.TipsText = "";
            // 
            // ucBtnImg6
            // 
            this.ucBtnImg6.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg6.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg6.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg6.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg6.BtnText = "";
            this.ucBtnImg6.ConerRadius = 5;
            this.ucBtnImg6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg6.FillColor = System.Drawing.Color.White;
            this.ucBtnImg6.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg6.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg6.Image")));
            this.ucBtnImg6.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg6.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg6.ImageFontIcons")));
            this.ucBtnImg6.IsRadius = true;
            this.ucBtnImg6.IsShowRect = true;
            this.ucBtnImg6.IsShowTips = false;
            this.ucBtnImg6.Location = new System.Drawing.Point(203, 11);
            this.ucBtnImg6.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg6.Name = "ucBtnImg6";
            this.ucBtnImg6.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnImg6.RectWidth = 1;
            this.ucBtnImg6.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg6.TabIndex = 0;
            this.ucBtnImg6.TabStop = false;
            this.ucBtnImg6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg6.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg6.TipsText = "";
            // 
            // ucBtnImg7
            // 
            this.ucBtnImg7.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg7.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg7.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg7.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg7.BtnText = "";
            this.ucBtnImg7.ConerRadius = 5;
            this.ucBtnImg7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg7.FillColor = System.Drawing.Color.White;
            this.ucBtnImg7.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg7.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg7.Image")));
            this.ucBtnImg7.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg7.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg7.ImageFontIcons")));
            this.ucBtnImg7.IsRadius = true;
            this.ucBtnImg7.IsShowRect = true;
            this.ucBtnImg7.IsShowTips = false;
            this.ucBtnImg7.Location = new System.Drawing.Point(263, 11);
            this.ucBtnImg7.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg7.Name = "ucBtnImg7";
            this.ucBtnImg7.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnImg7.RectWidth = 1;
            this.ucBtnImg7.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg7.TabIndex = 0;
            this.ucBtnImg7.TabStop = false;
            this.ucBtnImg7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg7.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg7.TipsText = "";
            // 
            // ucBtnImg8
            // 
            this.ucBtnImg8.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg8.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg8.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg8.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg8.BtnText = "";
            this.ucBtnImg8.ConerRadius = 5;
            this.ucBtnImg8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg8.FillColor = System.Drawing.Color.White;
            this.ucBtnImg8.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg8.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg8.Image")));
            this.ucBtnImg8.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg8.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg8.ImageFontIcons")));
            this.ucBtnImg8.IsRadius = true;
            this.ucBtnImg8.IsShowRect = true;
            this.ucBtnImg8.IsShowTips = false;
            this.ucBtnImg8.Location = new System.Drawing.Point(143, 55);
            this.ucBtnImg8.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg8.Name = "ucBtnImg8";
            this.ucBtnImg8.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnImg8.RectWidth = 1;
            this.ucBtnImg8.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg8.TabIndex = 0;
            this.ucBtnImg8.TabStop = false;
            this.ucBtnImg8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg8.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg8.TipsText = "";
            // 
            // ucBtnImg9
            // 
            this.ucBtnImg9.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg9.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg9.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg9.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg9.BtnText = "";
            this.ucBtnImg9.ConerRadius = 5;
            this.ucBtnImg9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg9.FillColor = System.Drawing.Color.White;
            this.ucBtnImg9.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg9.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg9.Image")));
            this.ucBtnImg9.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg9.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg9.ImageFontIcons")));
            this.ucBtnImg9.IsRadius = true;
            this.ucBtnImg9.IsShowRect = true;
            this.ucBtnImg9.IsShowTips = false;
            this.ucBtnImg9.Location = new System.Drawing.Point(203, 54);
            this.ucBtnImg9.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg9.Name = "ucBtnImg9";
            this.ucBtnImg9.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnImg9.RectWidth = 1;
            this.ucBtnImg9.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg9.TabIndex = 0;
            this.ucBtnImg9.TabStop = false;
            this.ucBtnImg9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg9.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg9.TipsText = "";
            // 
            // ucBtnImg10
            // 
            this.ucBtnImg10.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg10.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg10.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg10.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg10.BtnText = "";
            this.ucBtnImg10.ConerRadius = 5;
            this.ucBtnImg10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg10.FillColor = System.Drawing.Color.White;
            this.ucBtnImg10.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg10.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg10.Image")));
            this.ucBtnImg10.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg10.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg10.ImageFontIcons")));
            this.ucBtnImg10.IsRadius = true;
            this.ucBtnImg10.IsShowRect = true;
            this.ucBtnImg10.IsShowTips = false;
            this.ucBtnImg10.Location = new System.Drawing.Point(263, 55);
            this.ucBtnImg10.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg10.Name = "ucBtnImg10";
            this.ucBtnImg10.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnImg10.RectWidth = 1;
            this.ucBtnImg10.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg10.TabIndex = 0;
            this.ucBtnImg10.TabStop = false;
            this.ucBtnImg10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg10.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg10.TipsText = "";
            // 
            // ucSplitLine_V2
            // 
            this.ucSplitLine_V2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucSplitLine_V2.Location = new System.Drawing.Point(325, 10);
            this.ucSplitLine_V2.Name = "ucSplitLine_V2";
            this.ucSplitLine_V2.Size = new System.Drawing.Size(1, 76);
            this.ucSplitLine_V2.TabIndex = 2;
            this.ucSplitLine_V2.TabStop = false;
            // 
            // ucBtnImg11
            // 
            this.ucBtnImg11.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg11.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg11.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg11.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg11.BtnText = "";
            this.ucBtnImg11.ConerRadius = 5;
            this.ucBtnImg11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg11.FillColor = System.Drawing.Color.White;
            this.ucBtnImg11.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg11.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg11.Image")));
            this.ucBtnImg11.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg11.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg11.ImageFontIcons")));
            this.ucBtnImg11.IsRadius = true;
            this.ucBtnImg11.IsShowRect = true;
            this.ucBtnImg11.IsShowTips = false;
            this.ucBtnImg11.Location = new System.Drawing.Point(341, 11);
            this.ucBtnImg11.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg11.Name = "ucBtnImg11";
            this.ucBtnImg11.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            this.ucBtnImg11.RectWidth = 1;
            this.ucBtnImg11.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg11.TabIndex = 0;
            this.ucBtnImg11.TabStop = false;
            this.ucBtnImg11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg11.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg11.TipsText = "";
            // 
            // ucBtnImg12
            // 
            this.ucBtnImg12.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg12.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg12.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg12.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg12.BtnText = "";
            this.ucBtnImg12.ConerRadius = 5;
            this.ucBtnImg12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg12.FillColor = System.Drawing.Color.White;
            this.ucBtnImg12.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg12.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg12.Image")));
            this.ucBtnImg12.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg12.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg12.ImageFontIcons")));
            this.ucBtnImg12.IsRadius = true;
            this.ucBtnImg12.IsShowRect = true;
            this.ucBtnImg12.IsShowTips = false;
            this.ucBtnImg12.Location = new System.Drawing.Point(400, 11);
            this.ucBtnImg12.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg12.Name = "ucBtnImg12";
            this.ucBtnImg12.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            this.ucBtnImg12.RectWidth = 1;
            this.ucBtnImg12.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg12.TabIndex = 0;
            this.ucBtnImg12.TabStop = false;
            this.ucBtnImg12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg12.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg12.TipsText = "";
            // 
            // ucBtnImg13
            // 
            this.ucBtnImg13.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg13.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg13.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg13.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg13.BtnText = "";
            this.ucBtnImg13.ConerRadius = 5;
            this.ucBtnImg13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg13.FillColor = System.Drawing.Color.White;
            this.ucBtnImg13.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg13.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg13.Image")));
            this.ucBtnImg13.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg13.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg13.ImageFontIcons")));
            this.ucBtnImg13.IsRadius = true;
            this.ucBtnImg13.IsShowRect = true;
            this.ucBtnImg13.IsShowTips = false;
            this.ucBtnImg13.Location = new System.Drawing.Point(461, 11);
            this.ucBtnImg13.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg13.Name = "ucBtnImg13";
            this.ucBtnImg13.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            this.ucBtnImg13.RectWidth = 1;
            this.ucBtnImg13.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg13.TabIndex = 0;
            this.ucBtnImg13.TabStop = false;
            this.ucBtnImg13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg13.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg13.TipsText = "";
            // 
            // ucBtnImg14
            // 
            this.ucBtnImg14.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg14.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg14.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg14.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg14.BtnText = "";
            this.ucBtnImg14.ConerRadius = 5;
            this.ucBtnImg14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg14.FillColor = System.Drawing.Color.White;
            this.ucBtnImg14.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg14.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg14.Image")));
            this.ucBtnImg14.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg14.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg14.ImageFontIcons")));
            this.ucBtnImg14.IsRadius = true;
            this.ucBtnImg14.IsShowRect = true;
            this.ucBtnImg14.IsShowTips = false;
            this.ucBtnImg14.Location = new System.Drawing.Point(523, 11);
            this.ucBtnImg14.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg14.Name = "ucBtnImg14";
            this.ucBtnImg14.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            this.ucBtnImg14.RectWidth = 1;
            this.ucBtnImg14.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg14.TabIndex = 0;
            this.ucBtnImg14.TabStop = false;
            this.ucBtnImg14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg14.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg14.TipsText = "";
            // 
            // ucBtnImg15
            // 
            this.ucBtnImg15.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg15.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg15.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg15.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg15.BtnText = "";
            this.ucBtnImg15.ConerRadius = 5;
            this.ucBtnImg15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg15.FillColor = System.Drawing.Color.White;
            this.ucBtnImg15.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg15.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg15.Image")));
            this.ucBtnImg15.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg15.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg15.ImageFontIcons")));
            this.ucBtnImg15.IsRadius = true;
            this.ucBtnImg15.IsShowRect = true;
            this.ucBtnImg15.IsShowTips = false;
            this.ucBtnImg15.Location = new System.Drawing.Point(341, 54);
            this.ucBtnImg15.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg15.Name = "ucBtnImg15";
            this.ucBtnImg15.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            this.ucBtnImg15.RectWidth = 1;
            this.ucBtnImg15.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg15.TabIndex = 0;
            this.ucBtnImg15.TabStop = false;
            this.ucBtnImg15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg15.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg15.TipsText = "";
            // 
            // ucBtnImg16
            // 
            this.ucBtnImg16.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg16.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg16.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg16.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg16.BtnText = "";
            this.ucBtnImg16.ConerRadius = 5;
            this.ucBtnImg16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg16.FillColor = System.Drawing.Color.White;
            this.ucBtnImg16.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg16.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg16.Image")));
            this.ucBtnImg16.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg16.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg16.ImageFontIcons")));
            this.ucBtnImg16.IsRadius = true;
            this.ucBtnImg16.IsShowRect = true;
            this.ucBtnImg16.IsShowTips = false;
            this.ucBtnImg16.Location = new System.Drawing.Point(400, 54);
            this.ucBtnImg16.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg16.Name = "ucBtnImg16";
            this.ucBtnImg16.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            this.ucBtnImg16.RectWidth = 1;
            this.ucBtnImg16.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg16.TabIndex = 0;
            this.ucBtnImg16.TabStop = false;
            this.ucBtnImg16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg16.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg16.TipsText = "";
            // 
            // ucBtnImg17
            // 
            this.ucBtnImg17.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg17.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg17.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg17.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg17.BtnText = "";
            this.ucBtnImg17.ConerRadius = 5;
            this.ucBtnImg17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg17.FillColor = System.Drawing.Color.White;
            this.ucBtnImg17.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg17.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg17.Image")));
            this.ucBtnImg17.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg17.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg17.ImageFontIcons")));
            this.ucBtnImg17.IsRadius = true;
            this.ucBtnImg17.IsShowRect = true;
            this.ucBtnImg17.IsShowTips = false;
            this.ucBtnImg17.Location = new System.Drawing.Point(461, 54);
            this.ucBtnImg17.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg17.Name = "ucBtnImg17";
            this.ucBtnImg17.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            this.ucBtnImg17.RectWidth = 1;
            this.ucBtnImg17.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg17.TabIndex = 0;
            this.ucBtnImg17.TabStop = false;
            this.ucBtnImg17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg17.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg17.TipsText = "";
            // 
            // ucBtnImg18
            // 
            this.ucBtnImg18.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg18.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg18.BtnFont = new System.Drawing.Font("微软雅黑", 17F);
            this.ucBtnImg18.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg18.BtnText = "";
            this.ucBtnImg18.ConerRadius = 5;
            this.ucBtnImg18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg18.FillColor = System.Drawing.Color.White;
            this.ucBtnImg18.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg18.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg18.Image")));
            this.ucBtnImg18.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg18.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg18.ImageFontIcons")));
            this.ucBtnImg18.IsRadius = true;
            this.ucBtnImg18.IsShowRect = true;
            this.ucBtnImg18.IsShowTips = false;
            this.ucBtnImg18.Location = new System.Drawing.Point(523, 54);
            this.ucBtnImg18.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg18.Name = "ucBtnImg18";
            this.ucBtnImg18.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            this.ucBtnImg18.RectWidth = 1;
            this.ucBtnImg18.Size = new System.Drawing.Size(47, 32);
            this.ucBtnImg18.TabIndex = 0;
            this.ucBtnImg18.TabStop = false;
            this.ucBtnImg18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg18.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg18.TipsText = "";
            // 
            // ucSplitLine_V3
            // 
            this.ucSplitLine_V3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucSplitLine_V3.Location = new System.Drawing.Point(582, 11);
            this.ucSplitLine_V3.Name = "ucSplitLine_V3";
            this.ucSplitLine_V3.Size = new System.Drawing.Size(1, 76);
            this.ucSplitLine_V3.TabIndex = 2;
            this.ucSplitLine_V3.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(589, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "测试";
            // 
            // UCTestNavigationMenuOfficeItem
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ucSplitLine_V3);
            this.Controls.Add(this.ucSplitLine_V2);
            this.Controls.Add(this.ucSplitLine_V1);
            this.Controls.Add(this.ucBtnImg4);
            this.Controls.Add(this.ucBtnImg3);
            this.Controls.Add(this.ucBtnImg2);
            this.Controls.Add(this.ucBtnImg10);
            this.Controls.Add(this.ucBtnImg9);
            this.Controls.Add(this.ucBtnImg8);
            this.Controls.Add(this.ucBtnImg7);
            this.Controls.Add(this.ucBtnImg6);
            this.Controls.Add(this.ucBtnImg18);
            this.Controls.Add(this.ucBtnImg14);
            this.Controls.Add(this.ucBtnImg17);
            this.Controls.Add(this.ucBtnImg13);
            this.Controls.Add(this.ucBtnImg16);
            this.Controls.Add(this.ucBtnImg12);
            this.Controls.Add(this.ucBtnImg15);
            this.Controls.Add(this.ucBtnImg11);
            this.Controls.Add(this.ucBtnImg5);
            this.Controls.Add(this.ucBtnImg1);
            this.Name = "UCTestNavigationMenuOfficeItem";
            this.Size = new System.Drawing.Size(791, 100);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private HZH_Controls.Controls.UCBtnImg ucBtnImg1;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg2;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg3;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg4;
        private HZH_Controls.Controls.UCSplitLine_V ucSplitLine_V1;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg5;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg6;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg7;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg8;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg9;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg10;
        private HZH_Controls.Controls.UCSplitLine_V ucSplitLine_V2;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg11;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg12;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg13;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg14;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg15;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg16;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg17;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg18;
        private HZH_Controls.Controls.UCSplitLine_V ucSplitLine_V3;
        private System.Windows.Forms.Label label1;
    }
}

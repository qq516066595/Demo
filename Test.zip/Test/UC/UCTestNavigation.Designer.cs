﻿namespace Test.UC
{
    partial class UCTestNavigation
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem1 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem2 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem3 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem4 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem5 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem6 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem7 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem8 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem9 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem10 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem11 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem12 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem13 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem14 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem15 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem16 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem17 = new HZH_Controls.Controls.CrumbNavigationItem();
            HZH_Controls.Controls.CrumbNavigationItem crumbNavigationItem18 = new HZH_Controls.Controls.CrumbNavigationItem();
            this.ucCrumbNavigation4 = new HZH_Controls.Controls.UCCrumbNavigation();
            this.ucCrumbNavigation3 = new HZH_Controls.Controls.UCCrumbNavigation();
            this.ucCrumbNavigation2 = new HZH_Controls.Controls.UCCrumbNavigation();
            this.ucCrumbNavigation1 = new HZH_Controls.Controls.UCCrumbNavigation();
            this.SuspendLayout();
            // 
            // ucCrumbNavigation4
            // 
            this.ucCrumbNavigation4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucCrumbNavigation4.ForeColor = System.Drawing.Color.White;
            crumbNavigationItem1.ItemColor = null;
            crumbNavigationItem1.Key = "0";
            crumbNavigationItem1.Text = "item1";
            crumbNavigationItem2.ItemColor = null;
            crumbNavigationItem2.Key = "1";
            crumbNavigationItem2.Text = "item2";
            crumbNavigationItem3.ItemColor = null;
            crumbNavigationItem3.Key = "2";
            crumbNavigationItem3.Text = "item3";
            crumbNavigationItem4.ItemColor = null;
            crumbNavigationItem4.Key = "3";
            crumbNavigationItem4.Text = "item4";
            crumbNavigationItem5.ItemColor = null;
            crumbNavigationItem5.Key = "4";
            crumbNavigationItem5.Text = "item5";
            crumbNavigationItem6.ItemColor = null;
            crumbNavigationItem6.Key = "5";
            crumbNavigationItem6.Text = "item6";
            this.ucCrumbNavigation4.Items = new HZH_Controls.Controls.CrumbNavigationItem[] {
        crumbNavigationItem1,
        crumbNavigationItem2,
        crumbNavigationItem3,
        crumbNavigationItem4,
        crumbNavigationItem5,
        crumbNavigationItem6};
            this.ucCrumbNavigation4.Location = new System.Drawing.Point(29, 210);
            this.ucCrumbNavigation4.MinimumSize = new System.Drawing.Size(0, 25);
            this.ucCrumbNavigation4.Name = "ucCrumbNavigation4";
            this.ucCrumbNavigation4.NavColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
            this.ucCrumbNavigation4.Size = new System.Drawing.Size(523, 25);
            this.ucCrumbNavigation4.TabIndex = 4;
            this.ucCrumbNavigation4.ClickItemed += new HZH_Controls.Controls.UCCrumbNavigation.CrumbNavigationEventHander(this.ucCrumbNavigation4_ClickItemed);
            // 
            // ucCrumbNavigation3
            // 
            this.ucCrumbNavigation3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucCrumbNavigation3.ForeColor = System.Drawing.Color.White;
            crumbNavigationItem7.ItemColor = null;
            crumbNavigationItem7.Key = "0";
            crumbNavigationItem7.Text = "item1";
            crumbNavigationItem8.ItemColor = null;
            crumbNavigationItem8.Key = "1";
            crumbNavigationItem8.Text = "item2";
            crumbNavigationItem9.ItemColor = null;
            crumbNavigationItem9.Key = "2";
            crumbNavigationItem9.Text = "item3";
            crumbNavigationItem10.ItemColor = null;
            crumbNavigationItem10.Key = "3";
            crumbNavigationItem10.Text = "item4";
            crumbNavigationItem11.ItemColor = null;
            crumbNavigationItem11.Key = "4";
            crumbNavigationItem11.Text = "item5";
            crumbNavigationItem12.ItemColor = null;
            crumbNavigationItem12.Key = "5";
            crumbNavigationItem12.Text = "item6";
            this.ucCrumbNavigation3.Items = new HZH_Controls.Controls.CrumbNavigationItem[] {
        crumbNavigationItem7,
        crumbNavigationItem8,
        crumbNavigationItem9,
        crumbNavigationItem10,
        crumbNavigationItem11,
        crumbNavigationItem12};
            this.ucCrumbNavigation3.Location = new System.Drawing.Point(29, 156);
            this.ucCrumbNavigation3.MinimumSize = new System.Drawing.Size(0, 25);
            this.ucCrumbNavigation3.Name = "ucCrumbNavigation3";
            this.ucCrumbNavigation3.NavColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucCrumbNavigation3.Size = new System.Drawing.Size(523, 25);
            this.ucCrumbNavigation3.TabIndex = 4;
            this.ucCrumbNavigation3.ClickItemed += new HZH_Controls.Controls.UCCrumbNavigation.CrumbNavigationEventHander(this.ucCrumbNavigation3_ClickItemed);
            // 
            // ucCrumbNavigation2
            // 
            this.ucCrumbNavigation2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucCrumbNavigation2.ForeColor = System.Drawing.Color.White;
            crumbNavigationItem13.ItemColor = null;
            crumbNavigationItem13.Key = "0";
            crumbNavigationItem13.Text = "item1";
            crumbNavigationItem14.ItemColor = null;
            crumbNavigationItem14.Key = "1";
            crumbNavigationItem14.Text = "item2";
            crumbNavigationItem15.ItemColor = null;
            crumbNavigationItem15.Key = "2";
            crumbNavigationItem15.Text = "item3";
            this.ucCrumbNavigation2.Items = new HZH_Controls.Controls.CrumbNavigationItem[] {
        crumbNavigationItem13,
        crumbNavigationItem14,
        crumbNavigationItem15};
            this.ucCrumbNavigation2.Location = new System.Drawing.Point(29, 96);
            this.ucCrumbNavigation2.MinimumSize = new System.Drawing.Size(0, 25);
            this.ucCrumbNavigation2.Name = "ucCrumbNavigation2";
            this.ucCrumbNavigation2.NavColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
            this.ucCrumbNavigation2.Size = new System.Drawing.Size(222, 25);
            this.ucCrumbNavigation2.TabIndex = 4;
            this.ucCrumbNavigation2.ClickItemed += new HZH_Controls.Controls.UCCrumbNavigation.CrumbNavigationEventHander(this.ucCrumbNavigation2_ClickItemed);
            // 
            // ucCrumbNavigation1
            // 
            this.ucCrumbNavigation1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucCrumbNavigation1.ForeColor = System.Drawing.Color.White;
            crumbNavigationItem16.ItemColor = null;
            crumbNavigationItem16.Key = "0";
            crumbNavigationItem16.Text = "item1";
            crumbNavigationItem17.ItemColor = null;
            crumbNavigationItem17.Key = "1";
            crumbNavigationItem17.Text = "item2";
            crumbNavigationItem18.ItemColor = null;
            crumbNavigationItem18.Key = "2";
            crumbNavigationItem18.Text = "item3";
            this.ucCrumbNavigation1.Items = new HZH_Controls.Controls.CrumbNavigationItem[] {
        crumbNavigationItem16,
        crumbNavigationItem17,
        crumbNavigationItem18};
            this.ucCrumbNavigation1.Location = new System.Drawing.Point(29, 35);
            this.ucCrumbNavigation1.MinimumSize = new System.Drawing.Size(0, 25);
            this.ucCrumbNavigation1.Name = "ucCrumbNavigation1";
            this.ucCrumbNavigation1.NavColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucCrumbNavigation1.Size = new System.Drawing.Size(222, 25);
            this.ucCrumbNavigation1.TabIndex = 4;
            this.ucCrumbNavigation1.ClickItemed += new HZH_Controls.Controls.UCCrumbNavigation.CrumbNavigationEventHander(this.ucCrumbNavigation1_ClickItemed);
            // 
            // UCTestNavigation
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucCrumbNavigation4);
            this.Controls.Add(this.ucCrumbNavigation3);
            this.Controls.Add(this.ucCrumbNavigation2);
            this.Controls.Add(this.ucCrumbNavigation1);
            this.Name = "UCTestNavigation";
            this.Size = new System.Drawing.Size(611, 500);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCCrumbNavigation ucCrumbNavigation1;
        private HZH_Controls.Controls.UCCrumbNavigation ucCrumbNavigation2;
        private HZH_Controls.Controls.UCCrumbNavigation ucCrumbNavigation3;
        private HZH_Controls.Controls.UCCrumbNavigation ucCrumbNavigation4;
    }
}

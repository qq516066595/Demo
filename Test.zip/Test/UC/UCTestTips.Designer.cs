﻿namespace Test.UC
{
    partial class UCTestTips
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucBtnExt6 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt7 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt9 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt8 = new HZH_Controls.Controls.UCBtnExt();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ucBtnExt6
            // 
            this.ucBtnExt6.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt6.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt6.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt6.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt6.BtnText = "点击弹出提示";
            this.ucBtnExt6.ConerRadius = 10;
            this.ucBtnExt6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnExt6.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt6.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt6.IsRadius = true;
            this.ucBtnExt6.IsShowRect = false;
            this.ucBtnExt6.IsShowTips = false;
            this.ucBtnExt6.Location = new System.Drawing.Point(143, 89);
            this.ucBtnExt6.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt6.Name = "ucBtnExt6";
            this.ucBtnExt6.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt6.RectWidth = 1;
            this.ucBtnExt6.Size = new System.Drawing.Size(119, 46);
            this.ucBtnExt6.TabIndex = 16;
            this.ucBtnExt6.TabStop = false;
            this.ucBtnExt6.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt6.TipsText = "";
            this.ucBtnExt6.BtnClick += new System.EventHandler(this.ucBtnExt1_BtnClick);
            // 
            // ucBtnExt7
            // 
            this.ucBtnExt7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ucBtnExt7.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt7.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt7.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt7.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt7.BtnText = "点击弹出提示";
            this.ucBtnExt7.ConerRadius = 10;
            this.ucBtnExt7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucBtnExt7.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt7.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt7.IsRadius = true;
            this.ucBtnExt7.IsShowRect = false;
            this.ucBtnExt7.IsShowTips = false;
            this.ucBtnExt7.Location = new System.Drawing.Point(143, 447);
            this.ucBtnExt7.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt7.Name = "ucBtnExt7";
            this.ucBtnExt7.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt7.RectWidth = 1;
            this.ucBtnExt7.Size = new System.Drawing.Size(119, 46);
            this.ucBtnExt7.TabIndex = 17;
            this.ucBtnExt7.TabStop = false;
            this.ucBtnExt7.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt7.TipsText = "";
            this.ucBtnExt7.BtnClick += new System.EventHandler(this.ucBtnExt1_BtnClick);
            // 
            // ucBtnExt9
            // 
            this.ucBtnExt9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ucBtnExt9.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt9.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt9.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt9.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt9.BtnText = "点击弹出提示";
            this.ucBtnExt9.ConerRadius = 10;
            this.ucBtnExt9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucBtnExt9.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt9.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt9.IsRadius = true;
            this.ucBtnExt9.IsShowRect = false;
            this.ucBtnExt9.IsShowTips = false;
            this.ucBtnExt9.Location = new System.Drawing.Point(438, 447);
            this.ucBtnExt9.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt9.Name = "ucBtnExt9";
            this.ucBtnExt9.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt9.RectWidth = 1;
            this.ucBtnExt9.Size = new System.Drawing.Size(119, 46);
            this.ucBtnExt9.TabIndex = 18;
            this.ucBtnExt9.TabStop = false;
            this.ucBtnExt9.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt9.TipsText = "";
            this.ucBtnExt9.BtnClick += new System.EventHandler(this.ucBtnExt1_BtnClick);
            // 
            // ucBtnExt8
            // 
            this.ucBtnExt8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ucBtnExt8.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt8.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt8.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt8.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt8.BtnText = "点击弹出提示";
            this.ucBtnExt8.ConerRadius = 10;
            this.ucBtnExt8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucBtnExt8.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt8.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt8.IsRadius = true;
            this.ucBtnExt8.IsShowRect = false;
            this.ucBtnExt8.IsShowTips = false;
            this.ucBtnExt8.Location = new System.Drawing.Point(438, 89);
            this.ucBtnExt8.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt8.Name = "ucBtnExt8";
            this.ucBtnExt8.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt8.RectWidth = 1;
            this.ucBtnExt8.Size = new System.Drawing.Size(119, 46);
            this.ucBtnExt8.TabIndex = 19;
            this.ucBtnExt8.TabStop = false;
            this.ucBtnExt8.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt8.TipsText = "";
            this.ucBtnExt8.BtnClick += new System.EventHandler(this.ucBtnExt1_BtnClick);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(255, 287);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(221, 12);
            this.label1.TabIndex = 20;
            this.label1.Text = "点击不同颜色的按钮弹出对应颜色的提示";
            // 
            // UCTestTips
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ucBtnExt6);
            this.Controls.Add(this.ucBtnExt7);
            this.Controls.Add(this.ucBtnExt9);
            this.Controls.Add(this.ucBtnExt8);
            this.Name = "UCTestTips";
            this.Size = new System.Drawing.Size(730, 586);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private HZH_Controls.Controls.UCBtnExt ucBtnExt6;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt7;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt9;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt8;
        private System.Windows.Forms.Label label1;

    }
}

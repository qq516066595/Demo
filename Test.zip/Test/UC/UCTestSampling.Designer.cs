﻿namespace Test.UC
{
    partial class UCTestSampling
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCTestSampling));
            this.label1 = new System.Windows.Forms.Label();
            this.ucSampling6 = new HZH_Controls.Controls.UCSampling();
            this.ucSampling1 = new HZH_Controls.Controls.UCSampling();
            this.ucSampling5 = new HZH_Controls.Controls.UCSampling();
            this.ucSampling4 = new HZH_Controls.Controls.UCSampling();
            this.ucSampling2 = new HZH_Controls.Controls.UCSampling();
            this.ucSampling3 = new HZH_Controls.Controls.UCSampling();
            this.ucSampling7 = new HZH_Controls.Controls.UCSampling();
            this.ucSampling8 = new HZH_Controls.Controls.UCSampling();
            this.ucSampling9 = new HZH_Controls.Controls.UCSampling();
            this.ucSampling10 = new HZH_Controls.Controls.UCSampling();
            this.ucSampling11 = new HZH_Controls.Controls.UCSampling();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(65, 412);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(359, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "*该实例演示了采样控件根据设置的图片及参数得到有效的绘制区域\r\n你可以使用更好的图片来达到更出色的效果\r\n";
            // 
            // ucSampling6
            // 
            this.ucSampling6.Alpha = 50;
            this.ucSampling6.ColorThreshold = 13;
            this.ucSampling6.Location = new System.Drawing.Point(38, 3);
            this.ucSampling6.Name = "ucSampling6";
            this.ucSampling6.SamplingImag = ((System.Drawing.Bitmap)(resources.GetObject("ucSampling6.SamplingImag")));
            this.ucSampling6.Size = new System.Drawing.Size(350, 179);
            this.ucSampling6.TabIndex = 1;
            this.ucSampling6.Transparent = null;
            // 
            // ucSampling1
            // 
            this.ucSampling1.Alpha = 0;
            this.ucSampling1.ColorThreshold = 0;
            this.ucSampling1.Location = new System.Drawing.Point(669, 116);
            this.ucSampling1.Name = "ucSampling1";
            this.ucSampling1.SamplingImag = ((System.Drawing.Bitmap)(resources.GetObject("ucSampling1.SamplingImag")));
            this.ucSampling1.Size = new System.Drawing.Size(128, 128);
            this.ucSampling1.TabIndex = 1;
            this.ucSampling1.Transparent = null;
            // 
            // ucSampling5
            // 
            this.ucSampling5.Alpha = 50;
            this.ucSampling5.ColorThreshold = 12;
            this.ucSampling5.Location = new System.Drawing.Point(271, 130);
            this.ucSampling5.Name = "ucSampling5";
            this.ucSampling5.SamplingImag = ((System.Drawing.Bitmap)(resources.GetObject("ucSampling5.SamplingImag")));
            this.ucSampling5.Size = new System.Drawing.Size(350, 179);
            this.ucSampling5.TabIndex = 1;
            this.ucSampling5.Transparent = null;
            // 
            // ucSampling4
            // 
            this.ucSampling4.Alpha = 50;
            this.ucSampling4.ColorThreshold = 12;
            this.ucSampling4.Location = new System.Drawing.Point(74, 186);
            this.ucSampling4.Name = "ucSampling4";
            this.ucSampling4.SamplingImag = ((System.Drawing.Bitmap)(resources.GetObject("ucSampling4.SamplingImag")));
            this.ucSampling4.Size = new System.Drawing.Size(350, 179);
            this.ucSampling4.TabIndex = 1;
            this.ucSampling4.Transparent = null;
            // 
            // ucSampling2
            // 
            this.ucSampling2.Alpha = 0;
            this.ucSampling2.ColorThreshold = 0;
            this.ucSampling2.Location = new System.Drawing.Point(769, 212);
            this.ucSampling2.Name = "ucSampling2";
            this.ucSampling2.SamplingImag = ((System.Drawing.Bitmap)(resources.GetObject("ucSampling2.SamplingImag")));
            this.ucSampling2.Size = new System.Drawing.Size(128, 128);
            this.ucSampling2.TabIndex = 1;
            this.ucSampling2.Transparent = null;
            // 
            // ucSampling3
            // 
            this.ucSampling3.Alpha = 0;
            this.ucSampling3.ColorThreshold = 0;
            this.ucSampling3.Location = new System.Drawing.Point(862, 116);
            this.ucSampling3.Name = "ucSampling3";
            this.ucSampling3.SamplingImag = ((System.Drawing.Bitmap)(resources.GetObject("ucSampling3.SamplingImag")));
            this.ucSampling3.Size = new System.Drawing.Size(128, 128);
            this.ucSampling3.TabIndex = 1;
            this.ucSampling3.Transparent = null;
            // 
            // ucSampling7
            // 
            this.ucSampling7.Alpha = 0;
            this.ucSampling7.ColorThreshold = 10;
            this.ucSampling7.Location = new System.Drawing.Point(655, 460);
            this.ucSampling7.Name = "ucSampling7";
            this.ucSampling7.SamplingImag = ((System.Drawing.Bitmap)(resources.GetObject("ucSampling7.SamplingImag")));
            this.ucSampling7.Size = new System.Drawing.Size(218, 189);
            this.ucSampling7.TabIndex = 3;
            this.ucSampling7.Transparent = null;
            this.ucSampling7.Paint += new System.Windows.Forms.PaintEventHandler(this.ucSampling10_Paint);
            this.ucSampling7.MouseEnter += new System.EventHandler(this.ucSampling10_MouseEnter);
            this.ucSampling7.MouseLeave += new System.EventHandler(this.ucSampling10_MouseLeave);
            // 
            // ucSampling8
            // 
            this.ucSampling8.Alpha = 0;
            this.ucSampling8.ColorThreshold = 10;
            this.ucSampling8.Location = new System.Drawing.Point(659, 609);
            this.ucSampling8.Name = "ucSampling8";
            this.ucSampling8.SamplingImag = ((System.Drawing.Bitmap)(resources.GetObject("ucSampling8.SamplingImag")));
            this.ucSampling8.Size = new System.Drawing.Size(176, 199);
            this.ucSampling8.TabIndex = 4;
            this.ucSampling8.Transparent = null;
            this.ucSampling8.Paint += new System.Windows.Forms.PaintEventHandler(this.ucSampling10_Paint);
            this.ucSampling8.MouseEnter += new System.EventHandler(this.ucSampling10_MouseEnter);
            this.ucSampling8.MouseLeave += new System.EventHandler(this.ucSampling10_MouseLeave);
            // 
            // ucSampling9
            // 
            this.ucSampling9.Alpha = 0;
            this.ucSampling9.ColorThreshold = 10;
            this.ucSampling9.Location = new System.Drawing.Point(449, 609);
            this.ucSampling9.Name = "ucSampling9";
            this.ucSampling9.SamplingImag = ((System.Drawing.Bitmap)(resources.GetObject("ucSampling9.SamplingImag")));
            this.ucSampling9.Size = new System.Drawing.Size(215, 199);
            this.ucSampling9.TabIndex = 5;
            this.ucSampling9.Transparent = null;
            this.ucSampling9.Paint += new System.Windows.Forms.PaintEventHandler(this.ucSampling10_Paint);
            this.ucSampling9.MouseEnter += new System.EventHandler(this.ucSampling10_MouseEnter);
            this.ucSampling9.MouseLeave += new System.EventHandler(this.ucSampling10_MouseLeave);
            // 
            // ucSampling10
            // 
            this.ucSampling10.Alpha = 0;
            this.ucSampling10.ColorThreshold = 10;
            this.ucSampling10.Location = new System.Drawing.Point(409, 460);
            this.ucSampling10.Name = "ucSampling10";
            this.ucSampling10.SamplingImag = ((System.Drawing.Bitmap)(resources.GetObject("ucSampling10.SamplingImag")));
            this.ucSampling10.Size = new System.Drawing.Size(230, 203);
            this.ucSampling10.TabIndex = 6;
            this.ucSampling10.Transparent = null;
            this.ucSampling10.Paint += new System.Windows.Forms.PaintEventHandler(this.ucSampling10_Paint);
            this.ucSampling10.MouseEnter += new System.EventHandler(this.ucSampling10_MouseEnter);
            this.ucSampling10.MouseLeave += new System.EventHandler(this.ucSampling10_MouseLeave);
            // 
            // ucSampling11
            // 
            this.ucSampling11.Alpha = 0;
            this.ucSampling11.ColorThreshold = 10;
            this.ucSampling11.Location = new System.Drawing.Point(518, 394);
            this.ucSampling11.Name = "ucSampling11";
            this.ucSampling11.SamplingImag = ((System.Drawing.Bitmap)(resources.GetObject("ucSampling11.SamplingImag")));
            this.ucSampling11.Size = new System.Drawing.Size(250, 189);
            this.ucSampling11.TabIndex = 7;
            this.ucSampling11.Transparent = null;
            this.ucSampling11.Paint += new System.Windows.Forms.PaintEventHandler(this.ucSampling10_Paint);
            this.ucSampling11.MouseEnter += new System.EventHandler(this.ucSampling10_MouseEnter);
            this.ucSampling11.MouseLeave += new System.EventHandler(this.ucSampling10_MouseLeave);
            // 
            // UCTestSampling
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucSampling11);
            this.Controls.Add(this.ucSampling10);
            this.Controls.Add(this.ucSampling9);
            this.Controls.Add(this.ucSampling8);
            this.Controls.Add(this.ucSampling7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ucSampling6);
            this.Controls.Add(this.ucSampling3);
            this.Controls.Add(this.ucSampling2);
            this.Controls.Add(this.ucSampling1);
            this.Controls.Add(this.ucSampling5);
            this.Controls.Add(this.ucSampling4);
            this.Name = "UCTestSampling";
            this.Size = new System.Drawing.Size(1010, 821);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private HZH_Controls.Controls.UCSampling ucSampling4;
        private HZH_Controls.Controls.UCSampling ucSampling5;
        private HZH_Controls.Controls.UCSampling ucSampling6;
        private System.Windows.Forms.Label label1;
        private HZH_Controls.Controls.UCSampling ucSampling1;
        private HZH_Controls.Controls.UCSampling ucSampling2;
        private HZH_Controls.Controls.UCSampling ucSampling3;
        private HZH_Controls.Controls.UCSampling ucSampling7;
        private HZH_Controls.Controls.UCSampling ucSampling8;
        private HZH_Controls.Controls.UCSampling ucSampling9;
        private HZH_Controls.Controls.UCSampling ucSampling10;
        private HZH_Controls.Controls.UCSampling ucSampling11;


    }
}

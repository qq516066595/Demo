﻿namespace Test.UC
{
    partial class UCTestScrollbar
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("节点0");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("节点1");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("节点2");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("节点3");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("节点4");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("节点5");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("节点6");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("节点7");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("节点8");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("节点9");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("节点10");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("节点11");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("节点0", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4,
            treeNode5,
            treeNode6,
            treeNode7,
            treeNode8,
            treeNode9,
            treeNode10,
            treeNode11,
            treeNode12});
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("节点1");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("节点2");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("节点3");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("节点4");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("节点5");
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("节点6");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("节点7");
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("节点8");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("节点9");
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("节点10");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("节点11");
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("节点12");
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("节点13");
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("节点14");
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("节点15");
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("节点16");
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("节点17");
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("节点18");
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("节点19");
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("节点20");
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("节点21");
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("节点22");
            System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("节点23");
            System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("节点24");
            System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("节点25");
            System.Windows.Forms.TreeNode treeNode39 = new System.Windows.Forms.TreeNode("节点26");
            System.Windows.Forms.TreeNode treeNode40 = new System.Windows.Forms.TreeNode("节点27");
            System.Windows.Forms.TreeNode treeNode41 = new System.Windows.Forms.TreeNode("节点28");
            System.Windows.Forms.TreeNode treeNode42 = new System.Windows.Forms.TreeNode("节点29");
            System.Windows.Forms.TreeNode treeNode43 = new System.Windows.Forms.TreeNode("节点30");
            System.Windows.Forms.TreeNode treeNode44 = new System.Windows.Forms.TreeNode("节点31");
            System.Windows.Forms.TreeNode treeNode45 = new System.Windows.Forms.TreeNode("节点32");
            System.Windows.Forms.TreeNode treeNode46 = new System.Windows.Forms.TreeNode("节点33");
            System.Windows.Forms.TreeNode treeNode47 = new System.Windows.Forms.TreeNode("节点34");
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.uchScrollbar6 = new HZH_Controls.Controls.UCHScrollbar();
            this.uchScrollbar4 = new HZH_Controls.Controls.UCHScrollbar();
            this.uchScrollbar5 = new HZH_Controls.Controls.UCHScrollbar();
            this.uchScrollbar3 = new HZH_Controls.Controls.UCHScrollbar();
            this.uchScrollbar2 = new HZH_Controls.Controls.UCHScrollbar();
            this.uchScrollbar1 = new HZH_Controls.Controls.UCHScrollbar();
            this.ucvScrollbar6 = new HZH_Controls.Controls.UCVScrollbar();
            this.ucvScrollbar5 = new HZH_Controls.Controls.UCVScrollbar();
            this.ucvScrollbar4 = new HZH_Controls.Controls.UCVScrollbar();
            this.ucvScrollbar3 = new HZH_Controls.Controls.UCVScrollbar();
            this.ucvScrollbar2 = new HZH_Controls.Controls.UCVScrollbar();
            this.ucvScrollbar1 = new HZH_Controls.Controls.UCVScrollbar();
            this.scrollbarComponent1 = new HZH_Controls.Controls.ScrollbarComponent(this.components);
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(30, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(246, 93);
            this.panel1.TabIndex = 1;
            this.scrollbarComponent1.SetUserCustomScrollbar(this.panel1, true);
            this.panel1.VisibleChanged += new System.EventHandler(this.panel1_VisibleChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 432);
            this.label1.TabIndex = 0;
            this.label1.Text = "panel滚动条\r\n1\r\n2\r\n3\r\n4\r\n5\r\n6\r\n7\r\n8\r\n9\r\n1\r\n2\r\n3\r\n4\r\n5\r\n67\r\n8\r\n9\r\n1\r\n2\r\n3\r\n4\r\n5\r\n6\r\n7" +
    "\r\n8\r\n9\r\n1\r\n2\r\n3\r\n4\r\n5\r\n6\r\n7\r\n8\r\n7";
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(309, 22);
            this.treeView1.Name = "treeView1";
            treeNode1.Name = "节点0";
            treeNode1.Text = "节点0";
            treeNode2.Name = "节点1";
            treeNode2.Text = "节点1";
            treeNode3.Name = "节点2";
            treeNode3.Text = "节点2";
            treeNode4.Name = "节点3";
            treeNode4.Text = "节点3";
            treeNode5.Name = "节点4";
            treeNode5.Text = "节点4";
            treeNode6.Name = "节点5";
            treeNode6.Text = "节点5";
            treeNode7.Name = "节点6";
            treeNode7.Text = "节点6";
            treeNode8.Name = "节点7";
            treeNode8.Text = "节点7";
            treeNode9.Name = "节点8";
            treeNode9.Text = "节点8";
            treeNode10.Name = "节点9";
            treeNode10.Text = "节点9";
            treeNode11.Name = "节点10";
            treeNode11.Text = "节点10";
            treeNode12.Name = "节点11";
            treeNode12.Text = "节点11";
            treeNode13.Name = "节点0";
            treeNode13.Text = "节点0";
            treeNode14.Name = "节点1";
            treeNode14.Text = "节点1";
            treeNode15.Name = "节点2";
            treeNode15.Text = "节点2";
            treeNode16.Name = "节点3";
            treeNode16.Text = "节点3";
            treeNode17.Name = "节点4";
            treeNode17.Text = "节点4";
            treeNode18.Name = "节点5";
            treeNode18.Text = "节点5";
            treeNode19.Name = "节点6";
            treeNode19.Text = "节点6";
            treeNode20.Name = "节点7";
            treeNode20.Text = "节点7";
            treeNode21.Name = "节点8";
            treeNode21.Text = "节点8";
            treeNode22.Name = "节点9";
            treeNode22.Text = "节点9";
            treeNode23.Name = "节点10";
            treeNode23.Text = "节点10";
            treeNode24.Name = "节点11";
            treeNode24.Text = "节点11";
            treeNode25.Name = "节点12";
            treeNode25.Text = "节点12";
            treeNode26.Name = "节点13";
            treeNode26.Text = "节点13";
            treeNode27.Name = "节点14";
            treeNode27.Text = "节点14";
            treeNode28.Name = "节点15";
            treeNode28.Text = "节点15";
            treeNode29.Name = "节点16";
            treeNode29.Text = "节点16";
            treeNode30.Name = "节点17";
            treeNode30.Text = "节点17";
            treeNode31.Name = "节点18";
            treeNode31.Text = "节点18";
            treeNode32.Name = "节点19";
            treeNode32.Text = "节点19";
            treeNode33.Name = "节点20";
            treeNode33.Text = "节点20";
            treeNode34.Name = "节点21";
            treeNode34.Text = "节点21";
            treeNode35.Name = "节点22";
            treeNode35.Text = "节点22";
            treeNode36.Name = "节点23";
            treeNode36.Text = "节点23";
            treeNode37.Name = "节点24";
            treeNode37.Text = "节点24";
            treeNode38.Name = "节点25";
            treeNode38.Text = "节点25";
            treeNode39.Name = "节点26";
            treeNode39.Text = "节点26";
            treeNode40.Name = "节点27";
            treeNode40.Text = "节点27";
            treeNode41.Name = "节点28";
            treeNode41.Text = "节点28";
            treeNode42.Name = "节点29";
            treeNode42.Text = "节点29";
            treeNode43.Name = "节点30";
            treeNode43.Text = "节点30";
            treeNode44.Name = "节点31";
            treeNode44.Text = "节点31";
            treeNode45.Name = "节点32";
            treeNode45.Text = "节点32";
            treeNode46.Name = "节点33";
            treeNode46.Text = "节点33";
            treeNode47.Name = "节点34";
            treeNode47.Text = "节点34";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode13,
            treeNode14,
            treeNode15,
            treeNode16,
            treeNode17,
            treeNode18,
            treeNode19,
            treeNode20,
            treeNode21,
            treeNode22,
            treeNode23,
            treeNode24,
            treeNode25,
            treeNode26,
            treeNode27,
            treeNode28,
            treeNode29,
            treeNode30,
            treeNode31,
            treeNode32,
            treeNode33,
            treeNode34,
            treeNode35,
            treeNode36,
            treeNode37,
            treeNode38,
            treeNode39,
            treeNode40,
            treeNode41,
            treeNode42,
            treeNode43,
            treeNode44,
            treeNode45,
            treeNode46,
            treeNode47});
            this.treeView1.Size = new System.Drawing.Size(159, 97);
            this.treeView1.TabIndex = 2;
            this.scrollbarComponent1.SetUserCustomScrollbar(this.treeView1, true);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("宋体", 9F);
            this.textBox1.Location = new System.Drawing.Point(504, 22);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(151, 93);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = "Textbox滚动条\r\n支持上下键，滑轮，文字改变\r\n1\r\n2\r\n3\r\n4\r\n5\r\n6\r\n7\r\n8\r\n9\r\n1\r\n2\r\n3\r\n4\r\n5\r\n67\r\n8\r\n9\r\n1\r" +
    "\n2\r\n3\r\n4\r\n5\r\n6\r\n7\r\n8\r\n9\r\n1\r\n2\r\n3\r\n4\r\n5\r\n6\r\n7\r\n8\r\n7\r\n";
            this.scrollbarComponent1.SetUserCustomScrollbar(this.textBox1, true);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Items.AddRange(new object[] {
            "listbox滚动条",
            "1",
            "2",
            "3",
            "3",
            "4",
            "45",
            "35",
            "23",
            "452542",
            "54",
            "23",
            "45",
            "345",
            "236",
            "425",
            "46",
            "2545",
            "43",
            "534",
            "5",
            "235",
            "5445",
            "2324"});
            this.listBox1.Location = new System.Drawing.Point(965, 22);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(109, 220);
            this.listBox1.TabIndex = 7;
            this.scrollbarComponent1.SetUserCustomScrollbar(this.listBox1, true);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(920, 268);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(277, 211);
            this.dataGridView1.TabIndex = 8;
            this.scrollbarComponent1.SetUserCustomScrollbar(this.dataGridView1, true);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(899, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "Panel滚动条aaaaaaaaaaaaaaaaaaaaaabbbbbbbbbbbbbbbbbbbbbbbbbbbbccccccccccccccccccccccc" +
    "cdddddddddddddddddddddddeeeeeeeeeeeeeeeeeefffffffffffffffffffffff";
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(701, 22);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(246, 93);
            this.panel2.TabIndex = 6;
            this.scrollbarComponent1.SetUserCustomScrollbar(this.panel2, true);
            // 
            // uchScrollbar6
            // 
            this.uchScrollbar6.BtnWidth = 18;
            this.uchScrollbar6.ConerRadius = 10;
            this.uchScrollbar6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.uchScrollbar6.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.uchScrollbar6.IsRadius = true;
            this.uchScrollbar6.IsShowRect = false;
            this.uchScrollbar6.LargeChange = 10;
            this.uchScrollbar6.Location = new System.Drawing.Point(504, 488);
            this.uchScrollbar6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uchScrollbar6.Maximum = 100;
            this.uchScrollbar6.Minimum = 0;
            this.uchScrollbar6.MinimumSize = new System.Drawing.Size(0, 10);
            this.uchScrollbar6.Name = "uchScrollbar6";
            this.uchScrollbar6.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.uchScrollbar6.RectWidth = 1;
            this.uchScrollbar6.Size = new System.Drawing.Size(375, 22);
            this.uchScrollbar6.SmallChange = 5;
            this.uchScrollbar6.TabIndex = 5;
            this.uchScrollbar6.ThumbColor = System.Drawing.Color.White;
            this.uchScrollbar6.Value = 0;
            // 
            // uchScrollbar4
            // 
            this.uchScrollbar4.BtnWidth = 18;
            this.uchScrollbar4.ConerRadius = 10;
            this.uchScrollbar4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.uchScrollbar4.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.uchScrollbar4.IsRadius = true;
            this.uchScrollbar4.IsShowRect = false;
            this.uchScrollbar4.LargeChange = 10;
            this.uchScrollbar4.Location = new System.Drawing.Point(504, 360);
            this.uchScrollbar4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uchScrollbar4.Maximum = 100;
            this.uchScrollbar4.Minimum = 0;
            this.uchScrollbar4.MinimumSize = new System.Drawing.Size(0, 10);
            this.uchScrollbar4.Name = "uchScrollbar4";
            this.uchScrollbar4.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.uchScrollbar4.RectWidth = 1;
            this.uchScrollbar4.Size = new System.Drawing.Size(375, 22);
            this.uchScrollbar4.SmallChange = 5;
            this.uchScrollbar4.TabIndex = 5;
            this.uchScrollbar4.ThumbColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.uchScrollbar4.Value = 0;
            // 
            // uchScrollbar5
            // 
            this.uchScrollbar5.BtnWidth = 18;
            this.uchScrollbar5.ConerRadius = 7;
            this.uchScrollbar5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.uchScrollbar5.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.uchScrollbar5.IsRadius = true;
            this.uchScrollbar5.IsShowRect = false;
            this.uchScrollbar5.LargeChange = 10;
            this.uchScrollbar5.Location = new System.Drawing.Point(504, 426);
            this.uchScrollbar5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uchScrollbar5.Maximum = 100;
            this.uchScrollbar5.Minimum = 0;
            this.uchScrollbar5.MinimumSize = new System.Drawing.Size(0, 10);
            this.uchScrollbar5.Name = "uchScrollbar5";
            this.uchScrollbar5.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.uchScrollbar5.RectWidth = 1;
            this.uchScrollbar5.Size = new System.Drawing.Size(375, 18);
            this.uchScrollbar5.SmallChange = 5;
            this.uchScrollbar5.TabIndex = 5;
            this.uchScrollbar5.ThumbColor = System.Drawing.Color.White;
            this.uchScrollbar5.Value = 0;
            // 
            // uchScrollbar3
            // 
            this.uchScrollbar3.BtnWidth = 18;
            this.uchScrollbar3.ConerRadius = 7;
            this.uchScrollbar3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.uchScrollbar3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.uchScrollbar3.IsRadius = true;
            this.uchScrollbar3.IsShowRect = false;
            this.uchScrollbar3.LargeChange = 10;
            this.uchScrollbar3.Location = new System.Drawing.Point(504, 298);
            this.uchScrollbar3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uchScrollbar3.Maximum = 100;
            this.uchScrollbar3.Minimum = 0;
            this.uchScrollbar3.MinimumSize = new System.Drawing.Size(0, 10);
            this.uchScrollbar3.Name = "uchScrollbar3";
            this.uchScrollbar3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.uchScrollbar3.RectWidth = 1;
            this.uchScrollbar3.Size = new System.Drawing.Size(375, 18);
            this.uchScrollbar3.SmallChange = 5;
            this.uchScrollbar3.TabIndex = 5;
            this.uchScrollbar3.ThumbColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.uchScrollbar3.Value = 0;
            // 
            // uchScrollbar2
            // 
            this.uchScrollbar2.BtnWidth = 18;
            this.uchScrollbar2.ConerRadius = 2;
            this.uchScrollbar2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.uchScrollbar2.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.uchScrollbar2.IsRadius = true;
            this.uchScrollbar2.IsShowRect = false;
            this.uchScrollbar2.LargeChange = 10;
            this.uchScrollbar2.Location = new System.Drawing.Point(504, 232);
            this.uchScrollbar2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uchScrollbar2.Maximum = 100;
            this.uchScrollbar2.Minimum = 0;
            this.uchScrollbar2.MinimumSize = new System.Drawing.Size(0, 10);
            this.uchScrollbar2.Name = "uchScrollbar2";
            this.uchScrollbar2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.uchScrollbar2.RectWidth = 1;
            this.uchScrollbar2.Size = new System.Drawing.Size(375, 22);
            this.uchScrollbar2.SmallChange = 5;
            this.uchScrollbar2.TabIndex = 5;
            this.uchScrollbar2.ThumbColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.uchScrollbar2.Value = 0;
            // 
            // uchScrollbar1
            // 
            this.uchScrollbar1.BtnWidth = 18;
            this.uchScrollbar1.ConerRadius = 2;
            this.uchScrollbar1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.uchScrollbar1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.uchScrollbar1.IsRadius = true;
            this.uchScrollbar1.IsShowRect = false;
            this.uchScrollbar1.LargeChange = 10;
            this.uchScrollbar1.Location = new System.Drawing.Point(504, 170);
            this.uchScrollbar1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uchScrollbar1.Maximum = 100;
            this.uchScrollbar1.Minimum = 0;
            this.uchScrollbar1.MinimumSize = new System.Drawing.Size(0, 10);
            this.uchScrollbar1.Name = "uchScrollbar1";
            this.uchScrollbar1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.uchScrollbar1.RectWidth = 1;
            this.uchScrollbar1.Size = new System.Drawing.Size(375, 18);
            this.uchScrollbar1.SmallChange = 5;
            this.uchScrollbar1.TabIndex = 5;
            this.uchScrollbar1.ThumbColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.uchScrollbar1.Value = 0;
            // 
            // ucvScrollbar6
            // 
            this.ucvScrollbar6.BtnHeight = 18;
            this.ucvScrollbar6.ConerRadius = 10;
            this.ucvScrollbar6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucvScrollbar6.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucvScrollbar6.IsRadius = true;
            this.ucvScrollbar6.IsShowRect = false;
            this.ucvScrollbar6.LargeChange = 10;
            this.ucvScrollbar6.Location = new System.Drawing.Point(422, 170);
            this.ucvScrollbar6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucvScrollbar6.Maximum = 100;
            this.ucvScrollbar6.Minimum = 0;
            this.ucvScrollbar6.MinimumSize = new System.Drawing.Size(10, 0);
            this.ucvScrollbar6.Name = "ucvScrollbar6";
            this.ucvScrollbar6.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucvScrollbar6.RectWidth = 1;
            this.ucvScrollbar6.Size = new System.Drawing.Size(23, 343);
            this.ucvScrollbar6.SmallChange = 5;
            this.ucvScrollbar6.TabIndex = 4;
            this.ucvScrollbar6.ThumbColor = System.Drawing.Color.White;
            this.ucvScrollbar6.Value = 0;
            // 
            // ucvScrollbar5
            // 
            this.ucvScrollbar5.BtnHeight = 18;
            this.ucvScrollbar5.ConerRadius = 7;
            this.ucvScrollbar5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucvScrollbar5.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucvScrollbar5.IsRadius = true;
            this.ucvScrollbar5.IsShowRect = false;
            this.ucvScrollbar5.LargeChange = 10;
            this.ucvScrollbar5.Location = new System.Drawing.Point(346, 170);
            this.ucvScrollbar5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucvScrollbar5.Maximum = 100;
            this.ucvScrollbar5.Minimum = 0;
            this.ucvScrollbar5.MinimumSize = new System.Drawing.Size(10, 0);
            this.ucvScrollbar5.Name = "ucvScrollbar5";
            this.ucvScrollbar5.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucvScrollbar5.RectWidth = 1;
            this.ucvScrollbar5.Size = new System.Drawing.Size(18, 343);
            this.ucvScrollbar5.SmallChange = 5;
            this.ucvScrollbar5.TabIndex = 4;
            this.ucvScrollbar5.ThumbColor = System.Drawing.Color.White;
            this.ucvScrollbar5.Value = 0;
            // 
            // ucvScrollbar4
            // 
            this.ucvScrollbar4.BtnHeight = 18;
            this.ucvScrollbar4.ConerRadius = 10;
            this.ucvScrollbar4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.ucvScrollbar4.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucvScrollbar4.IsRadius = true;
            this.ucvScrollbar4.IsShowRect = false;
            this.ucvScrollbar4.LargeChange = 10;
            this.ucvScrollbar4.Location = new System.Drawing.Point(270, 170);
            this.ucvScrollbar4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucvScrollbar4.Maximum = 100;
            this.ucvScrollbar4.Minimum = 0;
            this.ucvScrollbar4.MinimumSize = new System.Drawing.Size(10, 0);
            this.ucvScrollbar4.Name = "ucvScrollbar4";
            this.ucvScrollbar4.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucvScrollbar4.RectWidth = 1;
            this.ucvScrollbar4.Size = new System.Drawing.Size(23, 343);
            this.ucvScrollbar4.SmallChange = 5;
            this.ucvScrollbar4.TabIndex = 4;
            this.ucvScrollbar4.ThumbColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucvScrollbar4.Value = 0;
            // 
            // ucvScrollbar3
            // 
            this.ucvScrollbar3.BtnHeight = 18;
            this.ucvScrollbar3.ConerRadius = 7;
            this.ucvScrollbar3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.ucvScrollbar3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucvScrollbar3.IsRadius = true;
            this.ucvScrollbar3.IsShowRect = false;
            this.ucvScrollbar3.LargeChange = 10;
            this.ucvScrollbar3.Location = new System.Drawing.Point(194, 170);
            this.ucvScrollbar3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucvScrollbar3.Maximum = 100;
            this.ucvScrollbar3.Minimum = 0;
            this.ucvScrollbar3.MinimumSize = new System.Drawing.Size(10, 0);
            this.ucvScrollbar3.Name = "ucvScrollbar3";
            this.ucvScrollbar3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucvScrollbar3.RectWidth = 1;
            this.ucvScrollbar3.Size = new System.Drawing.Size(18, 343);
            this.ucvScrollbar3.SmallChange = 5;
            this.ucvScrollbar3.TabIndex = 4;
            this.ucvScrollbar3.ThumbColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucvScrollbar3.Value = 0;
            // 
            // ucvScrollbar2
            // 
            this.ucvScrollbar2.BtnHeight = 18;
            this.ucvScrollbar2.ConerRadius = 2;
            this.ucvScrollbar2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.ucvScrollbar2.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucvScrollbar2.IsRadius = true;
            this.ucvScrollbar2.IsShowRect = false;
            this.ucvScrollbar2.LargeChange = 10;
            this.ucvScrollbar2.Location = new System.Drawing.Point(111, 170);
            this.ucvScrollbar2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucvScrollbar2.Maximum = 100;
            this.ucvScrollbar2.Minimum = 0;
            this.ucvScrollbar2.MinimumSize = new System.Drawing.Size(10, 0);
            this.ucvScrollbar2.Name = "ucvScrollbar2";
            this.ucvScrollbar2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucvScrollbar2.RectWidth = 1;
            this.ucvScrollbar2.Size = new System.Drawing.Size(24, 343);
            this.ucvScrollbar2.SmallChange = 5;
            this.ucvScrollbar2.TabIndex = 4;
            this.ucvScrollbar2.ThumbColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucvScrollbar2.Value = 0;
            // 
            // ucvScrollbar1
            // 
            this.ucvScrollbar1.BtnHeight = 18;
            this.ucvScrollbar1.ConerRadius = 2;
            this.ucvScrollbar1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.ucvScrollbar1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucvScrollbar1.IsRadius = true;
            this.ucvScrollbar1.IsShowRect = false;
            this.ucvScrollbar1.LargeChange = 10;
            this.ucvScrollbar1.Location = new System.Drawing.Point(35, 170);
            this.ucvScrollbar1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucvScrollbar1.Maximum = 100;
            this.ucvScrollbar1.Minimum = 0;
            this.ucvScrollbar1.MinimumSize = new System.Drawing.Size(10, 0);
            this.ucvScrollbar1.Name = "ucvScrollbar1";
            this.ucvScrollbar1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucvScrollbar1.RectWidth = 1;
            this.ucvScrollbar1.Size = new System.Drawing.Size(18, 343);
            this.ucvScrollbar1.SmallChange = 5;
            this.ucvScrollbar1.TabIndex = 4;
            this.ucvScrollbar1.ThumbColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucvScrollbar1.Value = 0;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.label3);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(1093, 19);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(159, 223);
            this.flowLayoutPanel1.TabIndex = 9;
            this.scrollbarComponent1.SetUserCustomScrollbar(this.flowLayoutPanel1, true);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 432);
            this.label3.TabIndex = 1;
            this.label3.Text = "panel滚动条\r\n1\r\n2\r\n3\r\n4\r\n5\r\n6\r\n7\r\n8\r\n9\r\n1\r\n2\r\n3\r\n4\r\n5\r\n67\r\n8\r\n9\r\n1\r\n2\r\n3\r\n4\r\n5\r\n6\r\n7" +
    "\r\n8\r\n9\r\n1\r\n2\r\n3\r\n4\r\n5\r\n6\r\n7\r\n8\r\n7";
            // 
            // UCTestScrollbar
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.uchScrollbar6);
            this.Controls.Add(this.uchScrollbar4);
            this.Controls.Add(this.uchScrollbar5);
            this.Controls.Add(this.uchScrollbar3);
            this.Controls.Add(this.uchScrollbar2);
            this.Controls.Add(this.uchScrollbar1);
            this.Controls.Add(this.ucvScrollbar6);
            this.Controls.Add(this.ucvScrollbar5);
            this.Controls.Add(this.ucvScrollbar4);
            this.Controls.Add(this.ucvScrollbar3);
            this.Controls.Add(this.ucvScrollbar2);
            this.Controls.Add(this.ucvScrollbar1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.panel1);
            this.Name = "UCTestScrollbar";
            this.Size = new System.Drawing.Size(1296, 569);
            this.Load += new System.EventHandler(this.UCTestScrollbar_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.TextBox textBox1;
        private HZH_Controls.Controls.UCVScrollbar ucvScrollbar1;
        private HZH_Controls.Controls.UCVScrollbar ucvScrollbar2;
        private HZH_Controls.Controls.UCVScrollbar ucvScrollbar3;
        private HZH_Controls.Controls.UCVScrollbar ucvScrollbar4;
        private HZH_Controls.Controls.UCVScrollbar ucvScrollbar5;
        private HZH_Controls.Controls.UCVScrollbar ucvScrollbar6;
        private HZH_Controls.Controls.UCHScrollbar uchScrollbar1;
        private HZH_Controls.Controls.UCHScrollbar uchScrollbar2;
        private HZH_Controls.Controls.UCHScrollbar uchScrollbar3;
        private HZH_Controls.Controls.UCHScrollbar uchScrollbar4;
        private HZH_Controls.Controls.UCHScrollbar uchScrollbar5;
        private HZH_Controls.Controls.UCHScrollbar uchScrollbar6;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private HZH_Controls.Controls.ScrollbarComponent scrollbarComponent1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label3;
    }
}

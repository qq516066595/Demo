﻿namespace Test.UC
{
    partial class UCTestConduit
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucValve1 = new HZH_Controls.Controls.UCValve();
            this.ucConduit9 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit22 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit24 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit23 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit8 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit7 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit6 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit3 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit4 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit2 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit18 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit17 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit1 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit19 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit20 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit21 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit25 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit14 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit30 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit12 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit27 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit11 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit29 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit28 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit26 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit5 = new HZH_Controls.Controls.UCConduit();
            this.ucConduit10 = new HZH_Controls.Controls.UCConduit();
            this.ucBottle2 = new HZH_Controls.Controls.UCBottle();
            this.ucBottle1 = new HZH_Controls.Controls.UCBottle();
            this.ucPond2 = new HZH_Controls.Controls.UCPond();
            this.ucBlower4 = new HZH_Controls.Controls.UCBlower();
            this.SuspendLayout();
            // 
            // ucValve1
            // 
            this.ucValve1.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve1.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve1.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve1.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucValve1.LiquidSpeed = 100;
            this.ucValve1.Location = new System.Drawing.Point(768, 264);
            this.ucValve1.Name = "ucValve1";
            this.ucValve1.Opened = true;
            this.ucValve1.Size = new System.Drawing.Size(169, 98);
            this.ucValve1.SwitchColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucValve1.TabIndex = 60;
            this.ucValve1.ValveColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucValve1.ValveStyle = HZH_Controls.Controls.ValveStyle.Horizontal_Top;
            // 
            // ucConduit9
            // 
            this.ucConduit9.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit9.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Down_Down;
            this.ucConduit9.ConduitWidth = 50;
            this.ucConduit9.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit9.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Forward;
            this.ucConduit9.LiquidSpeed = 100;
            this.ucConduit9.Location = new System.Drawing.Point(5, 276);
            this.ucConduit9.Name = "ucConduit9";
            this.ucConduit9.Size = new System.Drawing.Size(196, 37);
            this.ucConduit9.TabIndex = 27;
            // 
            // ucConduit22
            // 
            this.ucConduit22.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit22.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit22.ConduitWidth = 50;
            this.ucConduit22.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit22.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit22.LiquidSpeed = 100;
            this.ucConduit22.Location = new System.Drawing.Point(6, 313);
            this.ucConduit22.Name = "ucConduit22";
            this.ucConduit22.Size = new System.Drawing.Size(37, 186);
            this.ucConduit22.TabIndex = 45;
            // 
            // ucConduit24
            // 
            this.ucConduit24.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit24.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Up_None;
            this.ucConduit24.ConduitWidth = 50;
            this.ucConduit24.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit24.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit24.LiquidSpeed = 100;
            this.ucConduit24.Location = new System.Drawing.Point(142, 567);
            this.ucConduit24.Name = "ucConduit24";
            this.ucConduit24.Size = new System.Drawing.Size(65, 37);
            this.ucConduit24.TabIndex = 46;
            // 
            // ucConduit23
            // 
            this.ucConduit23.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit23.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Down_Down;
            this.ucConduit23.ConduitWidth = 50;
            this.ucConduit23.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit23.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit23.LiquidSpeed = 100;
            this.ucConduit23.Location = new System.Drawing.Point(72, 462);
            this.ucConduit23.Name = "ucConduit23";
            this.ucConduit23.Size = new System.Drawing.Size(108, 37);
            this.ucConduit23.TabIndex = 44;
            // 
            // ucConduit8
            // 
            this.ucConduit8.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit8.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Up_Up;
            this.ucConduit8.ConduitWidth = 50;
            this.ucConduit8.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit8.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit8.LiquidSpeed = 100;
            this.ucConduit8.Location = new System.Drawing.Point(5, 499);
            this.ucConduit8.Name = "ucConduit8";
            this.ucConduit8.Size = new System.Drawing.Size(105, 37);
            this.ucConduit8.TabIndex = 43;
            // 
            // ucConduit7
            // 
            this.ucConduit7.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit7.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Down_Up;
            this.ucConduit7.ConduitWidth = 50;
            this.ucConduit7.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit7.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Forward;
            this.ucConduit7.LiquidSpeed = 50;
            this.ucConduit7.Location = new System.Drawing.Point(34, 55);
            this.ucConduit7.Name = "ucConduit7";
            this.ucConduit7.Size = new System.Drawing.Size(310, 37);
            this.ucConduit7.TabIndex = 42;
            // 
            // ucConduit6
            // 
            this.ucConduit6.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit6.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Down_Up;
            this.ucConduit6.ConduitWidth = 50;
            this.ucConduit6.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit6.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Forward;
            this.ucConduit6.LiquidSpeed = 50;
            this.ucConduit6.Location = new System.Drawing.Point(624, 276);
            this.ucConduit6.Name = "ucConduit6";
            this.ucConduit6.Size = new System.Drawing.Size(127, 37);
            this.ucConduit6.TabIndex = 41;
            // 
            // ucConduit3
            // 
            this.ucConduit3.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit3.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Down_None;
            this.ucConduit3.ConduitWidth = 50;
            this.ucConduit3.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit3.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Forward;
            this.ucConduit3.LiquidSpeed = 50;
            this.ucConduit3.Location = new System.Drawing.Point(306, 18);
            this.ucConduit3.Name = "ucConduit3";
            this.ucConduit3.Size = new System.Drawing.Size(496, 37);
            this.ucConduit3.TabIndex = 40;
            // 
            // ucConduit4
            // 
            this.ucConduit4.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit4.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_Up;
            this.ucConduit4.ConduitWidth = 50;
            this.ucConduit4.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit4.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit4.LiquidSpeed = 50;
            this.ucConduit4.Location = new System.Drawing.Point(935, 313);
            this.ucConduit4.Name = "ucConduit4";
            this.ucConduit4.Size = new System.Drawing.Size(87, 37);
            this.ucConduit4.TabIndex = 39;
            // 
            // ucConduit2
            // 
            this.ucConduit2.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit2.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Up_None;
            this.ucConduit2.ConduitWidth = 50;
            this.ucConduit2.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit2.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit2.LiquidSpeed = 50;
            this.ucConduit2.Location = new System.Drawing.Point(624, 313);
            this.ucConduit2.Name = "ucConduit2";
            this.ucConduit2.Size = new System.Drawing.Size(144, 37);
            this.ucConduit2.TabIndex = 39;
            // 
            // ucConduit18
            // 
            this.ucConduit18.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit18.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_Right_Right;
            this.ucConduit18.ConduitWidth = 50;
            this.ucConduit18.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit18.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Forward;
            this.ucConduit18.LiquidSpeed = 50;
            this.ucConduit18.Location = new System.Drawing.Point(545, 193);
            this.ucConduit18.Name = "ucConduit18";
            this.ucConduit18.Size = new System.Drawing.Size(37, 193);
            this.ucConduit18.TabIndex = 38;
            // 
            // ucConduit17
            // 
            this.ucConduit17.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit17.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_Left_Left;
            this.ucConduit17.ConduitWidth = 50;
            this.ucConduit17.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit17.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Forward;
            this.ucConduit17.LiquidSpeed = 50;
            this.ucConduit17.Location = new System.Drawing.Point(582, 348);
            this.ucConduit17.Name = "ucConduit17";
            this.ucConduit17.Size = new System.Drawing.Size(37, 134);
            this.ucConduit17.TabIndex = 37;
            // 
            // ucConduit1
            // 
            this.ucConduit1.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit1.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit1.ConduitWidth = 50;
            this.ucConduit1.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit1.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit1.LiquidSpeed = 50;
            this.ucConduit1.Location = new System.Drawing.Point(581, 194);
            this.ucConduit1.Name = "ucConduit1";
            this.ucConduit1.Size = new System.Drawing.Size(136, 37);
            this.ucConduit1.TabIndex = 52;
            // 
            // ucConduit19
            // 
            this.ucConduit19.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit19.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_Left_Left;
            this.ucConduit19.ConduitWidth = 50;
            this.ucConduit19.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit19.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit19.LiquidSpeed = 50;
            this.ucConduit19.Location = new System.Drawing.Point(451, 285);
            this.ucConduit19.Name = "ucConduit19";
            this.ucConduit19.Size = new System.Drawing.Size(37, 125);
            this.ucConduit19.TabIndex = 34;
            // 
            // ucConduit20
            // 
            this.ucConduit20.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit20.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit20.ConduitWidth = 50;
            this.ucConduit20.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit20.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Forward;
            this.ucConduit20.LiquidSpeed = 100;
            this.ucConduit20.Location = new System.Drawing.Point(201, 373);
            this.ucConduit20.Name = "ucConduit20";
            this.ucConduit20.Size = new System.Drawing.Size(250, 37);
            this.ucConduit20.TabIndex = 33;
            // 
            // ucConduit21
            // 
            this.ucConduit21.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit21.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_Right;
            this.ucConduit21.ConduitWidth = 50;
            this.ucConduit21.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit21.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Forward;
            this.ucConduit21.LiquidSpeed = 100;
            this.ucConduit21.Location = new System.Drawing.Point(164, 309);
            this.ucConduit21.Name = "ucConduit21";
            this.ucConduit21.Size = new System.Drawing.Size(37, 101);
            this.ucConduit21.TabIndex = 36;
            // 
            // ucConduit25
            // 
            this.ucConduit25.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit25.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_None;
            this.ucConduit25.ConduitWidth = 50;
            this.ucConduit25.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit25.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit25.LiquidSpeed = 100;
            this.ucConduit25.Location = new System.Drawing.Point(143, 499);
            this.ucConduit25.Name = "ucConduit25";
            this.ucConduit25.Size = new System.Drawing.Size(37, 69);
            this.ucConduit25.TabIndex = 35;
            // 
            // ucConduit14
            // 
            this.ucConduit14.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit14.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_Right;
            this.ucConduit14.ConduitWidth = 50;
            this.ucConduit14.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit14.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit14.LiquidSpeed = 50;
            this.ucConduit14.Location = new System.Drawing.Point(414, 244);
            this.ucConduit14.Name = "ucConduit14";
            this.ucConduit14.Size = new System.Drawing.Size(37, 79);
            this.ucConduit14.TabIndex = 32;
            // 
            // ucConduit30
            // 
            this.ucConduit30.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit30.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_None_Right;
            this.ucConduit30.ConduitWidth = 50;
            this.ucConduit30.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit30.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit30.LiquidSpeed = 50;
            this.ucConduit30.Location = new System.Drawing.Point(35, 88);
            this.ucConduit30.Name = "ucConduit30";
            this.ucConduit30.Size = new System.Drawing.Size(37, 156);
            this.ucConduit30.TabIndex = 31;
            // 
            // ucConduit12
            // 
            this.ucConduit12.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit12.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_Right_None;
            this.ucConduit12.ConduitWidth = 50;
            this.ucConduit12.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit12.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Forward;
            this.ucConduit12.LiquidSpeed = 50;
            this.ucConduit12.Location = new System.Drawing.Point(451, 444);
            this.ucConduit12.Name = "ucConduit12";
            this.ucConduit12.Size = new System.Drawing.Size(37, 92);
            this.ucConduit12.TabIndex = 30;
            // 
            // ucConduit27
            // 
            this.ucConduit27.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit27.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_None;
            this.ucConduit27.ConduitWidth = 50;
            this.ucConduit27.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit27.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit27.LiquidSpeed = 50;
            this.ucConduit27.Location = new System.Drawing.Point(486, 445);
            this.ucConduit27.Name = "ucConduit27";
            this.ucConduit27.Size = new System.Drawing.Size(97, 37);
            this.ucConduit27.TabIndex = 29;
            // 
            // ucConduit11
            // 
            this.ucConduit11.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit11.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_Left_None;
            this.ucConduit11.ConduitWidth = 50;
            this.ucConduit11.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit11.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit11.LiquidSpeed = 50;
            this.ucConduit11.Location = new System.Drawing.Point(714, 193);
            this.ucConduit11.Name = "ucConduit11";
            this.ucConduit11.Size = new System.Drawing.Size(37, 83);
            this.ucConduit11.TabIndex = 28;
            // 
            // ucConduit29
            // 
            this.ucConduit29.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit29.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_Tilt_Left;
            this.ucConduit29.ConduitWidth = 37;
            this.ucConduit29.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit29.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Forward;
            this.ucConduit29.LiquidSpeed = 37;
            this.ucConduit29.Location = new System.Drawing.Point(816, 158);
            this.ucConduit29.Name = "ucConduit29";
            this.ucConduit29.Size = new System.Drawing.Size(275, 73);
            this.ucConduit29.TabIndex = 51;
            // 
            // ucConduit28
            // 
            this.ucConduit28.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit28.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Vertical_Tilt_Right;
            this.ucConduit28.ConduitWidth = 37;
            this.ucConduit28.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit28.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Forward;
            this.ucConduit28.LiquidSpeed = 37;
            this.ucConduit28.Location = new System.Drawing.Point(984, 231);
            this.ucConduit28.Name = "ucConduit28";
            this.ucConduit28.Size = new System.Drawing.Size(107, 82);
            this.ucConduit28.TabIndex = 50;
            // 
            // ucConduit26
            // 
            this.ucConduit26.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit26.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Tilt_Up;
            this.ucConduit26.ConduitWidth = 37;
            this.ucConduit26.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit26.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Forward;
            this.ucConduit26.LiquidSpeed = 37;
            this.ucConduit26.Location = new System.Drawing.Point(72, 124);
            this.ucConduit26.Name = "ucConduit26";
            this.ucConduit26.Size = new System.Drawing.Size(86, 120);
            this.ucConduit26.TabIndex = 49;
            // 
            // ucConduit5
            // 
            this.ucConduit5.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit5.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_Tilt_Down;
            this.ucConduit5.ConduitWidth = 37;
            this.ucConduit5.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit5.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit5.LiquidSpeed = 37;
            this.ucConduit5.Location = new System.Drawing.Point(157, 124);
            this.ucConduit5.Name = "ucConduit5";
            this.ucConduit5.Size = new System.Drawing.Size(133, 120);
            this.ucConduit5.TabIndex = 48;
            // 
            // ucConduit10
            // 
            this.ucConduit10.ConduitColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConduit10.ConduitStyle = HZH_Controls.Controls.ConduitStyle.Horizontal_None_Down;
            this.ucConduit10.ConduitWidth = 50;
            this.ucConduit10.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucConduit10.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucConduit10.LiquidSpeed = 50;
            this.ucConduit10.Location = new System.Drawing.Point(290, 207);
            this.ucConduit10.Name = "ucConduit10";
            this.ucConduit10.Size = new System.Drawing.Size(161, 37);
            this.ucConduit10.TabIndex = 47;
            // 
            // ucBottle2
            // 
            this.ucBottle2.BottleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBottle2.BottleMouthColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.ucBottle2.Direction = HZH_Controls.Controls.Direction.Up;
            this.ucBottle2.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBottle2.Location = new System.Drawing.Point(1011, 39);
            this.ucBottle2.MaxValue = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.ucBottle2.Name = "ucBottle2";
            this.ucBottle2.NO = "1#";
            this.ucBottle2.Size = new System.Drawing.Size(36, 119);
            this.ucBottle2.TabIndex = 53;
            this.ucBottle2.Title = "";
            this.ucBottle2.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // ucBottle1
            // 
            this.ucBottle1.BottleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBottle1.BottleMouthColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.ucBottle1.Direction = HZH_Controls.Controls.Direction.Down;
            this.ucBottle1.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBottle1.Location = new System.Drawing.Point(798, 8);
            this.ucBottle1.MaxValue = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.ucBottle1.Name = "ucBottle1";
            this.ucBottle1.NO = "1#";
            this.ucBottle1.Size = new System.Drawing.Size(73, 150);
            this.ucBottle1.TabIndex = 53;
            this.ucBottle1.Title = "";
            this.ucBottle1.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // ucPond2
            // 
            this.ucPond2.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucPond2.Location = new System.Drawing.Point(320, 529);
            this.ucPond2.MaxValue = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.ucPond2.Name = "ucPond2";
            this.ucPond2.Size = new System.Drawing.Size(185, 122);
            this.ucPond2.TabIndex = 61;
            this.ucPond2.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.ucPond2.WallColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucPond2.WallWidth = 2;
            // 
            // ucBlower4
            // 
            this.ucBlower4.BlowerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucBlower4.EntranceDirection = HZH_Controls.Controls.BlowerEntranceDirection.Right;
            this.ucBlower4.ExitDirection = HZH_Controls.Controls.BlowerExitDirection.Left;
            this.ucBlower4.FanColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucBlower4.Location = new System.Drawing.Point(206, 529);
            this.ucBlower4.Name = "ucBlower4";
            this.ucBlower4.Size = new System.Drawing.Size(116, 154);
            this.ucBlower4.TabIndex = 62;
            this.ucBlower4.TurnAround = HZH_Controls.Controls.TurnAround.Clockwise;
            this.ucBlower4.TurnSpeed = 100;
            // 
            // UCTestConduit
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucValve1);
            this.Controls.Add(this.ucConduit9);
            this.Controls.Add(this.ucConduit22);
            this.Controls.Add(this.ucConduit24);
            this.Controls.Add(this.ucConduit23);
            this.Controls.Add(this.ucConduit8);
            this.Controls.Add(this.ucConduit7);
            this.Controls.Add(this.ucConduit6);
            this.Controls.Add(this.ucConduit3);
            this.Controls.Add(this.ucConduit4);
            this.Controls.Add(this.ucConduit2);
            this.Controls.Add(this.ucConduit18);
            this.Controls.Add(this.ucConduit17);
            this.Controls.Add(this.ucConduit1);
            this.Controls.Add(this.ucConduit19);
            this.Controls.Add(this.ucConduit20);
            this.Controls.Add(this.ucConduit21);
            this.Controls.Add(this.ucConduit25);
            this.Controls.Add(this.ucConduit14);
            this.Controls.Add(this.ucConduit30);
            this.Controls.Add(this.ucConduit12);
            this.Controls.Add(this.ucConduit27);
            this.Controls.Add(this.ucConduit11);
            this.Controls.Add(this.ucConduit29);
            this.Controls.Add(this.ucConduit28);
            this.Controls.Add(this.ucConduit26);
            this.Controls.Add(this.ucConduit5);
            this.Controls.Add(this.ucConduit10);
            this.Controls.Add(this.ucBottle2);
            this.Controls.Add(this.ucBottle1);
            this.Controls.Add(this.ucPond2);
            this.Controls.Add(this.ucBlower4);
            this.Name = "UCTestConduit";
            this.Size = new System.Drawing.Size(1127, 705);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCValve ucValve1;
        private HZH_Controls.Controls.UCConduit ucConduit9;
        private HZH_Controls.Controls.UCConduit ucConduit22;
        private HZH_Controls.Controls.UCConduit ucConduit24;
        private HZH_Controls.Controls.UCConduit ucConduit23;
        private HZH_Controls.Controls.UCConduit ucConduit8;
        private HZH_Controls.Controls.UCConduit ucConduit7;
        private HZH_Controls.Controls.UCConduit ucConduit6;
        private HZH_Controls.Controls.UCConduit ucConduit3;
        private HZH_Controls.Controls.UCConduit ucConduit2;
        private HZH_Controls.Controls.UCConduit ucConduit18;
        private HZH_Controls.Controls.UCConduit ucConduit17;
        private HZH_Controls.Controls.UCConduit ucConduit19;
        private HZH_Controls.Controls.UCConduit ucConduit20;
        private HZH_Controls.Controls.UCConduit ucConduit21;
        private HZH_Controls.Controls.UCConduit ucConduit25;
        private HZH_Controls.Controls.UCConduit ucConduit14;
        private HZH_Controls.Controls.UCConduit ucConduit30;
        private HZH_Controls.Controls.UCConduit ucConduit12;
        private HZH_Controls.Controls.UCConduit ucConduit27;
        private HZH_Controls.Controls.UCConduit ucConduit11;
        private HZH_Controls.Controls.UCConduit ucConduit29;
        private HZH_Controls.Controls.UCConduit ucConduit28;
        private HZH_Controls.Controls.UCConduit ucConduit26;
        private HZH_Controls.Controls.UCConduit ucConduit5;
        private HZH_Controls.Controls.UCConduit ucConduit10;
        private HZH_Controls.Controls.UCConduit ucConduit1;
        private HZH_Controls.Controls.UCBottle ucBottle1;
        private HZH_Controls.Controls.UCPond ucPond2;
        private HZH_Controls.Controls.UCBlower ucBlower4;
        private HZH_Controls.Controls.UCConduit ucConduit4;
        private HZH_Controls.Controls.UCBottle ucBottle2;
    }
}

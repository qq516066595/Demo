﻿namespace Test.UC
{
    partial class UCTestVerification
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ucTextBoxEx4 = new HZH_Controls.Controls.UCTextBoxEx();
            this.ucComboxGrid1 = new HZH_Controls.Controls.UCComboxGrid();
            this.ucComboBox2 = new HZH_Controls.Controls.UCCombox();
            this.ucComboBox1 = new HZH_Controls.Controls.UCCombox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ucTextBoxEx1 = new HZH_Controls.Controls.UCTextBoxEx();
            this.ucComboxGrid2 = new HZH_Controls.Controls.UCComboxGrid();
            this.ucCombox1 = new HZH_Controls.Controls.UCCombox();
            this.ucCombox2 = new HZH_Controls.Controls.UCCombox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.verificationComponent1 = new HZH_Controls.Controls.VerificationComponent(this.components);
            this.graphicalOverlay1 = new HZH_Controls.Controls.GraphicalOverlayComponent(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(16, 32);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "验证";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ucTextBoxEx4);
            this.groupBox1.Controls.Add(this.ucComboxGrid1);
            this.groupBox1.Controls.Add(this.ucComboBox2);
            this.groupBox1.Controls.Add(this.ucComboBox1);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Location = new System.Drawing.Point(16, 94);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(210, 319);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "非空验证";
            // 
            // ucTextBoxEx4
            // 
            this.ucTextBoxEx4.BackColor = System.Drawing.Color.Transparent;
            this.ucTextBoxEx4.ConerRadius = 5;
            this.ucTextBoxEx4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ucTextBoxEx4.DecLength = 2;
            this.ucTextBoxEx4.FillColor = System.Drawing.Color.Empty;
            this.ucTextBoxEx4.FocusBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucTextBoxEx4.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucTextBoxEx4.InputText = "";
            this.ucTextBoxEx4.InputType = HZH_Controls.TextInputType.NotControl;
            this.ucTextBoxEx4.IsFocusColor = true;
            this.ucTextBoxEx4.IsRadius = true;
            this.ucTextBoxEx4.IsShowClearBtn = true;
            this.ucTextBoxEx4.IsShowKeyboard = true;
            this.ucTextBoxEx4.IsShowRect = true;
            this.ucTextBoxEx4.IsShowSearchBtn = false;
            this.ucTextBoxEx4.KeyBoardType = HZH_Controls.Controls.KeyBoardType.UCKeyBorderAll_EN;
            this.ucTextBoxEx4.Location = new System.Drawing.Point(7, 255);
            this.ucTextBoxEx4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucTextBoxEx4.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.ucTextBoxEx4.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.ucTextBoxEx4.Name = "ucTextBoxEx4";
            this.ucTextBoxEx4.Padding = new System.Windows.Forms.Padding(5);
            this.ucTextBoxEx4.PromptColor = System.Drawing.Color.Gray;
            this.ucTextBoxEx4.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucTextBoxEx4.PromptText = "水印文字";
            this.ucTextBoxEx4.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucTextBoxEx4.RectWidth = 1;
            this.ucTextBoxEx4.RegexPattern = "";
            this.ucTextBoxEx4.Size = new System.Drawing.Size(173, 42);
            this.ucTextBoxEx4.TabIndex = 14;
            this.verificationComponent1.SetVerificationCustomRegex(this.ucTextBoxEx4, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.ucTextBoxEx4, "");
            this.verificationComponent1.SetVerificationModel(this.ucTextBoxEx4, HZH_Controls.Controls.VerificationModel.None);
            this.verificationComponent1.SetVerificationRequired(this.ucTextBoxEx4, true);
            // 
            // ucComboxGrid1
            // 
            this.ucComboxGrid1.BackColor = System.Drawing.Color.Transparent;
            this.ucComboxGrid1.BackColorExt = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboxGrid1.BoxStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ucComboxGrid1.ConerRadius = 5;
            this.ucComboxGrid1.DropPanelHeight = -1;
            this.ucComboxGrid1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboxGrid1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.ucComboxGrid1.GridColumns = null;
            this.ucComboxGrid1.GridDataSource = null;
            this.ucComboxGrid1.GridRowType = typeof(HZH_Controls.Controls.UCDataGridViewRow);
            this.ucComboxGrid1.IsRadius = false;
            this.ucComboxGrid1.IsShowRect = true;
            this.ucComboxGrid1.ItemWidth = 70;
            this.ucComboxGrid1.Location = new System.Drawing.Point(7, 213);
            this.ucComboxGrid1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucComboxGrid1.Name = "ucComboxGrid1";
            this.ucComboxGrid1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboxGrid1.RectWidth = 1;
            this.ucComboxGrid1.SelectedIndex = -1;
            this.ucComboxGrid1.SelectedValue = "";
            this.ucComboxGrid1.SelectSource = null;
            this.ucComboxGrid1.Size = new System.Drawing.Size(173, 32);
            this.ucComboxGrid1.Source = null;
            this.ucComboxGrid1.TabIndex = 13;
            this.ucComboxGrid1.TextField = "Name";
            this.ucComboxGrid1.TextValue = null;
            this.ucComboxGrid1.TriangleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.verificationComponent1.SetVerificationCustomRegex(this.ucComboxGrid1, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.ucComboxGrid1, "");
            this.verificationComponent1.SetVerificationModel(this.ucComboxGrid1, HZH_Controls.Controls.VerificationModel.None);
            this.verificationComponent1.SetVerificationRequired(this.ucComboxGrid1, true);
            // 
            // ucComboBox2
            // 
            this.ucComboBox2.BackColor = System.Drawing.Color.Transparent;
            this.ucComboBox2.BackColorExt = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboBox2.BoxStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ucComboBox2.ConerRadius = 5;
            this.ucComboBox2.DropPanelHeight = -1;
            this.ucComboBox2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboBox2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.ucComboBox2.IsRadius = false;
            this.ucComboBox2.IsShowRect = true;
            this.ucComboBox2.ItemWidth = 70;
            this.ucComboBox2.Location = new System.Drawing.Point(7, 159);
            this.ucComboBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucComboBox2.Name = "ucComboBox2";
            this.ucComboBox2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboBox2.RectWidth = 1;
            this.ucComboBox2.SelectedIndex = -1;
            this.ucComboBox2.SelectedValue = "";
            this.ucComboBox2.Size = new System.Drawing.Size(173, 32);
            this.ucComboBox2.Source = null;
            this.ucComboBox2.TabIndex = 11;
            this.ucComboBox2.TextValue = null;
            this.ucComboBox2.TriangleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.verificationComponent1.SetVerificationCustomRegex(this.ucComboBox2, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.ucComboBox2, "");
            this.verificationComponent1.SetVerificationModel(this.ucComboBox2, HZH_Controls.Controls.VerificationModel.None);
            this.verificationComponent1.SetVerificationRequired(this.ucComboBox2, true);
            // 
            // ucComboBox1
            // 
            this.ucComboBox1.BackColor = System.Drawing.Color.Transparent;
            this.ucComboBox1.BackColorExt = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboBox1.BoxStyle = System.Windows.Forms.ComboBoxStyle.DropDown;
            this.ucComboBox1.ConerRadius = 5;
            this.ucComboBox1.DropPanelHeight = -1;
            this.ucComboBox1.FillColor = System.Drawing.Color.White;
            this.ucComboBox1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.ucComboBox1.IsRadius = true;
            this.ucComboBox1.IsShowRect = true;
            this.ucComboBox1.ItemWidth = 70;
            this.ucComboBox1.Location = new System.Drawing.Point(7, 105);
            this.ucComboBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucComboBox1.Name = "ucComboBox1";
            this.ucComboBox1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucComboBox1.RectWidth = 1;
            this.ucComboBox1.SelectedIndex = -1;
            this.ucComboBox1.SelectedValue = "";
            this.ucComboBox1.Size = new System.Drawing.Size(173, 32);
            this.ucComboBox1.Source = null;
            this.ucComboBox1.TabIndex = 12;
            this.ucComboBox1.TextValue = null;
            this.ucComboBox1.TriangleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.verificationComponent1.SetVerificationCustomRegex(this.ucComboBox1, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.ucComboBox1, "");
            this.verificationComponent1.SetVerificationModel(this.ucComboBox1, HZH_Controls.Controls.VerificationModel.None);
            this.verificationComponent1.SetVerificationRequired(this.ucComboBox1, true);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(7, 63);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 20);
            this.comboBox1.TabIndex = 4;
            this.verificationComponent1.SetVerificationCustomRegex(this.comboBox1, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.comboBox1, "");
            this.verificationComponent1.SetVerificationModel(this.comboBox1, HZH_Controls.Controls.VerificationModel.None);
            this.verificationComponent1.SetVerificationRequired(this.comboBox1, true);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(7, 20);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox1, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox1, "");
            this.verificationComponent1.SetVerificationModel(this.textBox1, HZH_Controls.Controls.VerificationModel.None);
            this.verificationComponent1.SetVerificationRequired(this.textBox1, true);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ucTextBoxEx1);
            this.groupBox2.Controls.Add(this.ucComboxGrid2);
            this.groupBox2.Controls.Add(this.ucCombox1);
            this.groupBox2.Controls.Add(this.ucCombox2);
            this.groupBox2.Controls.Add(this.comboBox2);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Location = new System.Drawing.Point(13, 16);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(205, 319);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "扩展验证";
            // 
            // ucTextBoxEx1
            // 
            this.ucTextBoxEx1.BackColor = System.Drawing.Color.Transparent;
            this.ucTextBoxEx1.ConerRadius = 5;
            this.ucTextBoxEx1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ucTextBoxEx1.DecLength = 2;
            this.ucTextBoxEx1.FillColor = System.Drawing.Color.Empty;
            this.ucTextBoxEx1.FocusBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucTextBoxEx1.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucTextBoxEx1.InputText = "";
            this.ucTextBoxEx1.InputType = HZH_Controls.TextInputType.NotControl;
            this.ucTextBoxEx1.IsFocusColor = true;
            this.ucTextBoxEx1.IsRadius = true;
            this.ucTextBoxEx1.IsShowClearBtn = true;
            this.ucTextBoxEx1.IsShowKeyboard = true;
            this.ucTextBoxEx1.IsShowRect = true;
            this.ucTextBoxEx1.IsShowSearchBtn = false;
            this.ucTextBoxEx1.KeyBoardType = HZH_Controls.Controls.KeyBoardType.UCKeyBorderAll_EN;
            this.ucTextBoxEx1.Location = new System.Drawing.Point(7, 255);
            this.ucTextBoxEx1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucTextBoxEx1.MaxValue = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.ucTextBoxEx1.MinValue = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.ucTextBoxEx1.Name = "ucTextBoxEx1";
            this.ucTextBoxEx1.Padding = new System.Windows.Forms.Padding(5);
            this.ucTextBoxEx1.PromptColor = System.Drawing.Color.Gray;
            this.ucTextBoxEx1.PromptFont = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucTextBoxEx1.PromptText = "水印文字";
            this.ucTextBoxEx1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucTextBoxEx1.RectWidth = 1;
            this.ucTextBoxEx1.RegexPattern = "";
            this.ucTextBoxEx1.Size = new System.Drawing.Size(173, 42);
            this.ucTextBoxEx1.TabIndex = 14;
            this.verificationComponent1.SetVerificationCustomRegex(this.ucTextBoxEx1, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.ucTextBoxEx1, "");
            this.verificationComponent1.SetVerificationModel(this.ucTextBoxEx1, HZH_Controls.Controls.VerificationModel.None);
            this.verificationComponent1.SetVerificationRequired(this.ucTextBoxEx1, true);
            // 
            // ucComboxGrid2
            // 
            this.ucComboxGrid2.BackColor = System.Drawing.Color.Transparent;
            this.ucComboxGrid2.BackColorExt = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboxGrid2.BoxStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ucComboxGrid2.ConerRadius = 5;
            this.ucComboxGrid2.DropPanelHeight = -1;
            this.ucComboxGrid2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboxGrid2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.ucComboxGrid2.GridColumns = null;
            this.ucComboxGrid2.GridDataSource = null;
            this.ucComboxGrid2.GridRowType = typeof(HZH_Controls.Controls.UCDataGridViewRow);
            this.ucComboxGrid2.IsRadius = false;
            this.ucComboxGrid2.IsShowRect = true;
            this.ucComboxGrid2.ItemWidth = 70;
            this.ucComboxGrid2.Location = new System.Drawing.Point(7, 213);
            this.ucComboxGrid2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucComboxGrid2.Name = "ucComboxGrid2";
            this.ucComboxGrid2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucComboxGrid2.RectWidth = 1;
            this.ucComboxGrid2.SelectedIndex = -1;
            this.ucComboxGrid2.SelectedValue = "";
            this.ucComboxGrid2.SelectSource = null;
            this.ucComboxGrid2.Size = new System.Drawing.Size(173, 32);
            this.ucComboxGrid2.Source = null;
            this.ucComboxGrid2.TabIndex = 13;
            this.ucComboxGrid2.TextField = "Name";
            this.ucComboxGrid2.TextValue = null;
            this.ucComboxGrid2.TriangleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.verificationComponent1.SetVerificationCustomRegex(this.ucComboxGrid2, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.ucComboxGrid2, "");
            this.verificationComponent1.SetVerificationModel(this.ucComboxGrid2, HZH_Controls.Controls.VerificationModel.None);
            this.verificationComponent1.SetVerificationRequired(this.ucComboxGrid2, true);
            // 
            // ucCombox1
            // 
            this.ucCombox1.BackColor = System.Drawing.Color.Transparent;
            this.ucCombox1.BackColorExt = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucCombox1.BoxStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ucCombox1.ConerRadius = 5;
            this.ucCombox1.DropPanelHeight = -1;
            this.ucCombox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucCombox1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.ucCombox1.IsRadius = false;
            this.ucCombox1.IsShowRect = true;
            this.ucCombox1.ItemWidth = 70;
            this.ucCombox1.Location = new System.Drawing.Point(7, 159);
            this.ucCombox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucCombox1.Name = "ucCombox1";
            this.ucCombox1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucCombox1.RectWidth = 1;
            this.ucCombox1.SelectedIndex = -1;
            this.ucCombox1.SelectedValue = "";
            this.ucCombox1.Size = new System.Drawing.Size(173, 32);
            this.ucCombox1.Source = null;
            this.ucCombox1.TabIndex = 11;
            this.ucCombox1.TextValue = null;
            this.ucCombox1.TriangleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.verificationComponent1.SetVerificationCustomRegex(this.ucCombox1, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.ucCombox1, "");
            this.verificationComponent1.SetVerificationModel(this.ucCombox1, HZH_Controls.Controls.VerificationModel.None);
            this.verificationComponent1.SetVerificationRequired(this.ucCombox1, true);
            // 
            // ucCombox2
            // 
            this.ucCombox2.BackColor = System.Drawing.Color.Transparent;
            this.ucCombox2.BackColorExt = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucCombox2.BoxStyle = System.Windows.Forms.ComboBoxStyle.DropDown;
            this.ucCombox2.ConerRadius = 5;
            this.ucCombox2.DropPanelHeight = -1;
            this.ucCombox2.FillColor = System.Drawing.Color.White;
            this.ucCombox2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.ucCombox2.IsRadius = true;
            this.ucCombox2.IsShowRect = true;
            this.ucCombox2.ItemWidth = 70;
            this.ucCombox2.Location = new System.Drawing.Point(7, 105);
            this.ucCombox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucCombox2.Name = "ucCombox2";
            this.ucCombox2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucCombox2.RectWidth = 1;
            this.ucCombox2.SelectedIndex = -1;
            this.ucCombox2.SelectedValue = "";
            this.ucCombox2.Size = new System.Drawing.Size(173, 32);
            this.ucCombox2.Source = null;
            this.ucCombox2.TabIndex = 12;
            this.ucCombox2.TextValue = null;
            this.ucCombox2.TriangleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.verificationComponent1.SetVerificationCustomRegex(this.ucCombox2, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.ucCombox2, "");
            this.verificationComponent1.SetVerificationModel(this.ucCombox2, HZH_Controls.Controls.VerificationModel.None);
            this.verificationComponent1.SetVerificationRequired(this.ucCombox2, true);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(7, 63);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 20);
            this.comboBox2.TabIndex = 4;
            this.verificationComponent1.SetVerificationCustomRegex(this.comboBox2, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.comboBox2, "");
            this.verificationComponent1.SetVerificationModel(this.comboBox2, HZH_Controls.Controls.VerificationModel.None);
            this.verificationComponent1.SetVerificationRequired(this.comboBox2, true);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(7, 20);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 21);
            this.textBox2.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox2, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox2, "");
            this.verificationComponent1.SetVerificationModel(this.textBox2, HZH_Controls.Controls.VerificationModel.None);
            this.verificationComponent1.SetVerificationRequired(this.textBox2, true);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.textBox10);
            this.groupBox3.Controls.Add(this.textBox9);
            this.groupBox3.Controls.Add(this.textBox8);
            this.groupBox3.Controls.Add(this.textBox7);
            this.groupBox3.Controls.Add(this.textBox6);
            this.groupBox3.Controls.Add(this.textBox5);
            this.groupBox3.Controls.Add(this.textBox4);
            this.groupBox3.Controls.Add(this.textBox3);
            this.groupBox3.Location = new System.Drawing.Point(329, 94);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(360, 319);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "其他验证";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 275);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 12);
            this.label8.TabIndex = 1;
            this.label8.Text = "自定义正则表达式";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(63, 239);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 1;
            this.label7.Text = "身份证号";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(99, 203);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 12);
            this.label6.TabIndex = 1;
            this.label6.Text = "IP";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(87, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 1;
            this.label5.Text = "邮箱";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(87, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = "正数";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(75, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = "非负数";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(63, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "任意数字";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "任意字母数字下划线";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(134, 272);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(177, 21);
            this.textBox10.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox10, "^\\d+$");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox10, "请输入数字");
            this.verificationComponent1.SetVerificationModel(this.textBox10, HZH_Controls.Controls.VerificationModel.Custom);
            this.verificationComponent1.SetVerificationRequired(this.textBox10, false);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(134, 236);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(177, 21);
            this.textBox9.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox9, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox9, "");
            this.verificationComponent1.SetVerificationModel(this.textBox9, HZH_Controls.Controls.VerificationModel.IDCardNo);
            this.verificationComponent1.SetVerificationRequired(this.textBox9, false);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(134, 200);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(177, 21);
            this.textBox8.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox8, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox8, "");
            this.verificationComponent1.SetVerificationModel(this.textBox8, HZH_Controls.Controls.VerificationModel.IP);
            this.verificationComponent1.SetVerificationRequired(this.textBox8, false);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(134, 164);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(177, 21);
            this.textBox7.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox7, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox7, "");
            this.verificationComponent1.SetVerificationModel(this.textBox7, HZH_Controls.Controls.VerificationModel.Email);
            this.verificationComponent1.SetVerificationRequired(this.textBox7, false);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(134, 128);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(177, 21);
            this.textBox6.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox6, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox6, "");
            this.verificationComponent1.SetVerificationModel(this.textBox6, HZH_Controls.Controls.VerificationModel.PositiveNumber);
            this.verificationComponent1.SetVerificationRequired(this.textBox6, false);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(134, 92);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(177, 21);
            this.textBox5.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox5, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox5, "");
            this.verificationComponent1.SetVerificationModel(this.textBox5, HZH_Controls.Controls.VerificationModel.UnsignNumber);
            this.verificationComponent1.SetVerificationRequired(this.textBox5, false);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(134, 56);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(177, 21);
            this.textBox4.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox4, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox4, "");
            this.verificationComponent1.SetVerificationModel(this.textBox4, HZH_Controls.Controls.VerificationModel.Number);
            this.verificationComponent1.SetVerificationRequired(this.textBox4, false);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(134, 20);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(177, 21);
            this.textBox3.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox3, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox3, "");
            this.verificationComponent1.SetVerificationModel(this.textBox3, HZH_Controls.Controls.VerificationModel.AnyChar);
            this.verificationComponent1.SetVerificationRequired(this.textBox3, false);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.textBox11);
            this.groupBox4.Controls.Add(this.textBox12);
            this.groupBox4.Controls.Add(this.textBox13);
            this.groupBox4.Controls.Add(this.textBox14);
            this.groupBox4.Controls.Add(this.textBox15);
            this.groupBox4.Controls.Add(this.textBox16);
            this.groupBox4.Controls.Add(this.textBox17);
            this.groupBox4.Controls.Add(this.textBox18);
            this.groupBox4.Location = new System.Drawing.Point(326, 16);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(360, 319);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "扩展验证";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 275);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 12);
            this.label9.TabIndex = 1;
            this.label9.Text = "自定义正则表达式";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(63, 239);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 1;
            this.label10.Text = "身份证号";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(99, 203);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(17, 12);
            this.label11.TabIndex = 1;
            this.label11.Text = "IP";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(87, 167);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 1;
            this.label12.Text = "邮箱";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(87, 131);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 1;
            this.label13.Text = "正数";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(75, 95);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 12);
            this.label14.TabIndex = 1;
            this.label14.Text = "非负数";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(63, 59);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 12);
            this.label15.TabIndex = 1;
            this.label15.Text = "任意数字";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(3, 23);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(113, 12);
            this.label16.TabIndex = 1;
            this.label16.Text = "任意字母数字下划线";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(134, 272);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(177, 21);
            this.textBox11.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox11, "^\\d+$");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox11, "请输入数字");
            this.verificationComponent1.SetVerificationModel(this.textBox11, HZH_Controls.Controls.VerificationModel.Custom);
            this.verificationComponent1.SetVerificationRequired(this.textBox11, false);
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(134, 236);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(177, 21);
            this.textBox12.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox12, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox12, "");
            this.verificationComponent1.SetVerificationModel(this.textBox12, HZH_Controls.Controls.VerificationModel.IDCardNo);
            this.verificationComponent1.SetVerificationRequired(this.textBox12, false);
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(134, 200);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(177, 21);
            this.textBox13.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox13, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox13, "");
            this.verificationComponent1.SetVerificationModel(this.textBox13, HZH_Controls.Controls.VerificationModel.IP);
            this.verificationComponent1.SetVerificationRequired(this.textBox13, false);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(134, 164);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(177, 21);
            this.textBox14.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox14, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox14, "");
            this.verificationComponent1.SetVerificationModel(this.textBox14, HZH_Controls.Controls.VerificationModel.Email);
            this.verificationComponent1.SetVerificationRequired(this.textBox14, false);
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(134, 128);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(177, 21);
            this.textBox15.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox15, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox15, "");
            this.verificationComponent1.SetVerificationModel(this.textBox15, HZH_Controls.Controls.VerificationModel.PositiveNumber);
            this.verificationComponent1.SetVerificationRequired(this.textBox15, false);
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(134, 92);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(177, 21);
            this.textBox16.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox16, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox16, "");
            this.verificationComponent1.SetVerificationModel(this.textBox16, HZH_Controls.Controls.VerificationModel.UnsignNumber);
            this.verificationComponent1.SetVerificationRequired(this.textBox16, false);
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(134, 56);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(177, 21);
            this.textBox17.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox17, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox17, "");
            this.verificationComponent1.SetVerificationModel(this.textBox17, HZH_Controls.Controls.VerificationModel.Number);
            this.verificationComponent1.SetVerificationRequired(this.textBox17, false);
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(134, 20);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(177, 21);
            this.textBox18.TabIndex = 0;
            this.verificationComponent1.SetVerificationCustomRegex(this.textBox18, "");
            this.verificationComponent1.SetVerificationErrorMsg(this.textBox18, "");
            this.verificationComponent1.SetVerificationModel(this.textBox18, HZH_Controls.Controls.VerificationModel.AnyChar);
            this.verificationComponent1.SetVerificationRequired(this.textBox18, false);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Location = new System.Drawing.Point(3, 420);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(697, 347);
            this.panel1.TabIndex = 4;
            // 
            // verificationComponent1
            // 
            this.verificationComponent1.ErrorTipsBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.verificationComponent1.ErrorTipsForeColor = System.Drawing.Color.White;
            this.verificationComponent1.Verificationed += new HZH_Controls.Controls.VerificationComponent.VerificationedHandle(this.verificationComponent1_Verificationed);
            // 
            // graphicalOverlay1
            // 
            this.graphicalOverlay1.Owner = this.panel1;
            this.graphicalOverlay1.Paint += new System.EventHandler<System.Windows.Forms.PaintEventArgs>(this.graphicalOverlay1_Paint);
            // 
            // UCTestVerification
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.Name = "UCTestVerification";
            this.Size = new System.Drawing.Size(1025, 767);
            this.Load += new System.EventHandler(this.UCTestVerification_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private HZH_Controls.Controls.VerificationComponent verificationComponent1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private HZH_Controls.Controls.UCComboxGrid ucComboxGrid1;
        private HZH_Controls.Controls.UCCombox ucComboBox2;
        private HZH_Controls.Controls.UCCombox ucComboBox1;
        private HZH_Controls.Controls.UCTextBoxEx ucTextBoxEx4;
        private System.Windows.Forms.GroupBox groupBox2;
        private HZH_Controls.Controls.UCTextBoxEx ucTextBoxEx1;
        private HZH_Controls.Controls.UCComboxGrid ucComboxGrid2;
        private HZH_Controls.Controls.UCCombox ucCombox1;
        private HZH_Controls.Controls.UCCombox ucCombox2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox2;
        private HZH_Controls.Controls.GraphicalOverlayComponent graphicalOverlay1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Panel panel1;
    }
}

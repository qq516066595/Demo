﻿namespace Test.UC
{
    partial class UCTestContextMenu
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCTestContextMenu));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.菜单1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.菜单1ToolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单1ToolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.菜单1ToolStripMenuItem11,
            this.菜单1ToolStripMenuItem12,
            this.菜单1ToolStripMenuItem13,
            this.菜单1ToolStripMenuItem14,
            this.菜单1ToolStripMenuItem15});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(108, 204);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.菜单1ToolStripMenuItem,
            this.菜单2ToolStripMenuItem,
            this.菜单1ToolStripMenuItem9,
            this.菜单1ToolStripMenuItem10});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(572, 25);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 菜单1ToolStripMenuItem
            // 
            this.菜单1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.菜单1ToolStripMenuItem1,
            this.菜单1ToolStripMenuItem2,
            this.菜单1ToolStripMenuItem5});
            this.菜单1ToolStripMenuItem.Name = "菜单1ToolStripMenuItem";
            this.菜单1ToolStripMenuItem.Size = new System.Drawing.Size(51, 21);
            this.菜单1ToolStripMenuItem.Text = "菜单1";
            // 
            // 菜单2ToolStripMenuItem
            // 
            this.菜单2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.菜单1ToolStripMenuItem6,
            this.菜单1ToolStripMenuItem7});
            this.菜单2ToolStripMenuItem.Name = "菜单2ToolStripMenuItem";
            this.菜单2ToolStripMenuItem.Size = new System.Drawing.Size(51, 21);
            this.菜单2ToolStripMenuItem.Text = "菜单2";
            // 
            // 菜单1ToolStripMenuItem1
            // 
            this.菜单1ToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.菜单1ToolStripMenuItem3,
            this.菜单1ToolStripMenuItem4});
            this.菜单1ToolStripMenuItem1.Name = "菜单1ToolStripMenuItem1";
            this.菜单1ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.菜单1ToolStripMenuItem1.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem2
            // 
            this.菜单1ToolStripMenuItem2.Name = "菜单1ToolStripMenuItem2";
            this.菜单1ToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.菜单1ToolStripMenuItem2.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem3
            // 
            this.菜单1ToolStripMenuItem3.Name = "菜单1ToolStripMenuItem3";
            this.菜单1ToolStripMenuItem3.Size = new System.Drawing.Size(152, 22);
            this.菜单1ToolStripMenuItem3.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem4
            // 
            this.菜单1ToolStripMenuItem4.Name = "菜单1ToolStripMenuItem4";
            this.菜单1ToolStripMenuItem4.Size = new System.Drawing.Size(152, 22);
            this.菜单1ToolStripMenuItem4.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem5
            // 
            this.菜单1ToolStripMenuItem5.Name = "菜单1ToolStripMenuItem5";
            this.菜单1ToolStripMenuItem5.Size = new System.Drawing.Size(152, 22);
            this.菜单1ToolStripMenuItem5.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem6
            // 
            this.菜单1ToolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.菜单1ToolStripMenuItem8});
            this.菜单1ToolStripMenuItem6.Name = "菜单1ToolStripMenuItem6";
            this.菜单1ToolStripMenuItem6.Size = new System.Drawing.Size(152, 22);
            this.菜单1ToolStripMenuItem6.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem7
            // 
            this.菜单1ToolStripMenuItem7.Name = "菜单1ToolStripMenuItem7";
            this.菜单1ToolStripMenuItem7.Size = new System.Drawing.Size(152, 22);
            this.菜单1ToolStripMenuItem7.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem8
            // 
            this.菜单1ToolStripMenuItem8.Name = "菜单1ToolStripMenuItem8";
            this.菜单1ToolStripMenuItem8.Size = new System.Drawing.Size(152, 22);
            this.菜单1ToolStripMenuItem8.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem9
            // 
            this.菜单1ToolStripMenuItem9.Name = "菜单1ToolStripMenuItem9";
            this.菜单1ToolStripMenuItem9.Size = new System.Drawing.Size(51, 21);
            this.菜单1ToolStripMenuItem9.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem10
            // 
            this.菜单1ToolStripMenuItem10.Name = "菜单1ToolStripMenuItem10";
            this.菜单1ToolStripMenuItem10.Size = new System.Drawing.Size(51, 21);
            this.菜单1ToolStripMenuItem10.Text = "菜单1";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Silver;
            this.label1.ContextMenuStrip = this.contextMenuStrip1;
            this.label1.Location = new System.Drawing.Point(94, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(357, 93);
            this.label1.TabIndex = 2;
            this.label1.Text = "看看我的右键菜单可好，骚年？\r\nHZH_Controls.Controls.ToolStripColorTable这里面有好多颜色  自己可以改  ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // 菜单1ToolStripMenuItem11
            // 
            this.菜单1ToolStripMenuItem11.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.菜单1ToolStripMenuItem16,
            this.菜单1ToolStripMenuItem17});
            this.菜单1ToolStripMenuItem11.Name = "菜单1ToolStripMenuItem11";
            this.菜单1ToolStripMenuItem11.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            this.菜单1ToolStripMenuItem11.Size = new System.Drawing.Size(152, 40);
            this.菜单1ToolStripMenuItem11.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem12
            // 
            this.菜单1ToolStripMenuItem12.Name = "菜单1ToolStripMenuItem12";
            this.菜单1ToolStripMenuItem12.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            this.菜单1ToolStripMenuItem12.Size = new System.Drawing.Size(152, 40);
            this.菜单1ToolStripMenuItem12.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem13
            // 
            this.菜单1ToolStripMenuItem13.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.菜单1ToolStripMenuItem18,
            this.菜单1ToolStripMenuItem19});
            this.菜单1ToolStripMenuItem13.Image = ((System.Drawing.Image)(resources.GetObject("菜单1ToolStripMenuItem13.Image")));
            this.菜单1ToolStripMenuItem13.Name = "菜单1ToolStripMenuItem13";
            this.菜单1ToolStripMenuItem13.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            this.菜单1ToolStripMenuItem13.Size = new System.Drawing.Size(107, 40);
            this.菜单1ToolStripMenuItem13.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem14
            // 
            this.菜单1ToolStripMenuItem14.Name = "菜单1ToolStripMenuItem14";
            this.菜单1ToolStripMenuItem14.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            this.菜单1ToolStripMenuItem14.Size = new System.Drawing.Size(152, 40);
            this.菜单1ToolStripMenuItem14.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem15
            // 
            this.菜单1ToolStripMenuItem15.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.菜单1ToolStripMenuItem20});
            this.菜单1ToolStripMenuItem15.Name = "菜单1ToolStripMenuItem15";
            this.菜单1ToolStripMenuItem15.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            this.菜单1ToolStripMenuItem15.Size = new System.Drawing.Size(152, 40);
            this.菜单1ToolStripMenuItem15.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem16
            // 
            this.菜单1ToolStripMenuItem16.Name = "菜单1ToolStripMenuItem16";
            this.菜单1ToolStripMenuItem16.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            this.菜单1ToolStripMenuItem16.Size = new System.Drawing.Size(152, 40);
            this.菜单1ToolStripMenuItem16.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem17
            // 
            this.菜单1ToolStripMenuItem17.Name = "菜单1ToolStripMenuItem17";
            this.菜单1ToolStripMenuItem17.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            this.菜单1ToolStripMenuItem17.Size = new System.Drawing.Size(152, 40);
            this.菜单1ToolStripMenuItem17.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem18
            // 
            this.菜单1ToolStripMenuItem18.Name = "菜单1ToolStripMenuItem18";
            this.菜单1ToolStripMenuItem18.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            this.菜单1ToolStripMenuItem18.Size = new System.Drawing.Size(152, 40);
            this.菜单1ToolStripMenuItem18.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem19
            // 
            this.菜单1ToolStripMenuItem19.Name = "菜单1ToolStripMenuItem19";
            this.菜单1ToolStripMenuItem19.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            this.菜单1ToolStripMenuItem19.Size = new System.Drawing.Size(152, 40);
            this.菜单1ToolStripMenuItem19.Text = "菜单1";
            // 
            // 菜单1ToolStripMenuItem20
            // 
            this.菜单1ToolStripMenuItem20.Name = "菜单1ToolStripMenuItem20";
            this.菜单1ToolStripMenuItem20.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            this.菜单1ToolStripMenuItem20.Size = new System.Drawing.Size(152, 40);
            this.菜单1ToolStripMenuItem20.Text = "菜单1";
            // 
            // UCTestContextMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "UCTestContextMenu";
            this.Size = new System.Drawing.Size(572, 332);
            this.contextMenuStrip1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem19;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem20;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem 菜单2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem 菜单1ToolStripMenuItem10;
        private System.Windows.Forms.Label label1;
    }
}

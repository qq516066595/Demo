﻿namespace Test.UC
{
    partial class UCTestValve
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucValve2 = new HZH_Controls.Controls.UCValve();
            this.ucValve4 = new HZH_Controls.Controls.UCValve();
            this.ucValve1 = new HZH_Controls.Controls.UCValve();
            this.ucValve3 = new HZH_Controls.Controls.UCValve();
            this.SuspendLayout();
            // 
            // ucValve2
            // 
            this.ucValve2.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve2.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve2.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve2.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Forward;
            this.ucValve2.LiquidSpeed = 100;
            this.ucValve2.Location = new System.Drawing.Point(215, 200);
            this.ucValve2.Name = "ucValve2";
            this.ucValve2.Opened = true;
            this.ucValve2.Size = new System.Drawing.Size(97, 131);
            this.ucValve2.SwitchColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucValve2.TabIndex = 24;
            this.ucValve2.ValveColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucValve2.ValveStyle = HZH_Controls.Controls.ValveStyle.Vertical_Right;
            // 
            // ucValve4
            // 
            this.ucValve4.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve4.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve4.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve4.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucValve4.LiquidSpeed = 100;
            this.ucValve4.Location = new System.Drawing.Point(215, 49);
            this.ucValve4.Name = "ucValve4";
            this.ucValve4.Opened = true;
            this.ucValve4.Size = new System.Drawing.Size(169, 106);
            this.ucValve4.SwitchColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucValve4.TabIndex = 25;
            this.ucValve4.ValveColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucValve4.ValveStyle = HZH_Controls.Controls.ValveStyle.Horizontal_Bottom;
            // 
            // ucValve1
            // 
            this.ucValve1.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve1.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve1.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve1.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Backward;
            this.ucValve1.LiquidSpeed = 100;
            this.ucValve1.Location = new System.Drawing.Point(33, 9);
            this.ucValve1.Name = "ucValve1";
            this.ucValve1.Opened = true;
            this.ucValve1.Size = new System.Drawing.Size(169, 106);
            this.ucValve1.SwitchColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucValve1.TabIndex = 26;
            this.ucValve1.ValveColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucValve1.ValveStyle = HZH_Controls.Controls.ValveStyle.Horizontal_Top;
            // 
            // ucValve3
            // 
            this.ucValve3.AsisBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve3.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve3.LiquidColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(169)))), ((int)(((byte)(243)))));
            this.ucValve3.LiquidDirection = HZH_Controls.Controls.LiquidDirection.Forward;
            this.ucValve3.LiquidSpeed = 100;
            this.ucValve3.Location = new System.Drawing.Point(69, 199);
            this.ucValve3.Name = "ucValve3";
            this.ucValve3.Opened = true;
            this.ucValve3.Size = new System.Drawing.Size(97, 131);
            this.ucValve3.SwitchColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucValve3.TabIndex = 27;
            this.ucValve3.ValveColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucValve3.ValveStyle = HZH_Controls.Controls.ValveStyle.Vertical_Left;
            // 
            // UCTestValve
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucValve2);
            this.Controls.Add(this.ucValve4);
            this.Controls.Add(this.ucValve1);
            this.Controls.Add(this.ucValve3);
            this.Name = "UCTestValve";
            this.Size = new System.Drawing.Size(520, 443);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCValve ucValve2;
        private HZH_Controls.Controls.UCValve ucValve4;
        private HZH_Controls.Controls.UCValve ucValve1;
        private HZH_Controls.Controls.UCValve ucValve3;
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HZH_Controls.Forms;

namespace Test
{
    public partial class FrmTestFrmBack : FrmBack
    {
        public FrmTestFrmBack()
        {
            InitializeComponent();
        }
    }
}

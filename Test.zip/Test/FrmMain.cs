﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using com.DataBaseModels;
using HZH_Controls;
using HZH_Controls.Controls;
using HZH_Controls.Forms;

namespace Test
{
    public partial class FrmMain : FrmWithTitle
    {
        public static View.Common.CommonClass comm = null;
        //public static View.Tube.UCMain ucMain = null;
        public FrmMain()
        {
            InitializeComponent();
            if (comm == null)
            {
                comm = new View.Common.CommonClass();
            }
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            try
            {
                TreeConentLoad();
                AddControl(new View.Tube.UCMain());
            }
            finally
            {
                ControlHelper.FreezeControl(this, false);
            }

            PlcVar.Tube[0].gnProcessWorkingTime = 1;
            PlcVar.Tube[1].gnProcessWorkingTime = 2;
            PlcVar.Tube[2].gnProcessWorkingTime = 3;
            PlcVar.Tube[3].gnProcessWorkingTime = 4;
            PlcVar.Tube[4].gnProcessWorkingTime = 5;
            PlcVar.Tube[0].gnProcessTotalTime = 111;
            PlcVar.Tube[1].gnProcessTotalTime = 222;
            PlcVar.Tube[2].gnProcessTotalTime = 333;
            PlcVar.Tube[3].gnProcessTotalTime = 444;
            PlcVar.Tube[4].gnProcessTotalTime = 555;
        }
        public void TreeConentLoad()
        {
            this.tvMenu.Nodes.Clear();
            ControlHelper.FreezeControl(this, true);
            this.tvMenu.Nodes.Add(" 用户");
            this.tvMenu.Nodes.Add(" 首页");
            this.tvMenu.Nodes.Add(" 主页");
            if (comm.Num != 5)
            {
                this.tvMenu.Nodes.Add(" 配方");
                this.tvMenu.Nodes.Add(" I/O");
                TreeNode tnData = new TreeNode(" 数据");
                tnData.Nodes.Add("图表");
                tnData.Nodes.Add("报表");
                this.tvMenu.Nodes.Add(tnData);
            }
            else
            {
                TreeNode tnIO = new TreeNode("I/O");
                tnIO.Nodes.Add("I/O");
                tnIO.Nodes.Add("通讯");
                this.tvMenu.Nodes.Add(tnIO);
            }
            TreeNode tnControl = new TreeNode(" 配置");
            if (comm.Num == 5)
            {
                tnControl.Nodes.Add("初始化");
                tnControl.Nodes.Add("轴控");
                tnControl.Nodes.Add("工位");
            }
            else
            {
                tnControl.Nodes.Add("初始化");
                tnControl.Nodes.Add("气路");
                tnControl.Nodes.Add("温控");
                tnControl.Nodes.Add("真空");
                tnControl.Nodes.Add("轴控");
                tnControl.Nodes.Add("限幅");
            }
            this.tvMenu.Nodes.Add(tnControl);
            if (comm.Num == 5)
                this.tvMenu.Nodes.Add(" 舟管理");
            TreeNode tnJournal = new TreeNode(" 日志");
            tnJournal.Nodes.Add("事件");
            tnJournal.Nodes.Add("报警");
            this.tvMenu.Nodes.Add(tnJournal);
            this.tvMenu.Nodes.Add(" 关于");

            for (int i = 0; i < tvMenu.Nodes.Count; i++)
            {
                if (tvMenu.Nodes[i].Text.Trim() == "主页")
                    tvMenu.SelectedNode = tvMenu.Nodes[i];//选中

                //for (int j = 0; j < tvMenu.Nodes[i].Nodes.Count; j++)
                //{
                //    if (tvMenu.Nodes[i].Nodes[j].Text == "首页")
                //    {
                //        tvMenu.SelectedNode = tvMenu.Nodes[i].Nodes[j];//选中
                //        //treeView.Nodes[i].Nodes[j].Checked = true;
                //        tvMenu.Nodes[i].Expand();//展开父级
                //        return;
                //    }
                //}
            }
        }
        private void tvMenu_AfterSelect(object sender, TreeViewEventArgs e)
        {
            View.Tube.UCMain ucMain = null;
            panControl.Controls.Clear();
            string strName = e.Node.Text.Trim();
            this.Title = "磷扩散控制系统--" + strName;
            if (comm.Num == 0 || comm.Num == 1 || comm.Num == 2 || comm.Num == 3 || comm.Num == 4)
            {
                switch (strName)
                {
                    case "首页":
                        AddControl(new UCShouQuan());
                        pnlMenu.Visible = false;
                        break;
                    case "用户":
                        AddControl(new View.Common.UCUserInfo());
                        pnlMenu.Visible = false;
                        break;
                    case "主页":
                        pnlMenu.Visible = true;
                        if (ucMain == null)
                            ucMain = new View.Tube.UCMain();
                        AddControl(ucMain);
                        break;
                    case "配方":
                        pnlMenu.Visible = true;
                        AddControl(new View.Tube.UCRecipe());
                        break;
                    case "I/O":
                        pnlMenu.Visible = true;
                        AddControl(new View.Tube.UCIO());
                        break;
                    case "数据":
                    case "图表":
                        pnlMenu.Visible = true;
                        AddControl(new View.Tube.UCChart());
                        break;
                    case "报表":
                        pnlMenu.Visible = true;
                        AddControl(new View.Tube.UCReport());
                        break;
                    case "配置":
                    case "初始化":
                        pnlMenu.Visible = true;
                        AddControl(new View.Tube.UCInit());
                        break;
                    case "气路":
                        pnlMenu.Visible = true;
                        AddControl(new View.Tube.UCSetMFC());
                        break;
                    case "温控":
                        pnlMenu.Visible = true;
                        AddControl(new View.Tube.UCSetTemp());
                        break;
                    case "真空":
                        pnlMenu.Visible = true;
                        AddControl(new View.Tube.UCSetVacuum());
                        break;
                    case "轴控":
                        pnlMenu.Visible = true;
                        AddControl(new View.Tube.UCSetBoatPush());
                        break;
                    case "日志":
                    case "报警":
                    case "事件":
                        pnlMenu.Visible = true;
                        AddControl(new View.Common.UCJournal());
                        break;
                    case "关于":
                        pnlMenu.Visible = false;
                        AddControl(new View.Common.UCAbout());
                        break;
                    default:
                        MessageBox.Show("打开画面异常！");
                        break;
                }
            }
            else
            {
                switch (strName)
                {
                    case "首页":
                        AddControl(new UCShouQuan());
                        pnlMenu.Visible = false;
                        break;
                    case "用户":
                        AddControl(new View.Common.UCUserInfo());
                        pnlMenu.Visible = false;
                        break;
                    case "主页":
                        pnlMenu.Visible = true;
                        AddControl(new View.Loader.UCMain());
                        break;
                    case "I/O":
                        pnlMenu.Visible = true;
                        AddControl(new View.Loader.UCIO());
                        break;
                    case "通讯":
                        pnlMenu.Visible = true;
                        AddControl(new View.Loader.UCCommIO());
                        break;
                    case "配置":
                    case "初始化":
                        pnlMenu.Visible = true;
                        AddControl(new View.Loader.UCSetInit());
                        break;
                    case "轴控":
                        pnlMenu.Visible = true;
                        AddControl(new View.Loader.UCSetAxisPara());
                        break;
                    case "工位":
                        pnlMenu.Visible = true;
                        AddControl(new View.Loader.UCSetStation());
                        break;
                    case "舟管理":
                        pnlMenu.Visible = false;
                        AddControl(new View.Loader.UCBoatManager());
                        break;
                    case "日志":
                    case "报警":
                    case "事件":
                        pnlMenu.Visible = true;
                        AddControl(new View.Common.UCJournal());
                        break;
                    case "关于":
                        pnlMenu.Visible = false;
                        AddControl(new View.Common.UCAbout());
                        break;
                    default:
                        MessageBox.Show("打开画面异常！");
                        break;
                }
            }

        }

        private void AddControl(Control c)
        {
            c.Dock = DockStyle.Fill;
            this.panControl.Controls.Add(c);
        }

        //View.Tube.UCRecipeInfo recipeInfo = new View.Tube.UCRecipeInfo();
        private void Lable_Click(object sender, EventArgs e)
        {
            #region 字体设置
            Label lbl = (Label)sender;
            lbl.Font = new System.Drawing.Font("微软雅黑", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            lbl.Padding = new System.Windows.Forms.Padding(10, 10, 10, 0);
            foreach (Control c in this.pnlMenu.Controls)
            {
                if (c is Label && c != lbl && c != lblCurrentLocation)
                {
                    c.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                    c.Padding = new System.Windows.Forms.Padding(10, 15, 10, 0);
                }
            }
            lblCurrentLocation.Text = "当前位置：" + lbl.Text;
            #endregion

            int num = Convert.ToInt16(((Label)sender).Tag);
            #region 窗体打开判断
            switch (num)
            {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    frmID.Unit = num - 1; comm.Num = num - 1;
                    break;
                case 6:
                    comm.Num = 5;
                    TreeConentLoad();
                    ControlHelper.FreezeControl(this, false);
                    break;
                default:
                    comm.Num = 0;
                    break;
            }
            DataBings();
            #endregion
        }
        public void DataBings()
        {
            View.Common.TubeHelpClass help = new View.Common.TubeHelpClass();
            string strName = tvMenu.SelectedNode.Text.Trim();
            switch (strName)
            {
                case "用户":
                    break;
                case "首页":
                    break;
                case "主页":
                    var bodyMain = this.panControl.Controls.Find("UCMain", false);
                    if (bodyMain != null)
                        foreach (var item in bodyMain[0].Controls)
                        {
                            if (item is View.Tube.UCRecipeInfo)//工艺信息
                            {
                                var recipeInfo = item as View.Tube.UCRecipeInfo;
                                recipeInfo.ucSwitch.Checked = PlcVar.Tube[frmID.Unit].OP_Cmd.bAutoSelect;
                                recipeInfo.ucBoatState.SelectedIndex = Convert.ToInt32(PlcVar.Tube[frmID.Unit].stTube_BoatInfo.eBoatState);
                                //recipeInfo.lblRecipeName.Text = PlcVar.Tube[frmID.Unit].stCurrentRecipeName;
                                recipeInfo.lblRecipeTotalTime.Text = help.timeFormatUshortToString(PlcVar.Tube[frmID.Unit].gnProcessTotalTime);
                                recipeInfo.lblRecipeWorkTime.Text = help.timeFormatUshortToString(PlcVar.Tube[frmID.Unit].gnProcessWorkingTime);
                                recipeInfo.lblRecipeRemainTime.Text = help.timeFormatUshortToString(PlcVar.Tube[frmID.Unit].gnProcessRemainTime);
                                recipeInfo.lblStepId.Text = PlcVar.Tube[frmID.Unit].giRecipe_ID.ToString();
                                recipeInfo.lblStepName.Text = help.KSrecipeNameFormatIntToString(PlcVar.Tube[frmID.Unit].stCurrentRecipeCtrl.eName);
                                recipeInfo.lblStepTotalTime.Text = help.timeFormatFloatToString(PlcVar.Tube[frmID.Unit].stCurrentRecipeCtrl.nDuration);
                                recipeInfo.lblStepWorkTime.Text = help.timeFormatFloatToString(PlcVar.Tube[frmID.Unit].stCurrentRecipeCtrl.nWorking_Time);
                                recipeInfo.lblStepRemainTime.Text = help.timeFormatFloatToString(PlcVar.Tube[frmID.Unit].stCurrentRecipeCtrl.nRemain_Time);
                                float totaltime = PlcVar.Tube[frmID.Unit].stCurrentRecipeCtrl.nDuration;
                                float workingtime = PlcVar.Tube[frmID.Unit].stCurrentRecipeCtrl.nWorking_Time;
                                recipeInfo.ucRecipeBar.Value = workingtime / totaltime;
                                recipeInfo.ucRecipeBar.Text = (workingtime / totaltime).ToString() + "%";
                            }
                            if (item is View.Tube.UCBoatPush)//推舟
                            {
                                var axisInfo = item as View.Tube.UCBoatPush;
                                axisInfo.lblAxisActPos.Text = PlcVar.Tube[frmID.Unit].BoatPush_SV_Ctrl.rActPos.ToString();
                                axisInfo.lblAxisActSpeed.Text = PlcVar.Tube[frmID.Unit].BoatPush_SV_Ctrl.rActSpeed.ToString();
                                axisInfo.lblAxisRulerPos.Text = PlcVar.Tube[frmID.Unit].grHand_X_RulerPos.ToString();
                                axisInfo.lblAxisActTorque.Text = PlcVar.Tube[frmID.Unit].BoatPush_SV_Ctrl.rAct_Torque.ToString();
                                axisInfo.LampStatesChange(PlcVar.Tube[frmID.Unit].BoatPush_SV_Ctrl.O_SW, axisInfo.lblAxisHome_SW);
                                axisInfo.LampStatesChange(PlcVar.Tube[frmID.Unit].BoatPush_SV_Ctrl.N_SW, axisInfo.lblAxisN_OT);
                                axisInfo.LampStatesChange(PlcVar.Tube[frmID.Unit].BoatPush_SV_Ctrl.P_SW, axisInfo.lblAxisP_OT);
                                axisInfo.txtHMI_JogSpeed.Text = PlcVar.Tube[frmID.Unit].BoatPush_SV_Para.rJogSpeed.ToString();
                            }
                            if (item is View.Tube.UCZone)//温区
                            {
                                var zoneInfo = item as View.Tube.UCZone;
                                foreach (Control control in zoneInfo.Controls)
                                {
                                    if (control is Label)
                                    {
                                        for (int i = 0; i <= 7; i++)
                                        {
                                            if (control.Name.Equals("lblZoneEx" + (i + 1).ToString(), StringComparison.CurrentCultureIgnoreCase))//外偶
                                                ((Label)control).Text = PlcVar.Tube[frmID.Unit].stTempZone[i].rExternal_Temp.ToString();
                                            else if (control.Name.Equals("lblZoneIn" + (i + 1).ToString(), StringComparison.CurrentCultureIgnoreCase))//内偶
                                                ((Label)control).Text = PlcVar.Tube[frmID.Unit].stTempZone[i].rInternal_Temp.ToString();
                                            else if (control.Name.Equals("lblZoneMV" + (i + 1).ToString(), StringComparison.CurrentCultureIgnoreCase))//功率
                                                ((Label)control).Text = PlcVar.Tube[frmID.Unit].stTempZone[i].rMV.ToString();
                                            //else if (control.Name.Equals("lblZoneSP" + i.ToString(), StringComparison.CurrentCultureIgnoreCase))//过渡
                                            //((LabelControl)control).Text = modus.grTemp_SPArray[i].ToString();
                                        }
                                    }
                                    if (control is TextBox)
                                    {
                                        for (int i = 0; i <= 7; i++)
                                        {
                                            if (control.Name.Equals("txtZoneSV" + (i + 1).ToString(), StringComparison.CurrentCultureIgnoreCase))//设定值
                                                ((TextBox)control).Text = PlcVar.Tube[frmID.Unit].stTempZone[i].rCurrent_SV.ToString();
                                        }
                                    }
                                    //水冷
                                    //lblWaterCooling1.Text = modus.grCooling_PV1.ToString();//水冷1
                                    //lblWaterCooling2.Text = modus.grCooling_PV2.ToString();//水冷2

                                }
                                if (item is View.Tube.UCRoad)//气路
                                {

                                }
                            }
                            if (item is View.Tube.UCRoad)
                            {

                            }
                        }
                    break;
                case "配方":
                    break;
                case "I/O":
                    break;
                case "图表":
                    break;
                case "曲线":
                    break;
                case "配置":
                case "初始化":
                    var bobyInit = this.panControl.Controls.Find("UCInit", false);
                    if (bobyInit != null && bobyInit[0].Controls.Owner is View.Tube.UCInit)
                    {
                        var initInfo = bobyInit[0].Controls.Owner is View.Tube.UCInit;
                        //if(PlcVar.Tube[frmID.Unit].gbProcess_InitDone)
                        //    initInfo.SLProcess_InitDone.
                        //help.SetbtnClickBackColor(btnProcessInit, Color.Green, tubeModelClass.GbProcess_InitDone);
                    }
                    else if (bobyInit != null && bobyInit[0].Controls.Owner is View.Loader.UCSetInit)
                    {

                    }
                    break;
                //···
                //···
                case "舟管理":
                    break;
                case "日志":
                case "事件":
                    var bodyEvent = this.panControl.Controls.Find("UCJournal", false);
                    if (bodyEvent != null && bodyEvent[0].Controls.Owner is View.Common.UCJournal)
                    {
                        var enevtInfo = bodyEvent[0].Controls.Owner as View.Common.UCJournal;
                        enevtInfo.dgvJournal.DataSource = com.TubeServices.TubeAlarmService.Instance.GetTubeAlarmList(frmID.Unit + 1, enevtInfo.dtStartTime.Value, enevtInfo.dtEndTime.Value);
                    }
                    break;
                case "报警":
                    var bodyAlarm = this.panControl.Controls.Find("UCJournal", false);
                    if (bodyAlarm != null && bodyAlarm[0].Controls.Owner is View.Common.UCJournal)
                    {
                        var alarmInfo = bodyAlarm[0].Controls.Owner as View.Common.UCJournal;
                        alarmInfo.dgvJournal.DataSource = com.TubeServices.TubeAlarmService.Instance.GetTubeAlarmList(frmID.Unit + 1, alarmInfo.dtStartTime.Value, alarmInfo.dtEndTime.Value);
                    }
                    break;
                case "关于":
                    break;
            }
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.laplace-tech.cn/");
        }

    }
}
